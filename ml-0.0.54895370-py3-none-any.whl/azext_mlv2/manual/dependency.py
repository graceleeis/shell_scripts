# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import pkg_resources

REQUIREMENTS = []
with open("azext_mlv2/manual/requirements.txt", "rt") as fd:
    REQUIREMENTS = [str(requirement) for requirement in pkg_resources.parse_requirements(fd)]
DEPENDENCIES = ['azure-identity', 'marshmallow<4.0.0,>=3.5', 'tqdm', 'pyjwt', 'azure-storage-blob<=12.9.0,>12.0.0b4', 'azure-storage-file-share<13.0.0', 'pydash<=4.9.0', 'pathspec==0.8.*', 'isodate', 'docker>=4.0.0,~=5.0.0', 'azure-common<2.0.0,>=1.1', 'typing_extensions<4.0.0,>=3.10'] + REQUIREMENTS

