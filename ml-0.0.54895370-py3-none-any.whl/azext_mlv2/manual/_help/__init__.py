# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._component_help import get_component_help
from ._environment_help import get_environment_help
from ._model_help import get_model_help
from ._data_help import get_data_help
from ._dataset_help import get_dataset_help
from ._code_help import get_code_help
from ._job_help import get_job_help
from ._online_endpoint_help import get_online_endpoint_help
from ._batch_endpoint_help import get_batch_endpoint_help
from ._online_deployment_help import get_online_deployment_help
from ._batch_deployment_help import get_batch_deployment_help
from ._workspace_help import get_workspace_help
from ._compute_help import get_compute_help
from ._datastore_help import get_datastore_help

from knack.help_files import helps

get_environment_help()
get_model_help()
get_data_help()
get_dataset_help()
get_code_help()
get_job_help()
get_online_endpoint_help()
get_batch_endpoint_help()
get_online_deployment_help()
get_batch_deployment_help()
get_compute_help()
get_workspace_help()
get_datastore_help()
get_component_help()

helps[
    "ml"
] = """
    type: group
    short-summary: Manage Azure Machine Learning resources.
"""
