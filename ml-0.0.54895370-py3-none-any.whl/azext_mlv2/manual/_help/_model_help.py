# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_model_help():
    helps[
        "ml model"
    ] = """
        type: group
        short-summary: Manage Azure ML models.
        long-summary: >
            Azure ML models consist of the binary file(s) that represent a machine learning
            model and any corresponding metadata.  These models can be used in endpoint
            deployments for real-time and batch inference.
    """
    helps[
        "ml model create"
    ] = """
        type: command
        short-summary: Create a model.
        long-summary: >
            Models can be created from a local file or directory. The created model will be
            tracked in the workspace under the specified name and version.
        examples:
        - name: Create a model from a YAML specification file
          text: az ml model create --file model.yml --resource-group my-resource-group --workspace-name my-workspace
        - name: Create a model from a local folder using command options
          text: az ml model create --name my-model --version 1 --local-path ./my-model --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml model show"
    ] = """
        type: command
        short-summary: Show details for a model.
        examples:
        - name: Show details for a model with the specified name and version
          text: az ml model show --name my-model --version 1 --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml model list"
    ] = """
        type: command
        short-summary: List models in a workspace.
        examples:
        - name: List all the models in a workspace
          text: az ml model list --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the model versions for the specified name in a workspace
          text: az ml model list --name my-model --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the models in a workspace using --query argument to execute a JMESPath query on the results of commands.
          text: az ml model list --query \"[].{Name:name}\"  --output table --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml model delete"
    ] = """
        type: command
        short-summary: Delete a model.
    """
    helps[
        "ml model update"
    ] = """
        type: command
        short-summary: Update a model.
        long-summary: >
            The 'description', and 'tags' properties can be updated.
        examples:
        - name: Update a model's flavors
          text: az ml model update --name my-model --version 1 --set flavors.python_function.python_version=3.8 --resource-group my-resource-group --workspace-name my-workspace
    """
