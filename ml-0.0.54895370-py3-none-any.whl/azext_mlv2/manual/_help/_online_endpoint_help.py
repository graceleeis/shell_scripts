# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_online_endpoint_help():
    helps[
        "ml online-endpoint"
    ] = """
        type: group
        short-summary: Manage Azure ML online endpoints.
        long-summary: >
          Azure ML endpoints provide a simple interface for creating and managing model deployments.
          Each endpoint can have one or more deployments, enabling the traffic from a single scoring
          endpoint to be served to multiple deployments if needed. This is useful for scenarios such
          as controlled rollout.


          Azure ML supports two types of endpoints: online and batch. Online endpoints support real-time
          inference, while batch endpoints are used for offline batch scoring.
    """
    helps[
        "ml online-endpoint create"
    ] = """
        type: command
        short-summary: Create an endpoint.
        long-summary: >
          To create an endpoint, provide a YAML file with batch endpoint
          configuration. If the endpoint already exists, it will be over-written with the new settings.
        examples:
        - name: Create an endpoint from a YAML specification file
          text: az ml online-endpoint create --file endpoint.yml --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml online-endpoint delete"
    ] = """
        type: command
        short-summary: Delete an endpoint.
        examples:
        - name: Delete an online endpoint, including all its deployments
          text: az ml online-endpoint delete --name my-online-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml online-endpoint invoke"
    ] = """
        type: command
        short-summary: Invoke an endpoint
        long-summary: >
          You can invoke an online endpoint with some request data. This
          will be real-time inference, and the scoring results will be returned immediately.
        examples:
        - name: Invoke an online endpoint with some request data
          text: az ml online-endpoint invoke --name my-online-endpoint --request-file sample_request.json --resource-group my-resource-group --workspace-name my-workspace
        - name: Invoke an online endpoint, targeting a specific deployment
          text: az ml online-endpoint invoke --name my-online-endpoint --deployment my-deployment --request-file sample_request.json --resource-group my-resource-group --workspace-name my-workspace

    """
    helps[
        "ml online-endpoint list"
    ] = """
        type: command
        short-summary: List endpoints in a workspace.
        examples:
        - name: List all the online endpoints in a workspace
          text: az ml online-endpoint list --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the batch endpoints in a workspace
          text: az ml online-endpoint list  --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the online endpoints in a workspace using --query argument to execute a JMESPath query on the results of commands.
          text: az ml online-endpoint list --query \"[].{Name:name}\"  --output table --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml online-endpoint get-credentials"
    ] = """
        type: command
        short-summary: List the token/keys for an online endpoint.
        examples:
        - name: List the keys for an online endpoint
          text: az ml online-endpoint get-credentials --name my-online-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml online-endpoint regenerate-keys"
    ] = """
        type: command
        short-summary: Regenerate the keys for an online endpoint.
        examples:
        - name: Regenerate the keys for an online endpoint
          text: az ml online-endpoint regenerate-keys --name my-online-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """

    helps[
        "ml online-endpoint show"
    ] = """
        type: command
        short-summary: Show details for an endpoint.
        examples:
        - name: Show the details for a batch endpoint
          text: az ml online-endpoint show --name my-online-endpoint  --resource-group my-resource-group --workspace-name my-workspace
        - name: Show the provisioning state of an endpoint using --query argument to execute a JMESPath query on the results of commands.
          text: az ml online-endpoint show -n my-endpoint --query "{Name:name,State:provisioning_state}"  --output table --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml online-endpoint update"
    ] = """
        type: command
        short-summary: Update an endpoint.
        long-summary: >
          The 'description', 'tags', and 'traffic' properties of an endpoint can be updated.
          In addition, new deployments can be added to an endpoint, and existing deployments
          can be updated.
        examples:
        - name: Update an endpoint from a YAML specification file
          text: az ml online-endpoint update --file updated_endpoint.yml --resource-group my-resource-group --workspace-name my-workspace
        - name: Update the traffic settings for an endpoint
          text: az ml online-endpoint update --name my-online-endpoint  --traffic "my-new-deployment 100" --resource-group my-resource-group --workspace-name my-workspace
    """
