# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_data_help():
    helps[
        "ml data"
    ] = """
        type: group
        short-summary: Manage Azure ML data assets.
        long-summary: >
            Azure ML data assets are references to file(s) in your storage services or public
            URLs along with any corresponding metadata. They are not copies of your data.
            You can use these data assets to access relevant data during model training and
            mount or download the referenced data to your compute target.
    """
    helps[
        "ml data list"
    ] = """
        type: command
        short-summary: List data assets in a workspace.
        examples:
        - name: List all the data assets in a workspace
          text: az ml data list --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the data asset versions for the specified name in a workspace
          text: az ml data list --name my-data --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the data assets in a workspace using --query argument to execute a JMESPath query on the results of commands.
          text: az ml data list --query \"[].{Name:name}\" --output table --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml data show"
    ] = """
        type: command
        short-summary: Shows details for a data asset.
        examples:
        - name: Show details for a data asset with the specified name and version
          text: az ml data show --name my-data --version 1 --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml data create"
    ] = """
        type: command
        short-summary: Create a data asset.
        long-summary: >
            Data assets can be defined from files on your local machine or as references to
            files in cloud storage. The created data asset will be tracked in the workspace
            under the specified name and version.


            To create a data asset from file(s) on your local machine, specify the 'local_path'
            field in your YAML config. Azure ML will upload these file(s) to the blob container
            that backs the workspace's default datastore (named 'workspaceblobstore'). The created
            data asset will then point to that uploaded data.


            To create a data asset that references file(s) in cloud storage, specify the
            'datastore' that corresponds to the storage service and the 'path' to the file(s)
            in storage in your YAML config.


            You can also create a data asset directly from a storage URL or public URL. To do
            so, specify the URL to the 'path' field in your YAML config.
        examples:
        - name: Create a data asset from a YAML specification file
          text: az ml data create --file data.yml --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml data delete"
    ] = """
        type: command
        short-summary: Delete a data asset.
    """
    helps[
        "ml data update"
    ] = """
        type: command
        short-summary: Update a data asset.
        long-summary: >
            Only the 'description' and 'tags' properties can be updated.
    """
