# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_batch_deployment_help():
    helps[
        "ml batch-deployment"
    ] = """
        type: group
        short-summary: Manage Azure ML batch deployments.
        long-summary: >
          Azure ML deployments provide a simple interface for creating and managing model deployments.

    """
    helps[
        "ml batch-deployment create"
    ] = """
        type: command
        short-summary: Create a deployment. If the deployment already exists, it will be over-written with the new settings.
        examples:
        - name: Create a deployment from a YAML specification file
          text: az ml batch-deployment create --file deployment.yaml --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml batch-deployment show"
    ] = """
        type: command
        short-summary: Show a deployment.
        examples:
        - name: Show a deployment
          text: az ml batch-deployment show --name my-deployment --endpoint-name my-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml batch-deployment list"
    ] = """
        type: command
        short-summary: List deployments.
        examples:
        - name: List deployment in an endpoint
          text: az ml batch-deployment list --endpoint-name my-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml batch-deployment delete"
    ] = """
        type: command
        short-summary: Delete a deployment.
        examples:
        - name: Delete a deployment with confirmation
          text: az ml batch-deployment delete --name my-deployment --endpoint-name my-endpoint --yes --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml batch-deployment list-jobs"
    ] = """
        type: command
        short-summary: List the batch scoring jobs for a batch deployment.
        examples:
        - name: List the batch scoring jobs for a specific deployment
          text: az ml batch-deployment list-jobs --name my-batch-endpoint --endpoint-name my-endpoint --resource-group my-resource-group --workspace-name my-workspace
    """

    helps[
        "ml batch-deployment update"
    ] = """
        type: command
        short-summary: Update a deployment.
        examples:
        - name: Update a deployment from a YAML specification file
          text: az ml batch-deployment update --file deployment.yaml --resource-group my-resource-group --workspace-name my-workspace
    """
