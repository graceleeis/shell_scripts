from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ManagedOnlineDeployment, Model, MultiModel, RouteType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import OnlineDeployment as Deployment

# option 1: load deployment from file
file = "./pipeline_deployment.yaml"
deployment = Deployment.load(path=file)

# option 2: hand craft the deployment
pipeline_model = MultiModel(name="syntax-pipeline", version=1, route_type=RouteType.Pipeline)

model = Model(name="syntax_check", local_path="./model/sklearn_mnist_model.pkl")
deployment_settings = ...
model.set_deployment_settings(deployment_settings)
pipeline_model.append(model)

model = Model(name="syntax_rewrite", local_path="./model/sklearn_mnist_model.pkl")
deployment_settings = ...
model.set_deployment_settings(deployment_settings)
pipeline_model.append(model)

# optionally create and set the pipeline spec
pipeline_spec = ...
pipeline_model.set_route_spec(spec=pipeline_spec)

deployment = ManagedOnlineDeployment(
    name="pipeline-deployment",
    endpoint_name="syntax-endpoint",
    model=pipeline_model,
)

# create deployment through ml client
subscription_id = ""
resource_group_name = ""
workspace_name = ""
ml_client = get_ml_client(
    subscription_id=subscription_id,
    resource_group_name=resource_group_name,
    workspace_name=workspace_name,
)

ml_client.create_or_update(deployment)
