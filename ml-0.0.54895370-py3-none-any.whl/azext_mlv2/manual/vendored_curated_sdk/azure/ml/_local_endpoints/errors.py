# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


## -------- General Local Endpoint Errors -------- ##


class LocalEndpointNotFoundError(Exception):
    def __init__(self, endpoint_name: str, deployment_name: str = None):
        resource_name = (
            f"Local deployment ({endpoint_name} / {deployment_name})"
            if deployment_name
            else f"Local endpoint ({endpoint_name})"
        )
        err = f"{resource_name} does not exist."
        super().__init__(err)


class LocalEndpointInFailedStateError(Exception):
    def __init__(self, endpoint_name, deployment_name=None):
        resource_name = (
            f"Local deployment ({endpoint_name} / {deployment_name})"
            if deployment_name
            else f"Local endpoint ({endpoint_name})"
        )
        err = f"{resource_name} is in failed state. Try getting logs to debug scoring script."
        super().__init__(err)


class DockerEngineNotAvailableError(Exception):
    def __init__(self):
        super().__init__(
            "Please make sure Docker Engine is installed and running. https://docs.docker.com/engine/install/"
        )


class MultipleLocalDeploymentsFoundError(Exception):
    def __init__(self, endpoint_name: str):
        super().__init__(
            f"Multiple deployments found for local endpoint ({endpoint_name}), please specify deployment name."
        )


class InvalidLocalEndpointError(Exception):
    def __init__(self, message: str):
        super().__init__(message)


class LocalEndpointImageBuildError(Exception):
    def __init__(self, complete_build_log: str):
        err = f"Building the local endpoint image failed with the following:\n{complete_build_log}"
        super().__init__(err)


class CloudArtifactsNotSupportedError(Exception):
    def __init__(self, endpoint_name: str, invalid_artifact: str, deployment_name: str = None):
        resource_name = (
            f"local deployment ({endpoint_name} / {deployment_name})"
            if deployment_name
            else f"local endpoint ({endpoint_name})"
        )
        err = f"Local endpoints only support local artifacts. '{invalid_artifact}' in {resource_name} referenced cloud artifacts."
        super().__init__(err)


class RequiredLocalArtifactsNotFoundError(Exception):
    def __init__(
        self, endpoint_name: str, required_artifact: str, required_artifact_type: str, deployment_name: str = None
    ):
        resource_name = (
            f"Local deployment ({endpoint_name} / {deployment_name})"
            if deployment_name
            else f"Local endpoint ({endpoint_name})"
        )
        err = f"Local endpoints only support local artifacts. {resource_name} did not contain required local artifact '{required_artifact}' of type '{required_artifact_type}'."
        super().__init__(err)


## -------- VSCode Debugger Errors -------- ##


class InvalidVSCodeRequestError(Exception):
    def __init__(self):
        super().__init__(
            "Local endpoint request is invalid. If 'vscode' flag is specified, 'local' flag must be set to True."
        )


class VSCodeCommandNotFound(Exception):
    def __init__(self, output=None):
        error_msg = f" due to error: [{output}]" if output else ""
        super().__init__(
            f"Could not start VSCode instance{error_msg}. Please make sure the VSCode command 'code' is installed and accessible from PATH environment variable. See https://code.visualstudio.com/docs/editor/command-line#_common-questions.\n"
        )
