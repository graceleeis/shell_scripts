# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.assets.environment import EnvironmentSchema, AnonymousEnvironmentSchema
# from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmVersionedStr, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.assets.model import AnonymousModelSchema, PipelineModelSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import EndpointComputeType

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.core.fields import ArmVersionedStr,UnionField, StringTransformedEnum

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import camel_to_snake
from marshmallow import fields, post_load

from .scale_settings_schema import DefaultScaleSettingsSchema, TargetUtilizationScaleSettingsSchema
from .request_settings_schema import RequestSettingsSchema
from .resource_requirements_schema import ResourceRequirementsSchema
from .liveness_probe import LivenessProbeSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._deployment.deployment import DeploymentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.assets.model import DeploymentComponentSchema, RoutingSpecSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import BASE_PATH_CONTEXT_KEY

module_logger = logging.getLogger(__name__)


class OnlineDeploymentSchema(DeploymentSchema):
    app_insights_enabled = fields.Bool()
    scale_settings = UnionField(
        [NestedField(DefaultScaleSettingsSchema), NestedField(TargetUtilizationScaleSettingsSchema)]
    )
    request_settings = NestedField(RequestSettingsSchema)
    liveness_probe = NestedField(LivenessProbeSchema)
    readiness_probe = NestedField(LivenessProbeSchema)
    provisioning_state = fields.Str()
    instance_count = fields.Int()
    type = StringTransformedEnum(
        required=False,
        allowed_values=[EndpointComputeType.MANAGED.value, EndpointComputeType.KUBERNETES.value],
        casing_transform=camel_to_snake,
    )
    model_mount_path = fields.Str()
    instance_type = fields.Str()


class KubernetesOnlineDeploymentSchema(OnlineDeploymentSchema):
    resources = NestedField(ResourceRequirementsSchema)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import KubernetesOnlineDeployment

        print("load by KubernetesOnlineDeploymentSchema")
        module_logger.info("KubernetesOnlineDeploymentSchema: Loading KubernetesOnlineDeployment ...")
        return KubernetesOnlineDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class CompositeOnlineDeploymentSchema(OnlineDeploymentSchema):
    resources = NestedField(ResourceRequirementsSchema)
    composite_model = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.MODEL, allow_default_version=True),
            NestedField(AnonymousModelSchema),
            NestedField(PipelineModelSchema),
        ],
        metadata={"description": "Reference to the model asset for the endpoint deployment."},
    )

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._deployment.online_deployment import CompositeOnlineDeployment

        print("load by CompositeOnlineDeploymentSchema")
        module_logger.info("CompositeOnlineDeploymentSchema: Loading CompositeOnlineDeployment ...")
        return CompositeOnlineDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class ManagedOnlineDeploymentSchema(OnlineDeploymentSchema):
    instance_type = fields.Str(required=True)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ManagedOnlineDeployment

        print("load by ManagedOnlineDeploymentSchema")
        return ManagedOnlineDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class CompositeManagedDeploymentSchema(ManagedOnlineDeploymentSchema):
    components = fields.List(
        NestedField(DeploymentComponentSchema),
        required=False,
        metadata={"description": "Reference to the components for the composite managed deployment."},
    )

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._deployment.composite_deployment import CompositeManagedDeployment

        print("load by CompositeManagedDeploymentSchema")
        module_logger.info("CompositeManagedDeploymentSchema: Loading CompositeManagedDeployment ...")
        return CompositeManagedDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class ManagedPipelineDeploymentSchema(CompositeManagedDeploymentSchema):
    routing_spec = NestedField(RoutingSpecSchema, required=True)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._deployment.composite_deployment import ManagedPipelineDeployment

        print("load by ManagedPipelineDeploymentSchema")
        module_logger.info("ManagedPipelineDeploymentSchema: Loading ManagedPipelineDeployment ...")
        return ManagedPipelineDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)
