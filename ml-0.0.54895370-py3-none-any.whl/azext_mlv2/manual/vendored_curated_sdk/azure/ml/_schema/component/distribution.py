# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import copy
from marshmallow import post_dump, post_load, INCLUDE

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.distribution import (
    PyTorchDistributionSchema,
    MPIDistributionSchema,
    TensorFlowDistributionSchema,
)


class BaseComponentDistributionSchema:
    class Meta:
        unknown = INCLUDE

    @post_load
    def make(self, data, **kwargs):
        return data

    @post_dump(pass_original=True)
    def dump_override(self, parsed_json, original, **kwargs):
        if isinstance(original, dict):
            # Parsed JSON contains only the properties declared in the schema.
            # To include unknown properties, we return the original,
            # mapping the parsed rename.
            # dumping should not directly change original dict, otherwise dumping twice will get different result
            result = copy.deepcopy(original)
            if result.get("type", None) is None:
                result["type"] = parsed_json.get("type", None)
            result.pop("distribution_type", None)
            return result
        else:
            # Otherwise return the parsed dict
            return parsed_json


class ComponentPyTorchSchema(BaseComponentDistributionSchema, PyTorchDistributionSchema):
    pass


class ComponentMPISchema(BaseComponentDistributionSchema, MPIDistributionSchema):
    pass


class ComponentTensorFlowSchema(BaseComponentDistributionSchema, TensorFlowDistributionSchema):
    pass
