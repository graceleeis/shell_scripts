# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.core.fields import VersionField
from marshmallow import fields, pre_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PathAwareSchema, UnionField, NestedField, ArmVersionedStr
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.component.input_output import InputPortSchema, ParameterSchema, OutputPortSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.creation_context import CreationContextSchema


class BaseComponentSchema(PathAwareSchema):
    schema = fields.Str(data_key="$schema", attribute="_schema")
    name = fields.Str(required=True)
    id = ArmVersionedStr(azureml_type=AzureMLResourceType.COMPONENT, dump_only=True)
    version = VersionField()
    display_name = fields.Str()
    description = fields.Str()
    tags = fields.Dict(keys=fields.Str(), values=fields.Str())
    is_deterministic = fields.Bool()
    inputs = fields.Dict(
        keys=fields.Str(),
        values=UnionField(
            [
                NestedField(ParameterSchema),
                NestedField(InputPortSchema),
            ]
        ),
    )
    outputs = fields.Dict(keys=fields.Str(), values=NestedField(OutputPortSchema))
    creation_context = NestedField(CreationContextSchema, dump_only=True)

    def __init__(self, *args, **kwargs):
        # Remove schema_ignored to enable serialize and deserialize schema.
        self._declared_fields.pop("schema_ignored", None)
        super().__init__(*args, **kwargs)

    @pre_load
    def convert_version_to_str(self, data, **kwargs):
        if isinstance(data, dict) and data.get("version", None):
            data["version"] = str(data["version"])
        return data
