# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import BASE_PATH_CONTEXT_KEY, AzureMLResourceType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import ModelFormat
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job import CreationContextSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import camel_to_snake
from marshmallow import fields, post_load

from ..core.fields import ArmStr, ArmVersionedStr, StringTransformedEnum, VersionField

from typing import Any
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.core.fields import UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.assets.environment import EnvironmentSchema, AnonymousEnvironmentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._deployment.code_configuration_schema import CodeConfigurationSchema


module_logger = logging.getLogger(__name__)


class ModelSchema(PathAwareSchema):
    name = fields.Str(required=True)
    id = ArmVersionedStr(azureml_type=AzureMLResourceType.MODEL, dump_only=True)
    model_uri = fields.Str()
    local_path = fields.Str()
    version = VersionField()
    description = fields.Str()
    properties = fields.Dict()
    tags = fields.Dict()
    utc_time_created = fields.DateTime()
    flavors = fields.Dict()
    creation_context = NestedField(CreationContextSchema, dump_only=True)
    datastore = ArmStr(
        azureml_type=AzureMLResourceType.DATASTORE,
        metadata={"description": "the datastore in which the data resides (once the Artifact is created)"},
    )
    model_format = StringTransformedEnum(
        allowed_values=[ModelFormat.CUSTOM, ModelFormat.ML_FLOW, ModelFormat.TRITON, ModelFormat.OPEN_AI],
        metadata={"description": "The storage format for this entity. Used for NCD."},
    )
    job_name = fields.Str(dump_only=True)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Model

        return Model(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class AnonymousModelSchema(ModelSchema):
    name = fields.Str()
    version = VersionField()


class PipelineSequenceStepSchema(metaclass=PatchedSchemaMeta):
    name = fields.Str(required=False)
    component = fields.Str(required=False)


class PipelineSpecSchema(metaclass=PatchedSchemaMeta):
    name = fields.Str(required=False)
    steps = fields.Dict(
        keys=fields.Str(),
        values=NestedField(PipelineSequenceStepSchema),
        required=True,
    )

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import PipelineSpec

        module_logger.info("Loading PipelineSpec ...")
        return PipelineSpec(**data)


class RoutingSpecSchema(metaclass=PatchedSchemaMeta):
    mode = fields.Str(required=True)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets.environment import RoutingSpec

        module_logger.info("Loading RoutingSpec ...")
        return RoutingSpec(**data)


class DeploymentComponentSchema(metaclass=PatchedSchemaMeta):
    name = fields.Str(required=True)
    model = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.MODEL, allow_default_version=True),
            NestedField(AnonymousModelSchema),
        ],
        metadata={"description": "Reference to the model asset for the endpoint deployment."},
    )
    code_configuration = NestedField(
        CodeConfigurationSchema, metadata={"description": "Code configuration for the endpoint deployment."}
    )
    environment = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.ENVIRONMENT, allow_default_version=True),
            NestedField(EnvironmentSchema),
            NestedField(AnonymousEnvironmentSchema),
        ]
    )
    environment_variables = fields.Dict(
        metadata={"description": "Environment variables configuration for the deployment."}
    )
    app_insights_enabled = fields.Bool(required=False)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import DeploymentComponent

        module_logger.info("Loading DeploymentComponent ...")
        return DeploymentComponent(**data)


class PipelineModelSchema(ModelSchema):
    type = fields.Str(required=True)
    spec = NestedField(PipelineSpecSchema, metadata={"description": "Code configuration for the endpoint deployment."})
    components = fields.List(NestedField(DeploymentComponentSchema), required=True)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import PipelineModel

        module_logger.info("Loading PipelineModel ...")
        return PipelineModel(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)
