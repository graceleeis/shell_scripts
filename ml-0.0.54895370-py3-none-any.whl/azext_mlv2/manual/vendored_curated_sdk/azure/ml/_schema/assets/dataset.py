# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from .dataset_paths import PathSchema
from marshmallow import fields, post_load, validates, ValidationError, validates_schema

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.core.fields import ArmStr
from .artifact import ArtifactSchema
from .asset import AnonymousAssetSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import BASE_PATH_CONTEXT_KEY, AzureMLResourceType

module_logger = logging.getLogger(__name__)


class DatasetSchema(ArtifactSchema):
    id = ArmStr(azureml_type=AzureMLResourceType.DATASET, dump_only=True)
    paths = UnionField(
        [
            fields.List(NestedField(PathSchema())),
        ],
        metadata={"description": "URI pointing to file or folder."},
    )

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Dataset

        data[BASE_PATH_CONTEXT_KEY] = self.context[BASE_PATH_CONTEXT_KEY]
        return data

    @validates("paths")
    def validate_paths(self, paths):
        if len(paths) <= 0:
            raise ValidationError("paths size must be greater than 0.")


class AnonymousDatasetSchema(DatasetSchema, AnonymousAssetSchema):
    # This is just a subclass of the two parents; it has no additional implementation
    # Necessary methods are provided by parents.
    pass


class DataSchema(ArtifactSchema):
    path = fields.Str(metadata={"description": "URI pointing to a file or directory."})
    datastore = ArmStr(
        azureml_type=AzureMLResourceType.DATASTORE,
        metadata={"description": "the datastore in which the data resides (once the Artifact is created)"},
    )


class AnonymousDataSchema(DataSchema, AnonymousAssetSchema):
    pass
