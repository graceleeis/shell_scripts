# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType
from marshmallow import fields

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.resource_configuration import ResourceConfigurationSchema

from ..assets.code_asset import AnonymousCodeAssetSchema
from ..assets.environment import AnonymousEnvironmentSchema
from ..core.fields import ArmVersionedStr, UnionField
from .distribution import MPIDistributionSchema, PyTorchDistributionSchema, TensorFlowDistributionSchema


class ParameterizedCommandSchema(PathAwareSchema):
    command = fields.Str(
        metadata={
            "description": "The command run and the parameters passed. This string may contain place holders of inputs in {}. "
        },
        required=True,
    )
    code = UnionField(
        [NestedField(AnonymousCodeAssetSchema), ArmVersionedStr(azureml_type=AzureMLResourceType.CODE)],
        metadata={"description": "A file:, http:, https:, or azureml: url pointing to an AzureML instance."},
    )
    environment = UnionField(
        [
            NestedField(AnonymousEnvironmentSchema),
            ArmVersionedStr(azureml_type=AzureMLResourceType.ENVIRONMENT, allow_default_version=True),
        ],
        required=True,
    )
    environment_variables = fields.Dict(keys=fields.Str(), values=fields.Str())
    resources = NestedField(ResourceConfigurationSchema)
    distribution = UnionField(
        [
            NestedField(PyTorchDistributionSchema),
            NestedField(TensorFlowDistributionSchema),
            NestedField(MPIDistributionSchema),
        ],
        metadata={"description": "Provides the configuration for a distributed run."},
    )
