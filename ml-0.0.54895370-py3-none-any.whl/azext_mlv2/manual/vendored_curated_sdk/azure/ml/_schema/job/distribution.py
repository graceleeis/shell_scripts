# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import Mpi, PyTorch, TensorFlow, DistributionType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.core.fields import StringTransformedEnum
from marshmallow import ValidationError, fields, post_load, pre_dump, pre_load, validate

from ..core.schema import PatchedSchemaMeta

module_logger = logging.getLogger(__name__)


class MPIDistributionSchema(metaclass=PatchedSchemaMeta):
    distribution_type = StringTransformedEnum(
        data_key="type", name="type", required=True, allowed_values=DistributionType.MPI
    )
    process_count_per_instance = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        return Mpi(**data)


class TensorFlowDistributionSchema(metaclass=PatchedSchemaMeta):
    distribution_type = StringTransformedEnum(
        data_key="type", name="type", required=True, allowed_values=DistributionType.TENSOR_FLOW
    )
    parameter_server_count = fields.Int()
    worker_count = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        return TensorFlow(**data)


class PyTorchDistributionSchema(metaclass=PatchedSchemaMeta):
    distribution_type = StringTransformedEnum(
        data_key="type", name="type", required=True, allowed_values=DistributionType.PY_TORCH
    )
    process_count_per_instance = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        return PyTorch(**data)
