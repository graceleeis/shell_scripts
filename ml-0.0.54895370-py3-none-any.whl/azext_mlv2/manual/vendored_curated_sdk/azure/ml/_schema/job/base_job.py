# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from marshmallow import fields

from ..core.fields import ArmStr, ComputeField
from .creation_context import CreationContextSchema
from .job_output import JobOutputSchema
from .services import JobServiceSchema

module_logger = logging.getLogger(__name__)


class BaseJobSchema(PathAwareSchema):
    creation_context = NestedField(CreationContextSchema, dump_only=True)
    services = fields.Dict(keys=fields.Str(), values=NestedField(JobServiceSchema))
    name = fields.Str()
    id = ArmStr(azureml_type=AzureMLResourceType.JOB, dump_only=True, required=False)
    display_name = fields.Str(required=False)
    tags = fields.Dict(keys=fields.Str(), values=fields.Str(allow_none=True))
    status = fields.Str(dump_only=True)
    experiment_name = fields.Str()
    properties = fields.Dict(keys=fields.Str(), values=fields.Str(allow_none=True))
    description = fields.Str()
    parent_job_name = fields.Str(dump_only=True)
    log_files = fields.Dict(
        keys=fields.Str(),
        values=fields.Str(),
        dump_only=True,
        metadata={
            "description": "The list of log files associated with this run. This section is only populated by the service and will be ignored if contained in a yaml sent to the service (e.g. via `az ml job create` ...)"
        },
    )
    output = NestedField(
        JobOutputSchema(), metadata={"description": "The output configurations for the component used."}, dump_only=True
    )
    compute = ComputeField(required=True)
