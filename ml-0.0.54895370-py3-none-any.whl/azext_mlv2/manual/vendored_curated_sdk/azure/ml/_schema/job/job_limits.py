# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.core.schema_meta import PatchedSchemaMeta
from marshmallow import fields, post_load


class CommandJobLimitsSchema(metaclass=PatchedSchemaMeta):
    timeout = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import CommandJobLimits

        return CommandJobLimits(**data)


class SweepJobLimitsSchema(metaclass=PatchedSchemaMeta):
    max_concurrent_trials = fields.Int(metadata={"description": "Sweep Job max concurrent trials."})
    max_total_trials = fields.Int(metadata={"description": "Sweep Job max total trials."})
    timeout = fields.Int(
        metadata={
            "description": "The max run duration in ISO 8601 format, after which the job will be cancelled. Only supports duration with precision as low as Seconds."
        }
    )
    trial_timeout = fields.Int(metadata={"description": "Sweep Job Trial timeout value."})

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import SweepJobLimits

        return SweepJobLimits(**data)
