# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.core.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.identity import AMLTokenIdentitySchema, ManagedIdentitySchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import JobType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_fields_provider import InputsField, OutputsField
from marshmallow import fields

from .base_job import BaseJobSchema
from .parameterized_command import ParameterizedCommandSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.job_limits import CommandJobLimitsSchema


class CommandJobSchema(ParameterizedCommandSchema, BaseJobSchema):
    type = StringTransformedEnum(allowed_values=JobType.COMMAND)
    limits = NestedField(CommandJobLimitsSchema)
    parameters = fields.Dict(dump_only=True)
    identity = UnionField(
        [
            NestedField(ManagedIdentitySchema),
            NestedField(AMLTokenIdentitySchema),
        ]
    )
    inputs = InputsField()
    outputs = OutputsField()
