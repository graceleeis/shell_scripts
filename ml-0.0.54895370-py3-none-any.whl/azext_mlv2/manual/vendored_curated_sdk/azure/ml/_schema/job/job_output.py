# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from marshmallow import fields

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.core.fields import ArmStr
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType

module_logger = logging.getLogger(__name__)


class JobOutputSchema(metaclass=PatchedSchemaMeta):
    datastore_id = ArmStr(azureml_type=AzureMLResourceType.DATASTORE)
    path = fields.Str()
