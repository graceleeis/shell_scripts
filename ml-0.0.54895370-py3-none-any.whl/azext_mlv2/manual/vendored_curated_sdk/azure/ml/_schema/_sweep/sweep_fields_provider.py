# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from marshmallow import fields

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, UnionField, StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import (
    SamplingAlgorithm,
)

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._sweep.search_space import (
    UniformSchema,
    ChoiceSchema,
    NormalSchema,
    QUniformSchema,
    QNormalSchema,
    RandintSchema,
)

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._sweep.sweep_termination import (
    BanditPolicySchema,
    MedianStoppingPolicySchema,
    TruncationSelectionPolicySchema,
)


def SamplingAlgorithmField():
    return StringTransformedEnum(
        required=True,
        allowed_values=[SamplingAlgorithm.BAYESIAN, SamplingAlgorithm.GRID, SamplingAlgorithm.RANDOM],
        metadata={"description": "The sampling algorithm to use for the hyperparameter sweep."},
    )


def SearchSpaceField():
    return fields.Dict(
        keys=fields.Str(),
        values=UnionField(
            [
                NestedField(ChoiceSchema()),
                NestedField(UniformSchema()),
                NestedField(QUniformSchema()),
                NestedField(NormalSchema()),
                NestedField(QNormalSchema()),
                NestedField(RandintSchema()),
            ]
        ),
        metadata={"description": "The parameters to sweep over the trial."},
    )


def EarlyTerminationField():
    return UnionField(
        [
            NestedField(BanditPolicySchema()),
            NestedField(MedianStoppingPolicySchema()),
            NestedField(TruncationSelectionPolicySchema()),
        ],
        metadata={"description": "The early termination policy to be applied to the Sweep runs."},
    )
