# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_fields_provider import InputsField, OutputsField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.parameterized_command import ParameterizedCommandSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.job_limits import SweepJobLimitsSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.core.fields import StringTransformedEnum

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import JobType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField

from .sweep_fields_provider import SearchSpaceField, EarlyTerminationField, SamplingAlgorithmField

from .sweep_objective import SweepObjectiveSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job import BaseJobSchema


# This is meant to match the yaml definition NOT the models defined in _restclient
class SweepJobSchema(BaseJobSchema):
    type = StringTransformedEnum(required=True, allowed_values=JobType.SWEEP)
    sampling_algorithm = SamplingAlgorithmField()
    search_space = SearchSpaceField()
    objective = NestedField(
        SweepObjectiveSchema,
        required=True,
        metadata={"description": "The name and optimization goal of the primary metric."},
    )
    trial = NestedField(ParameterizedCommandSchema, required=True)
    early_termination = EarlyTerminationField()
    limits = NestedField(SweepJobLimitsSchema)
    inputs = InputsField()
    outputs = OutputsField()
