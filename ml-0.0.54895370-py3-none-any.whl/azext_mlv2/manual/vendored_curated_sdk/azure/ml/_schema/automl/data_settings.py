# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType, AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, NestedField, ArmVersionedStr
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2020_09_01_preview.models import (
    DataSettings,
    TrainingDataSettings,
    ValidationDataSettings,
    TestDataSettings,
)


class TrainingDataSchema(metaclass=PatchedSchemaMeta):
    dataset_arm_id = ArmVersionedStr(
        azureml_type=AzureMLResourceType.DATA, required=True, data_key=AutoMLConstants.DATASET_YAML
    )

    @post_load
    def make(self, data, **kwargs):
        return TrainingDataSettings(**data)


class ValidationDataSchema(metaclass=PatchedSchemaMeta):
    dataset_arm_id = ArmVersionedStr(azureml_type=AzureMLResourceType.DATA, data_key=AutoMLConstants.DATASET_YAML)
    validation_data_size = fields.Float()
    n_cross_validations = fields.Int()
    cv_split_column_names = fields.List(fields.Str)

    @post_load
    def make(self, data, **kwargs) -> ValidationDataSettings:
        return ValidationDataSettings(**data)


class TestDataSchema(metaclass=PatchedSchemaMeta):
    dataset_arm_id = ArmVersionedStr(azureml_type=AzureMLResourceType.DATA, data_key=AutoMLConstants.DATASET_YAML)
    test_data_size = fields.Float()

    @post_load
    def make(self, data, **kwargs) -> TestDataSettings:
        return TestDataSettings(**data)


class DataSettingsSchema(metaclass=PatchedSchemaMeta):
    training_data = NestedField(
        TrainingDataSchema(), data_key=AutoMLConstants.TRAINING_DATA_SETTINGS_YAML, required=True
    )
    validation_data = NestedField(ValidationDataSchema(), data_key=AutoMLConstants.VALIDATION_DATA_SETTINGS_YAML)
    test_data = NestedField(TestDataSchema(), data_key=AutoMLConstants.TEST_DATA_SETTINGS_YAML)
    target_column_name = fields.Str(required=True)
    weight_column_name = fields.Str()

    @post_load
    def make(self, data, **kwargs) -> DataSettings:
        return DataSettings(**data)
