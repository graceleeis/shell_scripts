# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, UnionField, StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.automl.forecasting import ForecastingSettings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2020_09_01_preview.models import (
    TargetLagsMode,
    TargetRollingWindowSizeMode,
    ForecastHorizonMode,
    ShortSeriesHandlingConfiguration,
    TargetAggregationFunction,
    SeasonalityMode,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models._azure_machine_learning_workspaces_enums import _CaseInsensitiveEnumMeta
from enum import Enum
from six import with_metaclass


class FeatureLagsMode(with_metaclass(_CaseInsensitiveEnumMeta, str, Enum)):
    """Feature lags mode."""

    AUTO = "Auto"


class ForecastingSettingsSchema(metaclass=PatchedSchemaMeta):
    country_or_region_for_holidays = fields.Str()
    forecast_horizon = UnionField(
        [
            StringTransformedEnum(allowed_values=[ForecastHorizonMode.AUTO]),
            fields.Int(),
        ]
    )
    target_lags = UnionField(
        [
            StringTransformedEnum(allowed_values=[TargetLagsMode.AUTO]),
            fields.Int(),
            fields.List(fields.Int()),
        ]
    )
    target_rolling_window_size = UnionField(
        [
            StringTransformedEnum(allowed_values=[TargetRollingWindowSizeMode.AUTO]),
            fields.Int(),
        ]
    )
    time_column_name = fields.Str()
    time_series_id_column_names = UnionField([fields.Str(), fields.List(fields.Str())])
    frequency = fields.Str()
    feature_lags = StringTransformedEnum(allowed_values=[FeatureLagsMode.AUTO])
    seasonality = UnionField(
        [
            StringTransformedEnum(allowed_values=[SeasonalityMode.AUTO]),
            fields.Int(),
        ]
    )
    use_stl = fields.Str()
    short_series_handling_config = StringTransformedEnum(
        allowed_values=[o.value for o in ShortSeriesHandlingConfiguration]
    )
    target_aggregate_function = StringTransformedEnum(allowed_values=[o.value for o in TargetAggregationFunction])

    @post_load
    def make(self, data, **kwargs):
        return ForecastingSettings(**data)
