# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields, post_load

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import camel_to_snake
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, NestedField, StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2020_09_01_preview.models import SweepSettingsLimits, EarlyTerminationPolicyType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._sweep.sweep_fields_provider import (
    SearchSpaceField,
    SamplingAlgorithmField,
)


class SweepEarlyTerminationPolicySchema(metaclass=PatchedSchemaMeta):
    type = StringTransformedEnum(
        required=True,
        allowed_values=[t.value for t in EarlyTerminationPolicyType],
        casing_transform=camel_to_snake,
        data_key=AutoMLConstants.TERMINATION_POLICY_TYPE_YAML,
    )
    evaluation_interval = fields.Int()
    delay_evaluation = fields.Int()
    slack_factor = fields.Float()
    slack_amount = fields.Float()
    truncation_percentage = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import SweepEarlyTerminationPolicy

        return SweepEarlyTerminationPolicy(**data)


class SweepSettingsLimitsSchema(metaclass=PatchedSchemaMeta):
    max_concurrent_trials = fields.Int()
    max_total_trials = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        return SweepSettingsLimits(**data)


class SweepSettingsSchema(metaclass=PatchedSchemaMeta):
    sampling_algorithm = SamplingAlgorithmField()
    search_space = SearchSpaceField()
    early_termination = NestedField(SweepEarlyTerminationPolicySchema())
    limits = NestedField(SweepSettingsLimitsSchema())

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.automl.sweep import SweepSettings

        return SweepSettings(**data)
