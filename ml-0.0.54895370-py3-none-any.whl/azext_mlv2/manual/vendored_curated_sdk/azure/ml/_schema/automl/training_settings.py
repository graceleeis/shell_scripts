# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, NestedField, StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2020_09_01_preview.models import (
    StackEnsembleSettings,
    StackMetaLearnerType,
)


class StackEnsembleSettingsSchema(metaclass=PatchedSchemaMeta):
    stack_meta_learner_kwargs = fields.Dict()
    stack_meta_learner_train_percentage = fields.Float()
    stack_meta_learner_type = StringTransformedEnum(allowed_values=[o.value for o in StackMetaLearnerType])

    @post_load
    def make(self, data, **kwargs):
        return StackEnsembleSettings(**data)


class TrainingSettingsSchema(metaclass=PatchedSchemaMeta):
    block_list_models = fields.List(fields.Str(), data_key=AutoMLConstants.BLOCKED_ALGORITHMS_YAML)
    allow_list_models = fields.List(fields.Str(), data_key=AutoMLConstants.ALLOWED_ALGORITHMS_YAML)
    enable_dnn_training = fields.Bool()
    enable_onnx_compatible_models = fields.Bool()
    enable_stack_ensemble = fields.Bool()
    enable_vote_ensemble = fields.Bool()
    ensemble_model_download_timeout = fields.Int(data_key=AutoMLConstants.ENSEMBLE_MODEL_DOWNLOAD_TIMEOUT_YAML)
    stack_ensemble_settings = NestedField(StackEnsembleSettingsSchema())

    @post_load
    def make(self, data, **kwargs) -> "TrainingSettings":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.automl.training_settings import TrainingSettings

        return TrainingSettings(**data)
