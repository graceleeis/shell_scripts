# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Dict, Iterable

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations import DatastoreOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_03_01_preview import AzureMachineLearningWorkspaces as ServiceClient032021
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import is_ARM_id_for_resource, get_datastore_arm_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._artifact_utilities import _check_and_upload_path
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Data
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._constants import ASSET_PATH_ERROR, CHANGED_ASSET_PATH_MSG

module_logger = logging.getLogger(__name__)


class DataOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: ServiceClient032021,
        datastore_operations: DatastoreOperations,
        **kwargs: Dict,
    ):

        super(DataOperations, self).__init__(workspace_scope)
        self._operation = service_client.data_versions
        self._container_operation = service_client.data_containers
        self._datastore_operation = datastore_operations
        self._init_kwargs = kwargs

    def list(self, name: str = None) -> Iterable[Data]:
        """List the data assets of the workspace.

        :param name: Name of a specific data asset, optional.
        :type name: Optional[str]
        :return: An iterator like instance of Data objects
        :rtype: ~azure.core.paging.ItemPaged[Data]
        """
        if name:
            return self._operation.list(
                name=name,
                workspace_name=self._workspace_name,
                cls=lambda objs: [Data._from_rest_object(obj) for obj in objs],
                **self._scope_kwargs,
            )
        else:
            return self._container_operation.list(
                workspace_name=self._workspace_name,
                cls=lambda objs: [Data._from_container_rest_object(obj) for obj in objs],
                **self._scope_kwargs,
            )

    def get(self, name: str, version: str) -> Data:
        """Get the specified data asset.

        :param name: Name of data asset.
        :type name: str
        :param version: Version of data asset.
        :type version: str
        :return: Data asset object.
        """
        data_version_resource = self._operation.get(
            name,
            version,
            self._resource_group_name,
            self._workspace_name,
            **self._init_kwargs,
        )

        return Data._from_rest_object(data_version_resource)

    def create_or_update(self, data: Data) -> Data:
        """Returns created or updated data asset.

        If not already in storage, asset will be uploaded to datastore name specified in data.datastore or the workspace's default datastore.

        :param data: Data asset object.
        :type data: Data
        :return: Data asset object.
        """
        name = data.name
        version = data.version

        data, _ = _check_and_upload_path(artifact=data, asset_operations=self, datastore_name=data.datastore)
        if not is_ARM_id_for_resource(data.datastore):
            data.datastore = get_datastore_arm_id(data.datastore, self._workspace_scope)
        data_version_resource = data._to_rest_object()
        try:
            result = self._operation.create_or_update(
                name=name,
                version=version,
                workspace_name=self._workspace_name,
                body=data_version_resource,
                **self._scope_kwargs,
            )
        except Exception as e:
            # service side raises an exception if we attempt to update an existing asset's asset path
            if str(e) == ASSET_PATH_ERROR:
                raise Exception(CHANGED_ASSET_PATH_MSG)
            else:
                raise e

        return Data._from_rest_object(result)

    def delete(self, name: str, version: str) -> None:
        """Delete data asset.

        :param name: Name of data asset.
        :type name: str
        :param version: Version of data asset.
        :type version: str
        :return: None
        """
        if version:
            return self._operation.delete(
                name,
                version,
                self._resource_group_name,
                self._workspace_name,
                **self._init_kwargs,
            )
        else:
            raise Exception("Deletion on the whole lineage is not supported yet.")
