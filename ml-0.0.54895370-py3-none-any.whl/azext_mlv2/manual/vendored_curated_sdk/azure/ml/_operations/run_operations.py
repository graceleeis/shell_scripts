# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.runhistory import (
    AzureMachineLearningWorkspaces as RunHistoryServiceClient,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.runhistory.models import RunDetailsDto, PaginatedRunDto
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import _WorkspaceDependentOperations, WorkspaceScope

module_logger = logging.getLogger(__name__)


class RunOperations(_WorkspaceDependentOperations):
    def __init__(self, workspace_scope: WorkspaceScope, service_client: RunHistoryServiceClient):
        super(RunOperations, self).__init__(workspace_scope)
        self._operation = service_client.run

    def get_run_details(self, exp_name: str, run_id: str) -> RunDetailsDto:
        return self._operation.get_details(
            self._workspace_scope.subscription_id,
            self._workspace_scope.resource_group_name,
            self._workspace_name,
            exp_name,
            run_id,
        )

    def get_run_children(self, exp_name: str, run_id: str) -> PaginatedRunDto:
        return self._operation.get_child(
            self._workspace_scope.subscription_id,
            self._workspace_scope.resource_group_name,
            self._workspace_name,
            exp_name,
            run_id,
        )
