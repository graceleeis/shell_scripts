# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Dict, Iterable

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01 import AzureMachineLearningWorkspaces as ServiceClient102021
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import DatastoreCredentials, DatastoreSecrets, NoneDatastoreCredentials
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._datastore.datastore import Datastore

module_logger = logging.getLogger(__name__)


class DatastoreOperations(_WorkspaceDependentOperations):
    """Represents a client for performing operations on Datastores

    You should not instantiate this class directly. Instead, you should create MLClient and
    use this client via the property MLClient.datastores
    """

    def __init__(self, workspace_scope: WorkspaceScope, service_client: ServiceClient102021, **kwargs: Dict):
        super(DatastoreOperations, self).__init__(workspace_scope)
        self._operation = service_client.datastores
        self._init_kwargs = kwargs

    def list(self, *, include_secrets: bool = False) -> Iterable[Datastore]:
        """Lists all datastores and associated information within a workspace

        :param include_secrets: Include datastore secrets in returned datastores, defaults to False
        :type include_secrets: bool, optional
        :return: An iterator like instance of Datastore objects
        :rtype: ~azure.core.paging.ItemPaged[Datastore]
        """

        def _list_helper(ds, include_secrets: bool):
            ds = Datastore._from_rest_object(ds)
            # TODO: remove this when service side allows getting secrets directly through list
            if include_secrets:
                secrets = self._list_secrets(ds.name)  # type: ignore
                self._populate_datastore_credentials(ds.properties.credentials, secrets)
            return ds

        return self._operation.list(
            self._workspace_scope.resource_group_name,
            self._workspace_name,
            cls=lambda objs: [_list_helper(obj, include_secrets) for obj in objs],
            **self._init_kwargs
        )

    def _list_secrets(self, name: str) -> DatastoreSecrets:
        return self._operation.list_secrets(
            name, self._workspace_scope.resource_group_name, self._workspace_name, **self._init_kwargs
        )

    def delete(self, name: str) -> None:
        """Deletes a datastore reference with the given name from the workspace. This method
        does not delete the actual datastore or underlying data in the datastore.

        :param name: Name of the datastore
        :type name: str
        """

        return self._operation.delete(
            name, self._workspace_scope.resource_group_name, self._workspace_name, **self._init_kwargs
        )

    def get(self, name: str, *, include_secrets: bool = False) -> Datastore:
        """Returns information about the datastore referenced by the given name

        :param name: Datastore name
        :type name: str
        :param include_secrets: Include datastore secrets in the returned datastore, defaults to False
        :type include_secrets: bool, optional
        :return: Datastore with the specified name.
        :rtype: Datastore
        """

        datastore_resource = self._operation.get(
            name, self._workspace_scope.resource_group_name, self._workspace_name, **self._init_kwargs
        )
        # TODO: remove this when services allow getting secrets with just _operation.get
        if include_secrets:
            if datastore_resource.name and not isinstance(
                datastore_resource.properties.credentials, NoneDatastoreCredentials
            ):
                secrets = self._list_secrets(datastore_resource.name)
                self._populate_datastore_credentials(datastore_resource.properties.credentials, secrets)
        return Datastore._from_rest_object(datastore_resource)

    def _populate_datastore_credentials(
        self, datastore_credentials: DatastoreCredentials, secrets: DatastoreSecrets
    ) -> None:
        # if datastore_contents:
        #     datastore_contents.credentials = credentials
        # elif datastore_contents.azure_data_lake:
        datastore_credentials.secrets = secrets

    def get_default(self, *, include_secrets: bool = False) -> Datastore:
        """Returns the workspace's default datastore

        :param include_secrets: Include datastore secrets in the returned datastore, defaults to False
        :type include_secrets: bool, optional
        :return: The default datastore.
        :rtype: Datastore
        """

        ds = self._operation.list(
            self._workspace_scope.resource_group_name, self._workspace_name, is_default=True, **self._init_kwargs
        ).next()
        if include_secrets:
            secrets = self._list_secrets(ds.name)  # type: ignore
            self._populate_datastore_credentials(ds.properties.credentials, secrets)
        return Datastore._from_rest_object(ds)

    def create_or_update(self, datastore: Datastore) -> Datastore:
        """Attaches the passed in datastore to the workspace or updates the datastore if it already exists

        :param datastore: The configuration of the datastore to attach.
        :type datastore: Datastore
        :return: The attached datastore.
        :rtype: Datastore
        """

        ds_request = datastore._to_rest_object()
        datastore_resource = self._operation.create_or_update(
            datastore.name,
            self._workspace_scope.resource_group_name,
            self._workspace_name,
            ds_request,
            skip_validation=True,
        )
        return Datastore._from_rest_object(datastore_resource)
