# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging
from typing import Any, Iterable

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._artifact_utilities import _upload_to_datastore, _check_and_upload_env_build_context
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import ARM_ID_PREFIX, AzureMLResourceType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations import DatastoreOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import _WorkspaceDependentOperations, WorkspaceScope, OperationsContainer
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01 import AzureMachineLearningWorkspaces as ServiceClient102021
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import (
    EnvironmentVersionResource,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Environment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._asset_utils import _create_or_update_autoincrement

module_logger = logging.getLogger(__name__)


class EnvironmentOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: ServiceClient102021,
        all_operations: OperationsContainer,
        **kwargs: Any
    ):
        super(EnvironmentOperations, self).__init__(workspace_scope)
        self._kwargs = kwargs
        self._containers_operations = service_client.environment_containers
        self._version_operations = service_client.environment_versions
        self._all_operations = all_operations
        self._datastore_operation = all_operations.all_operations[AzureMLResourceType.DATASTORE]

    def create_or_update(self, environment: Environment) -> Environment:
        """Returns created or updated environment asset.

        :param environment: Environment object
        :type environment: Environment
        :return: Created or updated Environment object
        """

        if environment.build and environment.build.local_path and environment.build.context_uri:
            raise Exception("Docker build local_path or context_uri should be provided not both")

        environment = _check_and_upload_env_build_context(environment=environment, operations=self)

        env_version_resource = environment._to_rest_object()

        if environment._auto_increment_version:
            env_rest_obj = _create_or_update_autoincrement(
                name=environment.name,
                body=env_version_resource,
                version_operation=self._version_operations,
                container_operation=self._containers_operations,
                workspace_name=self._workspace_name,
                **self._scope_kwargs,
                **self._kwargs,
            )
        else:
            env_rest_obj = self._version_operations.create_or_update(
                name=environment.name,
                version=environment.version,
                workspace_name=self._workspace_name,
                body=env_version_resource,
                **self._scope_kwargs,
                **self._kwargs,
            )

        return Environment._from_rest_object(env_rest_obj)

    def _get(self, name: str, version: str) -> EnvironmentVersionResource:
        env_version_resource = self._version_operations.get(
            name=name,
            version=version,
            workspace_name=self._workspace_name,
            **self._scope_kwargs,
            **self._kwargs,
        )
        return env_version_resource

    def get(self, name: str, version: str) -> Environment:
        """Returns the specified environment asset.

        :param name: Name of the environment.
        :type name: str
        :param version: Version of the environment.
        :type version: str
        :return: Environment object
        """
        name = _preprocess_environment_name(name)
        env_version_resource = self._get(name, version)

        return Environment._from_rest_object(env_version_resource)

    def list(self, name: str = None) -> Iterable[Environment]:
        """List all environment assets in workspace.

        :param name: Name of the environment.
        :type name: str
        :return: An iterator like instance of Environment objects
        :rtype: ~azure.core.paging.ItemPaged[Environment]
        """
        if name:
            return self._version_operations.list(
                name=name,
                workspace_name=self._workspace_name,
                cls=lambda objs: [Environment._from_rest_object(obj) for obj in objs],
                **self._scope_kwargs,
                **self._kwargs,
            )
        else:
            return self._containers_operations.list(
                workspace_name=self._workspace_name,
                cls=lambda objs: [Environment._from_container_rest_object(obj) for obj in objs],
                **self._scope_kwargs,
                **self._kwargs,
            )

    def delete(self, name: str, version: str, **kwargs) -> None:
        """
        Delete the environment container

        :param name: Name of the environment.
        :type name: str
        :param version: Version of the environment.
        :type version: str
        """
        self._version_operations.delete(
            name=name,
            version=version,
            workspace_name=self._workspace_name,
            **self._scope_kwargs,
            **self._kwargs,
        )


def _preprocess_environment_name(environment_name: str) -> str:
    if environment_name.startswith(ARM_ID_PREFIX):
        return environment_name[len(ARM_ID_PREFIX) :]
    return environment_name
