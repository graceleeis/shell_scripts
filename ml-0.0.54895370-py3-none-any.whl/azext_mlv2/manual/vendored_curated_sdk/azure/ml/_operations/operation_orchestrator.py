# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any, Optional, Union
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._artifact_utilities import (
    IgnoreFile,
    _get_datastore_name,
    _check_and_upload_path,
    _check_and_upload_env_build_context,
    _upload_to_datastore,
    get_datastore_info,
    get_storage_client,
    get_object_hash,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._exception_utils import EmptyDirectoryError
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Code, Model, Dataset, Environment, Data
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets.asset import Asset
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets._artifacts.artifact import Artifact, ArtifactStorageInfo
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Component
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import (
    AMLNamedArmId,
    AMLVersionedArmId,
    is_ARM_id_for_resource,
    parse_name_version,
    get_arm_id_with_version,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import OperationsContainer, WorkspaceScope
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import (
    AZUREML_RESOURCE_PROVIDER,
    NAMED_RESOURCE_ID_FORMAT,
    VERSIONED_RESOURCE_ID_FORMAT,
    VERSIONED_RESOURCE_NAME,
    AzureMLResourceType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._deployment.component_converter import ComponentConverter
from pathlib import Path
import json

module_logger = logging.getLogger(__name__)


class OperationOrchestrator(object):
    AZUREML_TYPE_TO_ASSET_ENTITY = {
        AzureMLResourceType.MODEL: Model,
        AzureMLResourceType.CODE: Code,
        AzureMLResourceType.DATA: Data,
        AzureMLResourceType.DATASET: Dataset,
        AzureMLResourceType.ENVIRONMENT: Environment,
        AzureMLResourceType.COMPONENT: Component,
    }

    def __init__(self, operation_container: OperationsContainer, workspace_scope: WorkspaceScope):
        self._operation_container = operation_container
        self._workspace_scope = workspace_scope
        self._datastore_operation = self._operation_container.all_operations[AzureMLResourceType.DATASTORE]
        self._code_assets = self._operation_container.all_operations[AzureMLResourceType.CODE]
        self._environments = self._operation_container.all_operations[AzureMLResourceType.ENVIRONMENT]
        self._model = self._operation_container.all_operations[AzureMLResourceType.MODEL]
        self._dataset = self._operation_container.all_operations[AzureMLResourceType.DATASET]
        self._data = self._operation_container.all_operations[AzureMLResourceType.DATA]
        self._component = self._operation_container.all_operations[AzureMLResourceType.COMPONENT]

    def _prepare_dump_folder(self, endpoint_name, deployment_name):
        from pathlib import Path

        Path(f"./.dumps/{endpoint_name}/{deployment_name}/").mkdir(parents=True, exist_ok=True)

    def dump_file(self, content, file_name):
        try:
            with open(file_name, "w") as fp:
                json.dump(content, fp)
        except Exception as ex:
            print(f"dump manifest file error: {str(ex)}")

    def upload_storage_manifest(self, component, deployment_name, endpoint_name):
        # prepare dump folder
        self._prepare_dump_folder(endpoint_name, deployment_name)

        # generate and dump manifest file
        converter = ComponentConverter(component)
        manifest_content = converter.generate_manifest_content()
        file_name = f"./.dumps/{endpoint_name}/{deployment_name}/{endpoint_name}_{deployment_name}-{endpoint_name}_{component.name}_component_config_map.json"
        self.dump_file(manifest_content, file_name)

        component = self.upload(component, path=file_name, asset_operations=self._model, datastore_name=None)

        return component

    def upload(
        self,
        component,
        path,
        asset_operations,
        datastore_name: str = None,
        show_progress=True,
        ignore_file=IgnoreFile(None),
    ):
        # path = Path(component.local_path)
        # if not path.is_absolute():
        #     path = Path(component.base_path, path).resolve()

        # upload storage manifest
        asset_name = component.name
        asset_version = "1"

        datastore_name = _get_datastore_name(asset_operations._datastore_operation, datastore_name)
        datastore_info = get_datastore_info(asset_operations._datastore_operation, datastore_name)
        datastore_info["container_name"] = "azureml/Components"
        storage_client = get_storage_client(**datastore_info)

        asset_hash = get_object_hash(path, ignore_file)

        # uploading
        source_name = Path(path).name
        dest = f"{source_name}_{asset_hash}"
        msg = f"Uploading {dest}"

        try:
            blob_exist = False
            storage_client.indicator_file = dest
            storage_client.check_blob_exists()
        except Exception as ex:
            blob_exist = True
            print(f"blob may exist, skip uploading - {dest}: {str(ex)}")
        if not blob_exist:
            storage_client.upload_file(path, dest, msg, show_progress)

        artifact_info = {"remote path": dest, "name": asset_name, "version": asset_version, "indicator file": dest}

        artifact = ArtifactStorageInfo(
            name=artifact_info["name"],
            version=artifact_info["version"],
            relative_path=artifact_info["remote path"],
            datastore_arm_id=None,  # get_datastore_arm_id(datastore_name, workspace_scope),
            container_name=datastore_info["container_name"],
            storage_account_url=datastore_info.get("account_url"),
            indicator_file=artifact_info["indicator file"],
            is_file=Path(path).is_file(),
        )

        uploaded_artifact = artifact

        # Pass all of the upload information to the assets, and they will each construct the URLs that they support
        component._update_path(uploaded_artifact)

        return component

    def get_asset_arm_id(
        self,
        asset: Optional[Union[str, Asset]],
        azureml_type: str,
        register_asset: bool = True,
        sub_workspace_resource: bool = True,
    ):
        """This method converts AzureML Id to ARM Id. Or if the given asset is entity object, it tries to register/upload the asset based on register_asset and aszureml_type.

        :param asset: The asset to resolve/register. It can be a ARM id or a entity's object.
        :type asset: Optional[Union[str, InternalAsset]]
        :param azureml_type: The AzureML resource type. Defined in AzureMLResourceType.
        :type azureml_type: str
        :param register_asset: flag to register the asset, defaults to True
        :type register_asset: bool, optional
        :return: The ARM Id or entity object
        :rtype: Optional[Union[str, InternalAsset]]
        """
        if asset is None or is_ARM_id_for_resource(asset, azureml_type, sub_workspace_resource):
            return asset
        if isinstance(asset, str):
            if azureml_type in AzureMLResourceType.NAMED_TYPES:
                return NAMED_RESOURCE_ID_FORMAT.format(
                    self._workspace_scope.subscription_id,
                    self._workspace_scope.resource_group_name,
                    AZUREML_RESOURCE_PROVIDER,
                    self._workspace_scope.workspace_name,
                    azureml_type,
                    asset,
                )
            elif azureml_type in AzureMLResourceType.VERSIONED_TYPES:
                name, version = parse_name_version(asset)
                if not version:
                    raise Exception(
                        f"Failed to extract version when parsing asset {asset} of type {azureml_type} as arm id. Version must be provided."
                    )
                return VERSIONED_RESOURCE_ID_FORMAT.format(
                    self._workspace_scope.subscription_id,
                    self._workspace_scope.resource_group_name,
                    AZUREML_RESOURCE_PROVIDER,
                    self._workspace_scope.workspace_name,
                    azureml_type,
                    name,
                    version,
                )
            else:
                raise Exception(f"Unsupported azureml type {azureml_type} for asset: {asset}")
        elif isinstance(asset, OperationOrchestrator.AZUREML_TYPE_TO_ASSET_ENTITY[azureml_type]):
            try:
                # TODO: once the asset redesign is finished, this logic can be replaced with unified API
                if azureml_type == AzureMLResourceType.CODE:
                    return self._get_code_asset_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.ENVIRONMENT:
                    return self._get_environment_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.MODEL:
                    return self._get_model_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.DATA:
                    return self._get_data_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.DATASET:
                    return self._get_dataset_arm_id(asset, register_asset=register_asset)
                elif azureml_type == AzureMLResourceType.COMPONENT:
                    return self._get_component_arm_id(asset)
                else:
                    raise Exception(f"Unsupported azureml type {azureml_type} for asset: {asset}")
            except EmptyDirectoryError as e:
                raise Exception(f"Error creating {azureml_type} asset : {e.message}")

    def _get_code_asset_arm_id(self, code_asset: Code, register_asset: bool = True) -> Union[Code, str]:
        try:
            if register_asset:
                code_asset = self._code_assets.create_or_update(code_asset)
                return code_asset.id
            else:
                uploaded_code_asset, _ = _check_and_upload_path(artifact=code_asset, asset_operations=self._code_assets)
                uploaded_code_asset._id = get_arm_id_with_version(
                    self._workspace_scope, AzureMLResourceType.CODE, code_asset.name, code_asset.version
                )
                return uploaded_code_asset
        except Exception as e:
            raise Exception(f"Error with code: {e}")

    def _get_environment_arm_id(self, environment: Environment, register_asset: bool = True) -> Union[str, Environment]:
        if register_asset:
            env_response = self._environments.create_or_update(environment)
            return env_response.id
        else:
            environment = _check_and_upload_env_build_context(environment=environment, operations=self._environments)
            environment._id = get_arm_id_with_version(
                self._workspace_scope, AzureMLResourceType.ENVIRONMENT, environment.name, environment.version
            )
            return environment

    def _get_model_arm_id(self, model: Model, register_asset: bool = True) -> Union[str, Model]:
        # check model type here and handle compound model
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets.environment import CompositeModel
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._deployment.code_configuration import CodeConfiguration

        if isinstance(model, CompositeModel):
            for comp in model.components:
                if comp.model is not None:
                    module_logger.info(f"_get_model_arm_id component model name: {comp.model.name}")

                    updated_model = (
                        self.get_asset_arm_id(
                            comp.model, azureml_type=AzureMLResourceType.MODEL, register_asset=register_asset
                        )
                        if comp.model
                        else None
                    )
                    comp.model = updated_model
                    last_model_uri = updated_model.model_uri
                if comp.code_configuration is not None:
                    module_logger.info("_get_model_arm_id component code configuration")

                    updated_code_configuration = (
                        CodeConfiguration(
                            code=self.get_asset_arm_id(
                                comp.code_configuration.code,
                                azureml_type=AzureMLResourceType.CODE,
                                register_asset=register_asset,
                            ),
                            scoring_script=comp.code_configuration.scoring_script,
                        )
                        if comp.code_configuration
                        else None
                    )
                    comp.code_configuration = updated_code_configuration
                if comp.environment is not None:
                    module_logger.info("_get_model_arm_id component environment")

                    updated_environment = (
                        self.get_asset_arm_id(
                            comp.environment,
                            azureml_type=AzureMLResourceType.ENVIRONMENT,
                            register_asset=register_asset,
                        )
                        if comp.environment
                        else None
                    )
                    comp.environment = updated_environment
            for comp in model.components:
                if comp.model is not None:
                    module_logger.info(f"component model name: {comp.model.name}")
            module_logger.info(f"Last model_uri: {last_model_uri}")

        try:
            if register_asset:
                return self._model.create_or_update(model).id
            else:
                uploaded_model, _ = _check_and_upload_path(artifact=model, asset_operations=self._model)

                if isinstance(model, CompositeModel):
                    uploaded_model.model_uri = last_model_uri

                uploaded_model._id = get_arm_id_with_version(
                    self._workspace_scope, AzureMLResourceType.MODEL, model.name, model.version
                )
                return uploaded_model
        except Exception as e:
            raise Exception(f"Error with model: {e}")

    def _get_dataset_arm_id(self, data_asset: Dataset, register_asset: bool = True) -> Union[str, Dataset]:
        if register_asset:
            return self._dataset.create_or_update(data_asset).id
        else:
            data_asset, _ = _check_and_upload_path(artifact=data_asset, asset_operations=self._dataset)
            return data_asset

    def _get_data_arm_id(self, data_asset: Data, register_asset: bool = True) -> Union[str, Data]:
        if register_asset:
            return self._data.create_or_update(data_asset).id
        else:
            data_asset, _ = _check_and_upload_path(artifact=data_asset, asset_operations=self._data)
            return data_asset

    def _get_component_arm_id(self, component: Component) -> str:
        """Register component and get arm id."""
        return self._component.create_or_update(component).id

    def resolve_azureml_id(self, arm_id: str = None, **kwargs) -> str:
        """Thie function converts ARM id to name or name:version AzureML id. It parses the ARM id and matches the
        subscription Id, resource group name and worksapce_name.

        TODO: It is detable whether this method should be in operation_orchestrator.

        :param arm_id: entity's ARM id, defaults to None
        :type arm_id: str, optional
        :return: AzureML id
        :rtype: str
        """

        if arm_id and isinstance(arm_id, str):
            try:
                id = AMLVersionedArmId(arm_id)
                if self._match(id):
                    return VERSIONED_RESOURCE_NAME.format(id.asset_name, id.asset_version)
            except ValueError:
                pass  # fall back to named arm id
            try:
                id = AMLNamedArmId(arm_id)
                if self._match(id):
                    return id.asset_name
            except ValueError:
                pass  # fall back to be not a ARM_id
        return arm_id

    def _match(self, id: Any) -> bool:
        return (
            id.subscription_id == self._workspace_scope.subscription_id
            and id.resource_group_name == self._workspace_scope.resource_group_name
            and id.workspace_name == self._workspace_scope.workspace_name
        )
