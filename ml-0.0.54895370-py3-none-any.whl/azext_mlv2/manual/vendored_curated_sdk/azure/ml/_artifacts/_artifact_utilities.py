# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import os
from typing import Optional, Dict, Union, Tuple
from pathlib import Path
from datetime import datetime, timedelta

from azure.storage.blob import generate_blob_sas, BlobSasPermissions
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations import DatastoreOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._storage_utils import get_storage_client, STORAGE_ACCOUNT_URLS
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Environment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets._artifacts.artifact import Artifact, ArtifactStorageInfo
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._datastore.credentials import AccountKeyCredentials
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import (
    get_datastore_arm_id,
    get_resource_name_from_arm_id,
    remove_aml_prefix,
    is_ARM_id_for_resource,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._asset_utils import (
    _validate_path,
    get_object_hash,
    get_ignore_file,
    IgnoreFile,
    _build_metadata_dict,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._storage_utils import get_artifact_path_from_blob_url
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import (
    DatastoreType,
)

module_logger = logging.getLogger(__name__)


def _get_datastore_name(datastore_operation: DatastoreOperations, datastore_name: str):
    datastore_name = datastore_name or datastore_operation.get_default().name
    try:
        datastore_name = get_resource_name_from_arm_id(datastore_name)
    except (ValueError, AttributeError):
        module_logger.debug(f"datastore_name {datastore_name} is not a full arm id. Proceed with a shortened name.\n")
    datastore_name = remove_aml_prefix(datastore_name)
    if is_ARM_id_for_resource(datastore_name):
        datastore_name = get_resource_name_from_arm_id(datastore_name)
    return datastore_name


def get_datastore_info(operations: DatastoreOperations, name: str) -> Dict[str, str]:
    """
    Get datastore account, type, and auth information
    """
    datastore_info = {}
    if name:
        datastore = operations.get(name, include_secrets=True)
    else:
        datastore = operations.get_default(include_secrets=True)

    credentials = datastore.credentials
    datastore_info["storage_type"] = datastore.type
    datastore_info["storage_account"] = datastore.account_name
    datastore_info["container_name"] = str(
        datastore.container_name if datastore.type == DatastoreType.AZURE_BLOB else datastore.file_share_name
    )
    datastore_info["account_url"] = STORAGE_ACCOUNT_URLS[datastore.type].format(datastore.account_name)
    if isinstance(credentials, AccountKeyCredentials):
        datastore_info["credential"] = credentials.account_key
    else:
        datastore_info["credential"] = credentials.sas_token
    return datastore_info


def list_logs_in_datastore(ds_info: Dict[str, str], blob_prefix: str, legacy_log_folder_name: str) -> Dict[str, str]:
    """
    Returns a dictionary of file name to blob uri with SAS token, matching the structure of RunDetials.logFiles

    legacy_log_folder_name: the name of the folder in the datastore that contains the logs
        /azureml-logs/*.txt is the legacy log structure for commandJob and sweepJob
        /logs/azureml/*.txt is the legacy log structure for pipeline parent Job
    """
    # Only support blob storage for azureml log outputs
    if ds_info["storage_type"] != DatastoreType.AZURE_BLOB:
        raise Exception("Can only list logs in blob storage")
    storage_client = get_storage_client(
        credential=ds_info["credential"],
        container_name=ds_info["container_name"],
        storage_account=ds_info["storage_account"],
        storage_type=ds_info["storage_type"],
    )
    blobs = storage_client.list(starts_with=blob_prefix + "/user_logs/")
    # Append legacy log files if present
    blobs.extend(storage_client.list(starts_with=blob_prefix + legacy_log_folder_name))

    log_dict = {}
    for blob_name in blobs:
        sub_name = blob_name.split(blob_prefix + "/")[1]
        token = generate_blob_sas(
            account_name=ds_info["storage_account"],
            container_name=ds_info["container_name"],
            blob_name=blob_name,
            account_key=ds_info["credential"],
            permission=BlobSasPermissions(read=True),
            expiry=datetime.utcnow() + timedelta(minutes=30),
        )

        log_dict[sub_name] = "{}/{}/{}?{}".format(ds_info["account_url"], ds_info["container_name"], blob_name, token)
    return log_dict


def _get_default_datastore_info(datastore_operation):
    return get_datastore_info(datastore_operation, None)


def upload_artifact(
    local_path: str,
    datastore_operation: DatastoreOperations,
    workspace_scope: WorkspaceScope,
    datastore_name: Optional[str],
    asset_hash: str = None,
    show_progress: bool = True,
    asset_name: str = None,
    asset_version: str = None,
    ignore_file: IgnoreFile = IgnoreFile(None),
) -> ArtifactStorageInfo:
    """
    Upload local file or directory to datastore
    """
    datastore_name = _get_datastore_name(datastore_operation, datastore_name)
    datastore_info = get_datastore_info(datastore_operation, datastore_name)
    storage_client = get_storage_client(**datastore_info)
    artifact_info = storage_client.upload(
        local_path,
        asset_hash=asset_hash,
        show_progress=show_progress,
        name=asset_name,
        version=asset_version,
        ignore_file=ignore_file,
    )

    artifact = ArtifactStorageInfo(
        name=artifact_info["name"],
        version=artifact_info["version"],
        relative_path=artifact_info["remote path"],
        datastore_arm_id=get_datastore_arm_id(datastore_name, workspace_scope),
        container_name=datastore_info["container_name"],
        storage_account_url=datastore_info.get("account_url"),
        indicator_file=artifact_info["indicator file"],
        is_file=Path(local_path).is_file(),
    )
    return artifact


def download_artifact(
    starts_with: os.PathLike,
    destination: str,
    datastore_operation: DatastoreOperations,
    datastore_name: Optional[str],
    datastore_info: Dict = None,
) -> str:
    """
    Download datastore path to local file or directory.
    """
    starts_with = starts_with.as_posix() if isinstance(starts_with, Path) else starts_with
    datastore_name = _get_datastore_name(datastore_operation, datastore_name)
    if datastore_info is None:
        datastore_info = get_datastore_info(datastore_operation, datastore_name)
    storage_client = get_storage_client(**datastore_info)
    storage_client.download(starts_with=starts_with, destination=destination)
    return str(Path(destination, starts_with))


def download_artifact_from_blob_url(
    blob_url: str,
    destination: str,
    datastore_operation: DatastoreOperations,
    datastore_name: Optional[str],
) -> str:
    """
    Download datastore blob URL to local file or directory.
    """
    datastore_name = _get_datastore_name(datastore_operation, datastore_name)
    datastore_info = get_datastore_info(datastore_operation, datastore_name)
    starts_with = get_artifact_path_from_blob_url(
        blob_url=str(blob_url), container_name=datastore_info.get("container_name")
    )
    return download_artifact(
        starts_with=starts_with,
        destination=destination,
        datastore_operation=datastore_operation,
        datastore_name=datastore_name,
        datastore_info=datastore_info,
    )


def _upload_to_datastore(
    workspace_scope: WorkspaceScope,
    datastore_operation: DatastoreOperations,
    path: Union[str, Path, os.PathLike],
    datastore_name: str = None,
    show_progress: bool = True,
    asset_name: str = None,
    asset_version: str = None,
) -> ArtifactStorageInfo:
    _validate_path(path)
    ignore_file = get_ignore_file(path)
    asset_hash = get_object_hash(path, ignore_file)
    artifact = upload_artifact(
        str(path),
        datastore_operation,
        workspace_scope,
        datastore_name,
        show_progress=show_progress,
        asset_hash=asset_hash,
        asset_name=asset_name,
        asset_version=asset_version,
        ignore_file=ignore_file,
    )
    return artifact


def _update_metadata(name, version, indicator_file, datastore_info) -> None:
    storage_client = get_storage_client(**datastore_info)
    container_client = storage_client.container_client
    if indicator_file.startswith(storage_client.container):
        indicator_file = indicator_file.split(storage_client.container)[1]
    blob = container_client.get_blob_client(blob=indicator_file)
    blob.set_blob_metadata(_build_metadata_dict(name=name, version=version))


def _check_and_upload_path(
    artifact: Artifact,
    asset_operations: Union["DatasetOperations", "DataOperations", "ModelOperations", "CodeOperations"],
    datastore_name: str = None,
) -> Tuple[Artifact, str]:
    indicator_file = None
    if artifact.local_path:
        path = Path(artifact.local_path)
        if not path.is_absolute():
            path = Path(artifact.base_path, path).resolve()
        uploaded_artifact = _upload_to_datastore(
            asset_operations._workspace_scope,
            asset_operations._datastore_operation,
            path,
            datastore_name=datastore_name,
            asset_name=artifact.name,
            asset_version=str(artifact.version),
        )
        indicator_file = uploaded_artifact.indicator_file  # reference to storage contents
        if artifact._is_anonymous:
            artifact.name, artifact.version = uploaded_artifact.name, uploaded_artifact.version
        # Pass all of the upload information to the assets, and they will each construct the URLs that they support
        artifact._update_path(uploaded_artifact)
    return artifact, indicator_file


def _check_and_upload_env_build_context(environment: Environment, operations: "EnvironmentOperations") -> Environment:
    if environment.build and environment.build.local_path:
        path = Path(environment.build.local_path)
        if not path.is_absolute():
            path = Path(environment.base_path, path).resolve()
        uploaded_artifact = _upload_to_datastore(
            operations._workspace_scope,
            operations._datastore_operation,
            path,
            asset_name=environment.name,
            asset_version=str(environment.version),
        )
        # TODO: Depending on decision trailing "/" needs to stay or not. EMS requires it to be present
        environment.build.context_uri = uploaded_artifact.full_storage_path + "/"

    return environment
