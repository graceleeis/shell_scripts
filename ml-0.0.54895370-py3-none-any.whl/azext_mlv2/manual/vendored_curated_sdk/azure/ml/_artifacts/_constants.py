# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


CHUNK_SIZE = 1024
PROCESSES_PER_CORE = 2
MAX_CONCURRENCY = 16 # number of parallel connections to be used for uploads > 64MB and downloads (Azure Storage param: https://docs.microsoft.com/en-us/python/api/azure-storage-blob/azure.storage.blob.blobclient?view=azure-python#upload-blob-data--blob-type--blobtype-blockblob---blockblob----length-none--metadata-none----kwargs-)

ARTIFACT_ORIGIN = "LocalUpload"
LEGACY_ARTIFACT_DIRECTORY = "az-ml-artifacts"
UPLOAD_CONFIRMATION = {"upload_status": "completed"}

HASH_ALGORITHM_NAME = "md5"
AML_IGNORE_FILE_NAME = ".amlignore"
GIT_IGNORE_FILE_NAME = ".gitignore"

ASSET_PATH_ERROR = "(UserError) Asset paths cannot be updated."
CHANGED_ASSET_PATH_MSG = (
    "The code asset {name}:{version} is already linked to an asset "
    "in your datastore that does not match the content from your `directory` param "
    "and cannot be overwritten. Please provide a unique name or version "
    "to successfully create a new code asset."
)
EMPTY_DIRECTORY_ERROR = "Directory {0} is empty. local_path must be a non-empty directory."
