# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from ._common_params import add_common_params, add_override_param, add_lro_param


def add_batch_deployment_common_param(
    c,
    name_help_message="Name of the deployment.",
):
    c.argument("name", options_list=["--name", "-n"], help=name_help_message)
    c.argument(
        "endpoint_name",
        options_list=["--endpoint-name", "-e"],
        help="Name of the batch endpoint",
    )


def load_batch_deployment_params(self):
    with self.argument_context("ml batch-deployment create") as c:
        add_common_params(c)
        add_batch_deployment_common_param(c)
        add_lro_param(c)
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML deployment specification.",
        )
        c.argument(
            "set_default",
            help="Sets endpoint defaults.deployment_name to this deployment after successful creation, does not work with --no-wait",
        )
        add_override_param(c)

    with self.argument_context("ml batch-deployment delete") as c:
        add_common_params(c)
        add_batch_deployment_common_param(c)
        add_lro_param(c)

    with self.argument_context("ml batch-deployment show") as c:
        add_common_params(c)
        add_batch_deployment_common_param(c)

    with self.argument_context("ml batch-deployment list") as c:
        add_common_params(c)
        add_batch_deployment_common_param(c)
        c.argument(
            "endpoint_name",
            options_list=["--endpoint-name", "-e"],
            help="Name of the endpoint",
        )
    with self.argument_context("ml batch-deployment list-jobs") as c:
        add_common_params(c)
        add_batch_deployment_common_param(c)

    with self.argument_context("ml batch-deployment update") as c:
        add_common_params(c)
        add_batch_deployment_common_param(c)
        add_lro_param(c)
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML deployment specification.",
        )
        add_override_param(c)
