# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import (
    add_common_params,
    add_override_param,
    add_max_results_params,
    add_tags_param,
    add_description_param,
)


def load_model_params(self):
    with self.argument_context("ml model create") as c:
        add_common_params(c)
        add_override_param(c)
        add_tags_param(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the model.")
        c.argument("version", options_list=["--version", "-v"], help="Version of the model.")
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML model specification. --name/-n and --version/-v must be provided if YAML file does not have name and version.",
        )
        c.argument(
            "local_path",
            options_list=["--local-path", "-l"],
            help="Path to the model file(s). This can be either a file or a directory. If specified, --name/-n and --version/-v must also be provided.",
        )
        c.argument(
            "model_uri",
            options_list=["--model-uri", "-p"],
            help="Path of model in supported URI formats to create the model. Examples: 'folder:azureml://datastores/mydatastore/paths/path_to_model/', 'file:azureml://datastores/mydatastore/paths/path_to_model/myfile.csv'",
        )
        add_description_param(c)

    with self.argument_context("ml model show") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the model.")
        c.argument(
            "version",
            options_list=["--version", "-v"],
            help="Version of the model.",
        )

    with self.argument_context("ml model list") as c:
        add_common_params(c)
        c.argument(
            "name",
            options_list=["--name", "-n"],
            help="Name of the model. If provided, all the model versions under this name will be returned.",
        )
        add_max_results_params(c)

    with self.argument_context("ml model update") as c:
        add_common_params(c)
        add_override_param(c)
        c.argument("name", options_list=["--name", "-n"], help="Name of the model.")
        c.argument("version", options_list=["--version", "-v"], help="Version of the model.")
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML model specification.",
        )
        c.argument(
            "local_path",
            options_list=["--local-path", "-l"],
            help="Path to the model file(s). This can be either a file or a directory.",
        )
        add_description_param(c)

    with self.argument_context("ml model delete") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], help="Name of the model.")
        c.argument("version", options_list=["--version", "-v"], help="Version of the model.")
