# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azext_mlv2.manual.version import VERSION

USER_AGENT = "{}/{}".format("azureml-cli-v2", VERSION)
