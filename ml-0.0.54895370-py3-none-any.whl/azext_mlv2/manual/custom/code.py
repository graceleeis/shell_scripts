# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.cli.core.commands.client_factory import get_subscription_id

from .raise_error import log_and_raise_error
from .utils import _is_debug_set, _dump_entity_with_warnings, get_ml_client


def ml_code_show(cmd, resource_group_name, workspace_name, name, version):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        code = ml_client.code.get(name=name, version=version)
        return _dump_entity_with_warnings(code)
    except Exception as err:
        log_and_raise_error(err, debug)
