# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import OnlineDeployment as Deployment
from .raise_error import log_and_raise_error
from .utils import _is_debug_set, get_ml_client, _dump_entity_with_warnings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import EndpointGetLogsFields


def ml_online_deployment_create(
    cmd,
    resource_group_name,
    workspace_name,
    file,
    endpoint_name=None,
    name=None,
    local=False,
    vscode_debug=False,
    no_wait=False,
    all_traffic=False,
    params_override=None,
    **kwargs
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    params_override = params_override or []
    try:
        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        if name:
            params_override.append({"name": name})
        if endpoint_name:
            params_override.append({"endpoint_name": endpoint_name})
        deployment = Deployment.load(path=file, params_override=params_override)
        ml_client.begin_create_or_update(deployment, local=local, vscode_debug=vscode_debug, no_wait=no_wait)

        if all_traffic:
            endpoint = ml_client.online_endpoints.get(deployment.endpoint_name, local=local)
            endpoint.traffic = {deployment.name: 100}
            endpoint = ml_client.begin_create_or_update(endpoint, local=local)
        return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_deployment_update(
    cmd,
    resource_group_name,
    workspace_name,
    local=False,
    vscode_debug=False,
    no_wait=False,
    parameters: Dict = None,
):
    """
    The update does not need to take parameters like `endpoint_name` and `file` because it's been
    preprocessed by the `_ml_online_deployment_merge` function as a prestep defined generic_update_commands.

    See here for more information: https://github.com/Azure/azure-cli/blob/master/doc/authoring_command_modules/authoring_commands.md#generic-update-commands
    """
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        deployment = Deployment.load_from_dict(data=parameters)
        deployment = ml_client.begin_create_or_update(
            deployment, local=local, vscode_debug=vscode_debug, no_wait=no_wait
        )
        if deployment:  # TODO: https://msdata.visualstudio.com/Vienna/_workitems/edit/1252491/
            return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_deployment_show(cmd, resource_group_name, workspace_name, name, endpoint_name, local=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        deployment = ml_client.online_deployments.get(name, endpoint_name, local)
        return _dump_entity_with_warnings(deployment)
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_online_deployment_show(
    cmd, resource_group_name, workspace_name, name=None, endpoint_name=None, file=None, local=False
):
    params_override = []
    if name:
        params_override.append({"name": name})

    if endpoint_name:
        params_override.append({"endpoint_name": endpoint_name})
    if file:
        deployment = Deployment.load(file, params_override=params_override)
        return ml_online_deployment_show(
            cmd, resource_group_name, workspace_name, deployment.name, deployment.endpoint_name, local
        )
    else:
        return ml_online_deployment_show(cmd, resource_group_name, workspace_name, name, endpoint_name, local)


def _ml_online_deployment_merge(instance, name=None, endpoint_name=None, file=None, local: bool = False):
    """
    instance is what `ml_online_deployment_show` returns it is of Type Dict

    The purpose of this function is to merge the raw instance with file.
    The merging logic is that whatever resides in file overrides instance.
    """
    deployment = Deployment.load_from_dict(instance)
    if file:
        if local:
            deployment._merge_with(
                Deployment.load(
                    file,
                    params_override=[{"name": instance.get("name")}, {"endpoint_name": instance.get("endpoint_name")}],
                )
            )
        else:
            deployment._merge_with(
                Deployment.load(
                    file,
                    params_override=[{"name": instance.get("name")}, {"endpoint_name": instance.get("endpoint_name")}],
                )
            )
    instance = _dump_entity_with_warnings(deployment)
    return instance


def ml_online_deployment_delete(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    endpoint_name,
    local: bool = False,
    no_wait=False,
):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        return ml_client.online_deployments.delete(name, endpoint_name, local)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_deployment_list(cmd, resource_group_name, workspace_name, endpoint_name, local: bool = False):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        return list(
            map(
                lambda deployment: _dump_entity_with_warnings(deployment),
                ml_client.online_deployments.list(endpoint_name, local),
            )
        )
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_deployment_get_logs(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    endpoint_name,
    lines=EndpointGetLogsFields.LINES,
    container=None,
    local: bool = False,
):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)
        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        logs = ml_client.online_deployments.get_logs(name, endpoint_name, lines, container, local=local)
        print(logs.replace("\\n", "\n"))
    except Exception as err:
        log_and_raise_error(err, debug)
