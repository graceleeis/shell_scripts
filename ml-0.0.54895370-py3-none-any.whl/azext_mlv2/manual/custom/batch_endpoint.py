# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import time
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._util import load_from_dict
from azure.core.exceptions import ResourceNotFoundError
from azure.cli.core.commands.client_factory import get_subscription_id
from .dataset import ml_dataset_create
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import (
    EndpointYamlFields,
)

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import (
    Endpoint,
    BatchEndpoint,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Data
from .raise_error import log_and_raise_error
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import remove_aml_prefix
from .utils import _is_debug_set, get_ml_client, validate_and_split_output_path, convert_str_to_dict


def ml_batch_endpoint_show(cmd, resource_group_name, workspace_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        endpoint = ml_client.batch_endpoints.get(name=name)
        return endpoint.dump()
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_batch_endpoint_show(cmd, resource_group_name, workspace_name, name=None, file=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        if not name:
            endpoint = BatchEndpoint.load(path=file)
            name = endpoint.name
        return ml_client.batch_endpoints.get(name=name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_endpoint_create(
    cmd, resource_group_name, workspace_name, file=None, name=None, no_wait=False, params_override=None, **kwargs
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    params_override = params_override or []
    try:
        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        if name:
            # MFE is case-insensitive for Name. So convert the name into lower case here.
            params_override.append({"name": name.lower()})
        endpoint = BatchEndpoint.load(path=file, params_override=params_override)
        endpoint = ml_client.begin_create_or_update(endpoint, no_wait=no_wait)
        if isinstance(endpoint, BatchEndpoint):
            return endpoint.dump()
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_endpoint_delete(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    no_wait=False,
):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        return ml_client.batch_endpoints.begin_delete(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_endpoint_list(cmd, resource_group_name, workspace_name):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        return ml_client.batch_endpoints.list()
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_endpoint_update(
    cmd,
    resource_group_name,
    workspace_name,
    defaults=None,
    name=None,
    file=None,
    no_wait=False,
    parameters=None,
    **kwargs,
) -> None:
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )

        if name:
            parameters.name = name

        if file:
            loaded_endpoint = BatchEndpoint.load(file)
            loaded_endpoint.name = parameters.name
            parameters._merge_with(loaded_endpoint)

        if defaults and isinstance(defaults, str):
            defaults = convert_str_to_dict(defaults)
            parameters.defaults = defaults

        endpoint_return = ml_client.begin_create_or_update(
            entity=parameters,
            no_wait=no_wait,
        )

        if isinstance(endpoint_return, Endpoint):
            return endpoint_return.dump()
        else:
            return endpoint_return

    except Exception as err:
        log_and_raise_error(err, debug)


def ml_batch_endpoint_invoke(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    batch_deployment_name=None,
    input_dataset=None,
    input_path=None,  # --input-path dir:azureml://datastores/<datastore-name>/<path-on-datastore>
    input_local_path=None,
    output_path=None,  # --output-path dir:azureml://datastores/<datastore-name>/<path-on-datastore>
    job_name=None,
    mini_batch_size=None,
    instance_count=None,
    params_override=None,
) -> str:
    debug = _is_debug_set(cmd.cli_ctx)
    params_override = params_override or []
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)
        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        if batch_deployment_name:
            ml_client.batch_endpoints._validate_deployment_name(name, batch_deployment_name)
        input_data_asset = None

        input_dataset = remove_aml_prefix(input_dataset)

        data_name = "{}_input_data_{}".format(name, round(time.time()))
        input_data_asset = input_dataset or ml_dataset_create(
            cmd=cmd,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            paths=input_path,
            local_path=input_local_path,
            no_dump=True,
        )

        if mini_batch_size:
            params_override.append({EndpointYamlFields.MINI_BATCH_SIZE: mini_batch_size})
        if instance_count:
            params_override.append({EndpointYamlFields.BATCH_JOB_INSTANCE_COUNT: instance_count})
        if output_path:
            output = validate_and_split_output_path(output_path)  # This is until the API is ready
            params_override.append({EndpointYamlFields.BATCH_JOB_OUTPUT_PATH: output.path})
            params_override.append({EndpointYamlFields.BATCH_JOB_OUTPUT_DATSTORE: "azureml:" + output.datastore})
        if job_name:
            params_override.append({EndpointYamlFields.BATCH_JOB_NAME: job_name})

        kwargs = {
            "logging_enable": debug,
        }

        return ml_client.batch_endpoints.invoke(
            endpoint_name=name,
            input_data=input_data_asset,
            deployment_name=batch_deployment_name,
            params_override=params_override,
            **kwargs,
        )
    except Exception as err:
        # Bug for service side fix: https://msdata.visualstudio.com/Vienna/_workitems/edit/1413104
        # Once service throws correct exception we will remove this exception handling.
        if isinstance(err, ResourceNotFoundError) and batch_deployment_name is None:
            log_and_raise_error(f"Set a default deployment or provide a deployment name through cli command.")
        else:
            log_and_raise_error(err, debug)


def ml_batch_endpoint_list_jobs(cmd, resource_group_name, workspace_name, name):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)
        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )

        return ml_client.batch_endpoints.list_jobs(endpoint_name=name)
    except Exception as err:
        log_and_raise_error(err, debug)
