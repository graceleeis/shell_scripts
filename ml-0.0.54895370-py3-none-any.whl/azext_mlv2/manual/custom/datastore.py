# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from itertools import islice

from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Datastore
from azure.cli.core.commands.client_factory import get_subscription_id
from .utils import _is_debug_set, get_ml_client, _dump_entity_with_warnings
from .raise_error import log_and_raise_error


def ml_datastore_delete(cmd, resource_group_name, workspace_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.datastores.delete(name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_datastore_show(cmd, resource_group_name, workspace_name, name, include_secrets=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.datastores.get(name, include_secrets=include_secrets)._to_dict()
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_datastore_show(cmd, resource_group_name, workspace_name, file=None, name=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    try:
        if file:
            params_override = []
            if name:
                params_override = [{"name": name}]
            return Datastore.load(file, params_override=params_override)._to_dict()
        else:
            return ml_datastore_show(cmd, resource_group_name, workspace_name, name)
    except Exception as err:
        log_and_raise_error(err)


def ml_datastore_list(cmd, resource_group_name, workspace_name, include_secrets=False, max_results=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        if max_results:
            results = islice(ml_client.datastores.list(include_secrets=include_secrets), int(max_results))
        else:
            results = ml_client.datastores.list(include_secrets=include_secrets)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_datastore_create(cmd, resource_group_name, workspace_name, file, name=None, params_override=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    params_override = params_override or []
    if name:
        params_override.append({"name": name})

    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        datastore = Datastore.load(file, params_override=params_override)
        return ml_client.create_or_update(datastore)._to_dict()
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_datastore_update(cmd, resource_group_name, workspace_name, parameters: Dict):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        datastore = Datastore._load(parameters)
        return ml_client.create_or_update(datastore)._to_dict()
    except Exception as err:
        log_and_raise_error(err, debug)
