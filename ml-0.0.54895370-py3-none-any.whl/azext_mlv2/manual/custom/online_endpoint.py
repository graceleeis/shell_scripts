# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import EndpointKeyType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import load_yaml
import logging
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import (
    Endpoint,
    OnlineEndpoint,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Data
from .raise_error import log_and_raise_error
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import remove_aml_prefix
from .utils import _is_debug_set, get_ml_client, reset_anonymous_asset, convert_str_to_dict

module_logger = logging.getLogger(__name__)


def ml_online_endpoint_show(cmd, resource_group_name, workspace_name, name, local: bool = False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        endpoint = ml_client.online_endpoints.get(name=name, local=local)

        return endpoint.dump()
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_online_endpoint_show(cmd, resource_group_name, workspace_name, name=None, file=None, local=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        if not name:
            endpoint = OnlineEndpoint.load(path=file)
            name = endpoint.name
        return ml_client.online_endpoints.get(name=name, local=local)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_create(
    cmd,
    resource_group_name,
    workspace_name,
    auth_mode=None,
    file=None,
    name=None,
    local: bool = False,
    no_wait=False,
    params_override=None,
    **kwargs,
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    params_override = params_override or []
    try:
        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        if name:
            # MFE is case-insensitive for Name. So convert the name into lower case here.
            params_override.append({"name": name.lower()})
        if auth_mode:
            params_override.append({"auth_mode": auth_mode.lower()})

        endpoint = OnlineEndpoint.load(path=file, params_override=params_override)
        endpoint = ml_client.begin_create_or_update(endpoint, local=local, no_wait=no_wait)
        if isinstance(endpoint, OnlineEndpoint):
            return endpoint.dump()
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_delete(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    local: bool = False,
    no_wait=False,
):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        if no_wait:
            module_logger.info(
                f"Delete request initiated. Status can be checked using `az ml online-endpoint show -n {name}`\n"
            )
        return ml_client.online_endpoints.begin_delete(name=name, local=local, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_get_credentials(cmd, resource_group_name, workspace_name, name):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        return ml_client.online_endpoints.list_keys(name=name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_list(cmd, resource_group_name, workspace_name, local: bool = False):
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        return ml_client.online_endpoints.list(local=local)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_update(
    cmd,
    resource_group_name,
    workspace_name,
    traffic=None,
    name=None,
    file=None,
    parameters=None,
    local=False,
    no_wait=False,
    **kwargs,
) -> None:
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)

        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )

        if name:
            parameters.name = name

        if file:
            loaded_endpoint = OnlineEndpoint.load(file)
            loaded_endpoint.name = parameters.name
            parameters._merge_with(loaded_endpoint)

        if traffic and isinstance(traffic, str):
            traffic = convert_str_to_dict(traffic)
            parameters.traffic = traffic

        endpoint_return = ml_client.begin_create_or_update(
            entity=parameters,
            local=local,
            no_wait=no_wait,
        )

        if isinstance(endpoint_return, Endpoint):
            return endpoint_return.dump()
        else:
            return endpoint_return

    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_invoke(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    request_file=None,
    online_deployment_name=None,
    local: bool = False,
) -> str:
    debug = _is_debug_set(cmd.cli_ctx)
    try:
        subscription_id = get_subscription_id(cmd.cli_ctx)
        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        input_data_asset = None

        kwargs = {
            "logging_enable": debug,
        }

        return ml_client.online_endpoints.invoke(
            endpoint_name=name,
            request_file=request_file,
            input_data=input_data_asset,
            deployment_name=online_deployment_name,
            local=local,
            **kwargs,
        )
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_online_endpoint_regenerate_keys(
    cmd, resource_group_name, workspace_name, name, key_type=EndpointKeyType.PRIMARY_KEY_TYPE, no_wait: bool = False
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)

    try:
        ml_client = get_ml_client(
            subscription_id=subscription_id,
            resource_group_name=resource_group_name,
            workspace_name=workspace_name,
            debug=debug,
            cli_ctx=cmd.cli_ctx,
        )
        return ml_client.online_endpoints.begin_regenerate_keys(name=name, key_type=key_type, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)
