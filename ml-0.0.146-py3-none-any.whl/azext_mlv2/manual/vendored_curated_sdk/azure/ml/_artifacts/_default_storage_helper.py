# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import uuid
import logging
from contextlib import suppress
import time
import os
from typing import Optional, Dict, Any, List
from pathlib import PurePosixPath, Path
from functools import partial
from multiprocessing.pool import ThreadPool
from multiprocessing import cpu_count

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._exception_utils import EmptyDirectoryError
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceNotFoundError
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._asset_utils import (
    generate_asset_id,
    traverse_directory,
    AssetNotChangedError,
    _build_metadata_dict,
    IgnoreFile,
    FileUploadProgressBar,
    DirectoryUploadProgressBar,
    get_directory_size,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._constants import (
    UPLOAD_CONFIRMATION,
    ARTIFACT_ORIGIN,
    LEGACY_ARTIFACT_DIRECTORY,
    EMPTY_DIRECTORY_ERROR,
    PROCESSES_PER_CORE,
    MAX_CONCURRENCY,
)

module_logger = logging.getLogger(__name__)


class DefaultStorageClient:
    def __init__(self, credential: str, container_name: str, account_url: str):
        self.service_client = BlobServiceClient(account_url=account_url, credential=credential)
        self.container_client = self.service_client.get_container_client(container=container_name)
        self.container = container_name
        self.total_file_count = 1
        self.uploaded_file_count = 0
        self.overwrite = False
        self.indicator_file = None
        self.legacy = False
        self.name = None
        self.version = None

    def upload(
        self,
        source: str,
        name: str,
        version: str,
        ignore_file: IgnoreFile = IgnoreFile(None),
        asset_hash: str = None,
        show_progress: bool = True,
    ) -> Dict[str, str]:
        """
        Upload a file or directory to a path inside the container
        """
        if name and version is None:
            version = str(uuid.uuid4())  # placeholder for auto-increment artifacts

        asset_id = generate_asset_id(asset_hash, include_directory=True)
        source_name = Path(source).name
        dest = str(PurePosixPath(asset_id, source_name))

        try:
            # truncate path longer than 50 chars for terminal display
            if show_progress and len(source_name) >= 50:
                formatted_path = "{:.47}".format(source_name) + "..."
            else:
                formatted_path = source_name
            msg = f"Uploading {formatted_path}"

            if os.path.isdir(source):
                self.upload_dir(source, asset_id, msg, show_progress, ignore_file=ignore_file)
            else:
                self.indicator_file = dest
                self.check_blob_exists()
                self.upload_file(source, dest, msg, show_progress)

            # upload must be completed before we try to generate confirmation file
            while self.uploaded_file_count < self.total_file_count:
                time.sleep(0.5)
            self._set_confirmation_metadata(name, version)
        except AssetNotChangedError:
            name = self.name
            version = self.version
            if self.legacy:
                dest = dest.replace(ARTIFACT_ORIGIN, LEGACY_ARTIFACT_DIRECTORY)

        module_logger.info(f"DefaultStorageClient: name - {name}, self.name = {self.name}")
        artifact_info = {"remote path": dest, "name": name, "version": version, "indicator file": self.indicator_file}

        return artifact_info

    def upload_file(
        self,
        source: str,
        dest: str,
        msg: Optional[str] = None,
        show_progress: Optional[bool] = None,
        in_directory: bool = False,
        callback: Any = None,
    ) -> None:
        """ "
        Upload a single file to a path inside the container
        """
        validate_content = os.stat(source).st_size > 0  # don't do checksum for empty files

        with open(source, "rb") as data:
            cntx_manager = FileUploadProgressBar(msg=msg) if (show_progress and not in_directory) else suppress()
            with cntx_manager as c:
                callback = c.update_to if (show_progress and not in_directory) else None
                self.container_client.upload_blob(
                    name=dest,
                    data=data,
                    validate_content=validate_content,
                    overwrite=self.overwrite,
                    raw_response_hook=callback,
                    max_concurrency=MAX_CONCURRENCY,
                )

        self.uploaded_file_count += 1

    def upload_dir(self, source: str, dest: str, msg: str, show_progress: bool, ignore_file: IgnoreFile) -> None:
        """
        Upload a directory to a path inside the container

        Azure Blob doesn't allow metadata setting at the directory level, so the first
        file in the directory is designated as the file where the confirmation metadata
        will be added at the end of the upload.
        """
        source_path = Path(source).resolve()
        prefix = "" if dest == "" else dest + "/"
        prefix += os.path.basename(source_path) + "/"

        upload_paths = []
        for root, _, files in os.walk(source_path):
            upload_paths += list(traverse_directory(root, files, source_path, prefix, ignore_file=ignore_file))

        upload_paths = sorted(upload_paths)
        if len(upload_paths) == 0:
            raise EmptyDirectoryError(EMPTY_DIRECTORY_ERROR.format(source))

        self.indicator_file = upload_paths[0][1]
        self.check_blob_exists()

        self.total_file_count = len(upload_paths)

        cntx_manager = (
            DirectoryUploadProgressBar(dir_size=get_directory_size(source_path), msg=msg)
            if show_progress
            else suppress()
        )
        with cntx_manager as c:
            callback = c.update_to if show_progress else None
            num_cores = int(cpu_count()) * PROCESSES_PER_CORE
            with ThreadPool(processes=num_cores) as pool:
                func = partial(self._upload_file_helper, show_progress=show_progress, callback=callback)
                return pool.map(func, upload_paths)

    def _upload_file_helper(self, upload_path, show_progress, callback):
        src, dest = upload_path[0], upload_path[1]
        self.upload_file(src, dest, in_directory=True, show_progress=show_progress, callback=callback)

    def check_blob_exists(self) -> None:
        """
        Throw error if blob already exists.

        Check if blob already exists in container by checking the metadata for
        existence and confirmation data. If confirmation data is missing, blob does not exist
        or was only partially uploaded and the partial upload will be overwritten with a complete
        upload.
        """

        try:
            legacy_indicator_file = self.indicator_file.replace(ARTIFACT_ORIGIN, LEGACY_ARTIFACT_DIRECTORY)
            blob_client = self.container_client.get_blob_client(blob=self.indicator_file)
            legacy_blob_client = self.container_client.get_blob_client(blob=legacy_indicator_file)

            properties = blob_client.get_blob_properties()
            metadata = properties.get("metadata")

            # first check legacy folder's metadata to see if artifact is stored there
            try:
                legacy_properties = legacy_blob_client.get_blob_properties()
                legacy_metadata = legacy_properties.get("metadata")

                if (
                    legacy_metadata and UPLOAD_CONFIRMATION.items() <= legacy_metadata.items()
                ):  # checks if metadata dictionary includes confirmation key and value
                    self.name = legacy_metadata.get("name")
                    self.version = legacy_metadata.get("version")
                    self.legacy = True

                    raise AssetNotChangedError
            except ResourceNotFoundError:
                pass

            # check LocalUpload folder's metadata if not found in legacy metadata
            if metadata and UPLOAD_CONFIRMATION.items() <= metadata.items():
                self.name = metadata.get("name")
                self.version = metadata.get("version")
                raise AssetNotChangedError
            else:
                self.overwrite = True  # if upload never confirmed, approve overriding the partial upload
        except ResourceNotFoundError:
            pass
        except Exception as e:
            raise e

    def _set_confirmation_metadata(self, name: str, version: str) -> None:
        blob_client = self.container_client.get_blob_client(blob=self.indicator_file)
        metadata_dict = _build_metadata_dict(name, version)
        blob_client.set_blob_metadata(metadata_dict)

    def download(
        self, starts_with: str, destination: str = Path.home(), max_concurrency: int = MAX_CONCURRENCY
    ) -> None:
        """
        Downloads all blobs inside a specified container
        :param starts_with: Indicates the blob name starts with to search.
        :param destination: Indicates path to download in local
        :param max_concurrency: Indicates concurrent connections to download a blob.
        :return: The status object.
        """
        try:
            mylist = self.container_client.list_blobs(name_starts_with=starts_with)
            split_dir_name = starts_with.split("dcid.")
            dir_name = split_dir_name[0] if len(split_dir_name) == 1 else split_dir_name[1]
            for item in mylist:
                blob_name = item.name.replace(starts_with, "").lstrip("//")
                blob_content = self.container_client.download_blob(item)
                blob_content = blob_content.content_as_bytes(MAX_CONCURRENCY)
                target_path = os.path.join(Path(destination, dir_name), Path(blob_name))
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                with open(target_path, "wb") as file:
                    file.write(blob_content)
        except OSError as ex:
            raise ex
        except Exception as e:
            raise Exception(f"Saving blob with prefix {starts_with} was unsuccessful. exception={e}")

    def list(self, starts_with: str) -> List[str]:
        """
        Lists all blob names in the specified container
        :param starts_with: Indicates the blob name starts with to search.
        :return: the list of blob paths in container
        """
        blobs = self.container_client.list_blobs(name_starts_with=starts_with)
        return [blob.name for blob in blobs]
