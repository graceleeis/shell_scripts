# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import json
import logging
from os import PathLike, getenv
from os.path import sep
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Union
from multiprocessing.pool import ThreadPool
from multiprocessing import cpu_count
from functools import partial
from itertools import chain

try:
    from typing import Protocol  # For python >= 3.8
except ImportError:
    from typing_extensions import Protocol  # For python < 3.8

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import PipelineConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.job_errors import JobParsingError

import jwt
from azure.identity import ChainedTokenCredential
from azure.core.exceptions import HttpResponseError

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations.run_history_constants import RunHistoryConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01 import (
    AzureMachineLearningWorkspaces as ServiceClient102021,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import JobBaseResource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2020_09_01_preview import (
    AzureMachineLearningWorkspaces as ServiceClient092020Preview,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2020_09_01_preview.models import (
    JobType as RestJobType,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.runhistory import (
    AzureMachineLearningWorkspaces as ServiceClientRunHistory,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._storage_utils import get_storage_client
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import create_session_with_retry, download_text_from_url
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import OperationsContainer, WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import (
    AzureMLResourceType,
    TID_FMT,
    DEFAULT_SCOPES,
    AZUREML_PRIVATE_FEATURES_ENV_VAR,
    BASE_PATH_CONTEXT_KEY,
    AZUREML_RESOURCE_PROVIDER,
    LEVEL_ONE_NAMED_RESOURCE_ID_FORMAT,
    LOCAL_COMPUTE_TARGET,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import (
    AutoMLJob,
    CommandJob,
    Job,
    SweepJob,
    PipelineJob,
    Component,
    CommandComponent,
    InputOutputEntry,
    InputDatasetEntry,
    _BaseJob,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.pipeline.component_job import ComponentJob
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.pipeline.pipeline_job_settings import PipelineJobSettings
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._constants import PROCESSES_PER_CORE
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import modified_operation_client

from .job_ops_helper import get_git_properties, stream_logs_until_completion, get_children
from .local_job_invoker import is_local_run, start_run_if_local
from .operation_orchestrator import OperationOrchestrator
from .run_operations import RunOperations

module_logger = logging.getLogger(__name__)


class _JobLike(Protocol):
    """This protocol describes an object which can be translate to a job with object._to_job."""

    def _to_job(self, **kwargs) -> Job:
        """Build current object to a job object."""
        pass


class JobOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client_09_2020_preview: ServiceClient092020Preview,
        service_client_10_2021: ServiceClient102021,
        service_client_run_history: ServiceClientRunHistory,
        all_operations: OperationsContainer,
        credential: ChainedTokenCredential,
        **kwargs: Any,
    ):
        super(JobOperations, self).__init__(workspace_scope)
        self._operation_2020_09_preview = service_client_09_2020_preview.jobs
        self._operation_2021_10 = service_client_10_2021.jobs
        self._all_operations = all_operations
        self._kwargs = kwargs
        self._runs = RunOperations(workspace_scope, service_client_run_history)
        self._stream_logs_until_completion = stream_logs_until_completion
        self._container = "azureml"
        self._credential = credential
        self._orchestrators = OperationOrchestrator(self._all_operations, self._workspace_scope)

    def list(self) -> Iterable[Job]:
        """List jobs of the workspace.

        :return: An iterator like instance of Job objects
        :rtype: ~azure.core.paging.ItemPaged[Job]
        """
        if getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR):
            automl_jobs = self._operation_2020_09_preview.list(
                self._workspace_scope.resource_group_name,
                self._workspace_name,
                job_type=RestJobType.AUTO_ML,
                cls=lambda objs: [self._handle_rest_errors(obj) for obj in objs],
                **self._kwargs,
            )
            remainder_jobs = self._operation_2021_10.list(
                self._workspace_scope.resource_group_name,
                self._workspace_name,
                cls=lambda objs: [self._handle_rest_errors(obj) for obj in objs],
                **self._kwargs,
            )
            return chain(automl_jobs, remainder_jobs)
        else:
            return self._operation_2021_10.list(
                self._workspace_scope.resource_group_name,
                self._workspace_name,
                cls=lambda objs: [self._handle_rest_errors(obj) for obj in objs],
                **self._kwargs,
            )

    def _handle_rest_errors(self, job_object):
        """Handle errors while resolving azureml_id's during list operation"""
        try:
            return self._resolve_azureml_id(Job._from_rest_object(job_object))
        except JobParsingError:
            pass

    def get(self, name: str) -> Job:
        """Get a job resource.

        :param str name: Name of the job.
        :return: Job object retrieved from the service.
        :rtype: Job
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """
        job_object = self._get_job(name)
        job = Job._from_rest_object(job_object)
        if job_object.properties.job_type != RestJobType.AUTO_ML:
            # resolvers do not work with the old contract, leave the ids as is
            job = self._resolve_azureml_id(job)
        return job

    def cancel(self, name: str) -> None:
        """Cancel job resource.

        :param str name: Name of the job.
        :return: None, or the result of cls(response)
        :rtype: None
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """
        if getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR):
            return self._operation_2020_09_preview.cancel(
                id=name,
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                **self._kwargs,
            )
        else:
            return self._operation_2021_10.cancel(
                id=name,
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                **self._kwargs,
            )

    def create_or_update(
        self,
        job: Union[Job, _JobLike],
        *,
        description: str = None,
        compute: str = None,
        tags: dict = None,
        experiment_name: str = None,
        **kwargs,
    ) -> Job:
        """Create or update a job, if there're inline defined entities, e.g. Environment, Code, they'll be created together with the job.

        :param Job job: Job definition or object which can be translate to a job.
        :param description: Description to overwrite when submitting the pipeline.
        :type description: str
        :param compute: Compute target to overwrite when submitting the pipeline.
        :type compute: str
        :param tags: Tags to overwrite when submitting the pipeline.
        :type tags: dict
        :param experiment_name: Name of the experiment the job will be created under, if None is provided, job will be created under experiment 'Default'.
        :type experiment_name: str
        :return: Created or updated job.
        :rtype: Job
        """
        if not isinstance(job, Job):
            # For non-Job type instance, try to convert it to a job.
            try:
                job = job._to_job(**kwargs)
            except AttributeError as e:
                # If the job instance is not Job or _JobLike, raise error
                raise RuntimeError(f"Failed to parse {type(job)} to job.") from e

        # Set job properties before submission
        if description is not None:
            job.description = description
        if compute is not None:
            job.compute = compute
        if tags is not None:
            job.tags = tags
        if experiment_name is not None:
            job.experiment_name = experiment_name

        # Create all dependent resources
        self._resolve_arm_id_or_upload_dependencies(job)
        git_props = get_git_properties()
        # Do not add git props if they already exist in job properties.
        # This is for update specifically-- if the user switches branches and tries to update their job, the request will fail since the git props will be repopulated.
        # MFE does not allow existing properties to be updated, only for new props to be added
        if not any(prop_name in job.properties for prop_name in git_props.keys()):
            job.properties = {**job.properties, **git_props}

        rest_job_resource = job._to_rest_object()
        if getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR) and rest_job_resource.properties.job_type == RestJobType.AUTO_ML:
            try:
                result = self._operation_2020_09_preview.create_or_update(
                    id=rest_job_resource.name,  # type: ignore
                    resource_group_name=self._workspace_scope.resource_group_name,
                    workspace_name=self._workspace_name,
                    body=rest_job_resource,
                    **self._kwargs,
                )
            except HttpResponseError as e:
                print(json.dumps(e.model.as_dict(), indent=3))
                raise e
        else:
            result = self._operation_2021_10.create_or_update(
                id=rest_job_resource.name,  # type: ignore
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                body=rest_job_resource,
                **self._kwargs,
            )
        if is_local_run(result):
            ws_base_url = self._all_operations.all_operations[
                AzureMLResourceType.WORKSPACE
            ]._operation._client._base_url
            snapshot_id = start_run_if_local(result, self._credential, ws_base_url)
            # in case of local run, the first create/update call to MFE returns the
            # request for submitting to ES. Once we request to ES and start the run, we
            # need to put the same body to MFE to append user tags etc.
            job_object = self._get_job(rest_job_resource.name)
            if result.properties.tags is not None:
                for tag_name, tag_value in rest_job_resource.properties.tags.items():
                    job_object.properties.tags[tag_name] = tag_value
            if result.properties.properties is not None:
                for prop_name, prop_value in rest_job_resource.properties.properties.items():
                    job_object.properties.properties[prop_name] = prop_value
            if snapshot_id is not None:
                job_object.properties.properties["ContentSnapshotId"] = snapshot_id
            if (
                getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR)
                and rest_job_resource.properties.job_type == RestJobType.AUTO_ML
            ):
                result = self._operation_2020_09_preview.create_or_update(
                    id=rest_job_resource.name,  # type: ignore
                    resource_group_name=self._workspace_scope.resource_group_name,
                    workspace_name=self._workspace_name,
                    body=job_object,
                    **self._kwargs,
                )
            else:
                result = self._operation_2021_10.create_or_update(
                    id=rest_job_resource.name,  # type: ignore
                    resource_group_name=self._workspace_scope.resource_group_name,
                    workspace_name=self._workspace_name,
                    body=job_object,
                    **self._kwargs,
                )
        return self._resolve_azureml_id(Job._from_rest_object(result))

    def stream(self, name: str) -> None:
        """Stream logs of a job.

        :param str name: Name of the job.
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """
        job_object = self._get_job(name)

        try:
            self._runs._operation._client._base_url = self._get_workspace_url()
            self._stream_logs_until_completion(
                self._runs, job_object, self._all_operations.all_operations[AzureMLResourceType.DATASTORE]
            )
        except Exception:
            raise

    def download(
        self,
        name: str,
        *,
        download_path: Union[PathLike, str] = Path.home(),
        include_children=True,
    ) -> None:
        """Download logs and output of a job.

        :param str name: Name of the job.
        :param Union[PathLike, str] download_path: Local path as download destination, defaults to home directory of the current user.
        :param bool include_children: Download children of the job. Default to True.
        :raise: ResourceNotFoundError if can't find a job matching provided name.
        """
        job_details = self.get(name)
        job_status = job_details.status
        if job_status not in RunHistoryConstants.TERMINAL_STATUSES:
            raise Exception(
                "This job is in state {}. Download is allowed only in states {}".format(
                    job_status, RunHistoryConstants.TERMINAL_STATUSES
                )
            )
        self._download(name, download_path)
        if include_children:
            if isinstance(job_details, PipelineJob) or isinstance(job_details, SweepJob):
                job_object = self._get_job(name)
                with modified_operation_client(self._runs._operation, self._get_workspace_url()):
                    job_details = get_children(self._runs, job_object.properties.experiment_name, job_object.name)
                    num_processes = int(cpu_count()) * PROCESSES_PER_CORE
                    with ThreadPool(num_processes) as pool:
                        child_run_ids = [child_job["runId"] for child_job in job_details["value"]]
                        func = partial(self._download, download_path=(Path(download_path) / name))
                        return pool.map(func, child_run_ids)

    def _download(
        self,
        name: str,
        download_path: Union[PathLike, str] = Path.home(),
    ) -> None:

        prefix_list = ["ExperimentRun/dcid." + name + "/"]

        ds = self._all_operations.all_operations[AzureMLResourceType.DATASTORE].get_default(include_secrets=True)
        acc_name = ds.account_name
        acc_key = ds.credentials.key
        datastore_type = ds.type

        storage_client = get_storage_client(
            credential=acc_key, container_name=self._container, storage_account=acc_name, storage_type=datastore_type
        )

        for item in prefix_list:
            path_file = "{}{}{}".format(download_path, sep, name)
            module_logger.info(f"Downloading the job logs {item} at {path_file}\n")
            storage_client.download(starts_with=item, destination=download_path)

    def _get_job(self, name: str) -> JobBaseResource:
        try:
            return self._operation_2021_10.get(
                id=name,
                resource_group_name=self._workspace_scope.resource_group_name,
                workspace_name=self._workspace_name,
                **self._kwargs,
            )
        except HttpResponseError as e:
            if (
                getenv(AZUREML_PRIVATE_FEATURES_ENV_VAR)
                and "A job was found, but it is not supported in this API version and cannot be accessed" in e.message
            ):
                return self._operation_2020_09_preview.get(
                    id=name,
                    resource_group_name=self._workspace_scope.resource_group_name,
                    workspace_name=self._workspace_name,
                    **self._kwargs,
                )
            raise e

    def _get_workspace_url(self):
        discovery_url = (
            self._all_operations.all_operations[AzureMLResourceType.WORKSPACE]
            .get(self._workspace_scope.workspace_name)
            .discovery_url
        )
        all_urls = json.loads(download_text_from_url(discovery_url, create_session_with_retry()))
        return all_urls["history"]

    def _resolve_arm_id_or_upload_dependencies(self, job: Job) -> Job:
        """This method converts name or name:version to ARM id. Or it registers/uploads nested dependencies.

        :param job: the job resource entity
        :type job: Job
        :return: the job resource entity that nested dependencies are resolved
        :rtype: Job
        """
        return self._resolve_arm_id_or_azureml_id(job, self._orchestrators.get_asset_arm_id)

    def _resolve_azureml_id(self, job: Job) -> Job:
        """This method converts ARM id to name or name:version for nested entities.

        :param job: the job resource entity
        :type job: Job
        :return: the job resource entity that nested dependencies are resolved
        :rtype: Job
        """
        self._append_tid_to_studio_url(job)
        return self._resolve_arm_id_or_azureml_id(job, self._orchestrators.resolve_azureml_id)

    def _resolve_compute_id(self, resolver: Callable, target: Any) -> Any:
        # special case for local runs
        if target is not None and target.lower() == LOCAL_COMPUTE_TARGET:
            return LOCAL_COMPUTE_TARGET
        try:
            modified_target_name = target
            if target.lower().startswith(AzureMLResourceType.VIRTUALCLUSTER + "/"):
                # Compute target can be either workspace-scoped compute type,
                # or AML scoped VC. In the case of VC, resource name will be of form
                # azureml:virtualClusters/<name> to disambiguate from azureml:name (which is always compute)
                modified_target_name = modified_target_name[len(AzureMLResourceType.VIRTUALCLUSTER) + 1 :]
                modified_target_name = LEVEL_ONE_NAMED_RESOURCE_ID_FORMAT.format(
                    self._workspace_scope.subscription_id,
                    self._workspace_scope.resource_group_name,
                    AZUREML_RESOURCE_PROVIDER,
                    AzureMLResourceType.VIRTUALCLUSTER,
                    modified_target_name,
                )
            return resolver(
                modified_target_name,
                azureml_type=AzureMLResourceType.VIRTUALCLUSTER,
                sub_workspace_resource=False,
            )
        except Exception:
            return resolver(target, azureml_type=AzureMLResourceType.COMPUTE)

    def _resolve_arm_id_or_azureml_id(self, job: Job, resolver: Callable) -> Job:
        """Resolve arm_id for a given job"""
        # TODO: this will need to be parallelized when multiple tasks
        # are required. Also consider the implications for dependencies.
        if isinstance(job, _BaseJob):
            job.compute = self._resolve_compute_id(resolver, job.compute)
        elif isinstance(job, CommandJob):
            job = self._resolve_arm_id_for_command_job(job, resolver)
        elif isinstance(job, SweepJob):
            job = self._resolve_arm_id_for_sweep_job(job, resolver)
        elif isinstance(job, AutoMLJob):
            job = self._resolve_arm_id_for_automl_job(job, resolver)
        elif isinstance(job, PipelineJob):
            job = self._resolve_arm_id_for_pipeline_job(job, resolver)
        else:
            raise Exception(f"Non supported job type: {type(job)}")
        return job

    def _resolve_arm_id_for_command_job(self, job: Job, resolver: Callable) -> Job:
        """Resolve arm_id for CommandJob"""
        job.code = resolver(job.code, azureml_type=AzureMLResourceType.CODE)
        job.environment = resolver(job.environment, azureml_type=AzureMLResourceType.ENVIRONMENT)
        for value in job.inputs.values():
            if isinstance(value, InputOutputEntry):
                value.data = resolver(value.data, azureml_type=AzureMLResourceType.DATA)
            if isinstance(value, InputDatasetEntry):
                value.dataset = resolver(value.dataset, azureml_type=AzureMLResourceType.DATASET)
        for value in job.outputs.values():
            if isinstance(value, InputOutputEntry):
                value.data = resolver(value.data, azureml_type=AzureMLResourceType.DATA)
        job.compute = self._resolve_compute_id(resolver, job.compute)
        return job

    def _resolve_arm_id_for_sweep_job(self, job: Job, resolver: Callable) -> Job:
        """Resolve arm_id for SweepJob"""
        job.trial.code = resolver(job.trial.code, azureml_type=AzureMLResourceType.CODE)
        job.trial.environment = resolver(job.trial.environment, azureml_type=AzureMLResourceType.ENVIRONMENT)
        for value in job.inputs.values():
            if isinstance(value, InputOutputEntry):
                value.data = resolver(value.data, azureml_type=AzureMLResourceType.DATA)
            if isinstance(value, InputDatasetEntry):
                value.dataset = resolver(value.dataset, azureml_type=AzureMLResourceType.DATASET)
        for value in job.outputs.values():
            if isinstance(value, InputOutputEntry):
                value.data = resolver(value.data, azureml_type=AzureMLResourceType.DATA)
        job.compute = self._resolve_compute_id(resolver, job.compute)
        return job

    def _resolve_arm_id_for_automl_job(self, job: Job, resolver: Callable) -> Job:
        """Resolve arm_id for AutoMLJob"""
        # AutoML does not have dependency uploads. Only need to resolve reference to arm id.
        job.compute = resolver(job.compute, azureml_type=AzureMLResourceType.COMPUTE)
        training_data = job.data_settings.training_data
        if training_data:
            training_data.dataset_arm_id = resolver(training_data.dataset_arm_id, azureml_type=AzureMLResourceType.DATA)
        validation_data = job.data_settings.validation_data
        if validation_data:
            validation_data.dataset_arm_id = resolver(
                validation_data.dataset_arm_id, azureml_type=AzureMLResourceType.DATA
            )
        test_data = job.data_settings.test_data
        if test_data:
            test_data.dataset_arm_id = resolver(test_data.dataset_arm_id, azureml_type=AzureMLResourceType.DATA)

    def _resolve_arm_id_for_pipeline_job(self, pipeline_job: PipelineJob, resolver: Callable) -> Job:
        """Resolve arm_id for pipeline_job"""
        # Get top-level job compute
        self._get_job_compute_id(pipeline_job, resolver)
        # Process top-level job inputs
        self._get_pipeline_component_job_dataset_ids(pipeline_job.inputs, resolver)

        # Process job defaults:
        if pipeline_job.settings:
            pipeline_job.settings.datastore = resolver(
                pipeline_job.settings.datastore, azureml_type=AzureMLResourceType.DATASTORE
            )
            pipeline_job.settings.code = resolver(pipeline_job.settings.code, azureml_type=AzureMLResourceType.CODE)
            pipeline_job.settings.environment = resolver(
                pipeline_job.settings.environment, azureml_type=AzureMLResourceType.ENVIRONMENT
            )

        # Process each component job
        if pipeline_job.jobs:

            for key, job_instance in pipeline_job.jobs.items():
                if not (isinstance(job_instance, CommandJob) or isinstance(job_instance, ComponentJob)):
                    raise Exception(f"Non supported job type in Pipeline jobs: {type(job_instance)}")
                if isinstance(job_instance, CommandJob):
                    context = {BASE_PATH_CONTEXT_KEY: "./"}
                    translated_component_job = job_instance._translate_command_job_to_component_job(
                        pipeline_job.inputs, context
                    )
                    if not isinstance(translated_component_job, ComponentJob):
                        raise Exception(f"Unable to translate CommandJob: {job_instance} to ComponentJob.")
                    # Remove CommandJob from the dictionary and add translated ComponentJob for the same key
                    pipeline_job.jobs.update({key: translated_component_job})
                    job_instance = translated_component_job
                # Get the default for the specific job type
                if (
                    isinstance(job_instance.component, CommandComponent)
                    and job_instance.component.is_anonymous
                    and not job_instance.component.display_name
                ):
                    job_instance.component.display_name = key

                # Get compute for each job
                self._get_job_compute_id(job_instance, resolver)

                # set default code & environment for component
                self._set_defaults_to_component(job_instance.component, pipeline_job.settings)

                # Get the component id for each job's component
                job_instance.component = resolver(job_instance.component, azureml_type=AzureMLResourceType.COMPONENT)

                # Process job-level job inputs
                self._get_pipeline_component_job_dataset_ids(job_instance.inputs, resolver)

        return pipeline_job

    def _get_pipeline_component_job_dataset_ids(
        self, inputs: Dict[str, Union[str, float, bool, int, InputOutputEntry, InputDatasetEntry]], resolver: Callable
    ) -> None:
        """Processes dataset inputs for both PipelineJob and ComponentJob"""
        if inputs:
            for input_value in inputs.values():
                # Get the dataset ARM ID for any dataset inputs.
                # Since the backend calls the DataVersionService and not DatasetVersionService, replace "datasets" in ARM id with "data"
                if isinstance(input_value, InputOutputEntry):
                    input_value.data = resolver(input_value.data, azureml_type=AzureMLResourceType.DATA)
                if isinstance(input_value, InputDatasetEntry):
                    input_value.dataset = resolver(input_value.dataset, azureml_type=AzureMLResourceType.DATASET)

    def _get_job_compute_id(self, job: Union[Job, ComponentJob], resolver: Callable) -> None:
        job.compute = resolver(job.compute, azureml_type=AzureMLResourceType.COMPUTE)

    def _append_tid_to_studio_url(self, job: Job) -> None:
        """Appends the user's tenant ID to the end of the studio URL so the UI knows against which tenant to authenticate"""
        try:
            studio_endpoint = job.services.get("Studio", None)
            studio_url = studio_endpoint.endpoint
            # Extract the tenant id from the credential using PyJWT
            decode = jwt.decode(
                self._credential.get_token(*DEFAULT_SCOPES).token,
                options={"verify_signature": False, "verify_aud": False},
            )
            tid = decode["tid"]
            formatted_tid = TID_FMT.format(tid)
            studio_endpoint.endpoint = studio_url + formatted_tid
        except Exception:
            module_logger.info("Proceeding with no tenant id appended to studio URL\n")

    def _set_defaults_to_component(self, component: Union[str, Component], settings: PipelineJobSettings):
        """Set default code&environment to component if not specified."""
        if isinstance(component, CommandComponent):
            if not component.code and settings and settings.code:
                component.code = settings.code
            if not component.environment:
                component.environment = settings.environment
