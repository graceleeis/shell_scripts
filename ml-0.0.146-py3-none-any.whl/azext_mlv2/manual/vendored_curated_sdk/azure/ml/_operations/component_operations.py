# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import logging
import tempfile
from pathlib import Path
from typing import Dict, Iterable, Union, cast

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations import OperationOrchestrator
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01 import AzureMachineLearningWorkspaces as ServiceClient102021
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import (
    ComponentVersionResource,
    ComponentContainer,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import _WorkspaceDependentOperations, WorkspaceScope, OperationsContainer
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import OrderString, AzureMLResourceType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Component, CommandComponent, Code
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._asset_utils import _create_or_update_autoincrement

module_logger = logging.getLogger(__name__)
CODE_IMMUTABLE_ERROR = "The field CodeName is immutable."
CHANGE_CODE_IMMUTABLE_ERROR = (
    "Component {} already exists with a different component code. "
    "The component code field is immutable, try specifying a new version."
)
COMPONENT_PLACEHOLDER_FILE_NAME = "COMPONENT_PLACEHOLDER"


class ComponentOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: ServiceClient102021,
        all_operations: OperationsContainer,
        **kwargs: Dict,
    ):
        super(ComponentOperations, self).__init__(workspace_scope)
        self._version_operation = service_client.component_versions
        self._container_operation = service_client.component_containers
        self._all_operations = all_operations
        self._init_args = kwargs

    def list(self, name: Union[str, None] = None) -> Iterable[Union[Component, ComponentContainer]]:
        if name:
            return self._version_operation.list(
                name,
                self._resource_group_name,
                self._workspace_name,
                **self._init_args,
                cls=lambda objs: [Component._from_rest_object(obj) for obj in objs],
            )
        return self._container_operation.list(
            self._resource_group_name,
            self._workspace_name,
            **self._init_args,
        )

    def get(self, name: str, version: str) -> Component:
        """Returns information about the specified component.

        :param name: Name of the code component.
        :type name: str
        :param version: Version of the component.
        :type version: str
        """
        result = self._version_operation.get(
            name=name,
            version=version,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            **self._init_args,
        )
        component = Component._from_rest_object(result)
        return component

    def create_or_update(self, component: Component) -> Component:
        # Create all dependent resources
        self._upload_dependencies(component)

        rest_component_resource = component._to_rest_object()
        try:
            if component.auto_increment_version:
                result = _create_or_update_autoincrement(
                    name=component.name,
                    body=rest_component_resource,
                    version_operation=self._version_operation,
                    container_operation=self._container_operation,
                    resource_group_name=self._workspace_scope.resource_group_name,
                    workspace_name=self._workspace_name,
                    **self._init_args,
                )
            else:
                result = self._version_operation.create_or_update(
                    name=rest_component_resource.name,
                    version=component.version,
                    resource_group_name=self._resource_group_name,
                    workspace_name=self._workspace_name,
                    body=rest_component_resource,
                    **self._init_args,
                )
        except Exception as e:
            # If user tries to create same component with different code, raise exception with meaningful error msg.
            if CODE_IMMUTABLE_ERROR in str(e):
                # TODO: the exception type might be user error.
                raise Exception(CHANGE_CODE_IMMUTABLE_ERROR.format(rest_component_resource.name))
            raise e

        return Component._from_rest_object(result)

    def delete(self, name: str, version: str = None):
        """Deletes a specified version of a component.

        :param name: Name of component.
        :type name: str
        :param version: Version of the component.
        :type version: str
        """
        if version:
            result = self._version_operation.delete(
                name=name,
                version=version,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                **self._init_args,
            )
        else:
            result = self._container_operation.delete(
                name=name,
                resource_group_name=self._resource_group_name,
                workspace_name=self._workspace_name,
                **self._init_args,
            )
        return result

    def get_latest_version(self, component_name: str) -> Component:
        """
        Gets the latest version of the component
        """

        for component in self._version_operation.list(
            component_name,
            self._resource_group_name,
            self._workspace_name,
            order_by=OrderString.CREATED_AT_DESC,
            top=1,
            **self._init_args,
        ):
            result = cast(ComponentVersionResource, component)
            return Component._from_rest_object(result)

    def _upload_dependencies(self, component: Component) -> None:
        orchestrators = OperationOrchestrator(self._all_operations, self._workspace_scope)
        resolver = orchestrators.get_asset_arm_id

        if type(component) is CommandComponent:
            if component.code:
                component.code = resolver(component.code, azureml_type=AzureMLResourceType.CODE)
            else:
                # Hack: when code not specified, we generated a file which contains component name & version as code
                # This hack was introduced because job does not allow running component without a code and we need to
                # make sure when component updated some field(eg: description), the code remains the same.
                with tempfile.TemporaryDirectory() as tmp_dir:
                    code_file_path = Path(tmp_dir) / COMPONENT_PLACEHOLDER_FILE_NAME
                    with open(code_file_path, "w") as f:
                        f.write(f"{component.name}:{component.version}")
                    component.code = resolver(Code(local_path=code_file_path), azureml_type=AzureMLResourceType.CODE)
            if component.environment:
                component.environment = resolver(component.environment, azureml_type=AzureMLResourceType.ENVIRONMENT)
        else:
            raise Exception(f"Non supported component type: {type(component)}")
