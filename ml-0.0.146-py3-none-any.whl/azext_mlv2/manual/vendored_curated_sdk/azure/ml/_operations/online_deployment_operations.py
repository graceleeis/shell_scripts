# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import random
from typing import Dict, Optional

from azure.identity import ChainedTokenCredential
from azure.core.paging import ItemPaged
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._arm_deployments import ArmDeploymentExecutor
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._arm_deployments.online_deployment_arm_generator import OnlineDeploymentArmGenerator
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01 import (
    AzureMachineLearningWorkspaces as ServiceClient102021,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import (
    DeploymentLogsRequest,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import OperationsContainer, WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._local_endpoints import LocalEndpointMode
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType, EndpointDeploymentLogContainerType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import CodeConfiguration, OnlineDeployment

from ._local_deployment_helper import _LocalDeploymentHelper
from .operation_orchestrator import OperationOrchestrator

module_logger = logging.getLogger(__name__)


class OnlineDeploymentOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client_10_2021: ServiceClient102021,
        all_operations: OperationsContainer,
        local_deployment_helper: _LocalDeploymentHelper,
        credentials: ChainedTokenCredential = None,
        **kwargs: Dict,
    ):
        super(OnlineDeploymentOperations, self).__init__(workspace_scope)
        self._local_deployment_helper = local_deployment_helper
        self._online_deployment = service_client_10_2021.online_deployments
        self._online_endpoint_operations = service_client_10_2021.online_endpoints
        self._all_operations = all_operations
        self._credentials = credentials
        self._init_kwargs = kwargs

    def create_or_update(
        self,
        deployment: OnlineDeployment,
        local: bool = False,
        vscode_debug: bool = False,
        no_wait: bool = False,
    ) -> None:
        """Create or update a deployment

        :param deployment: the deployment entity
        :type deployment: OnlineDeployment
        :param local: Whether deployment should be created locally, defaults to False
        :type local: bool, optional
        :param vscode_debug: Whether to open VSCode instance to debug local deployment, defaults to False
        :type vscode_debug: bool, optional
        :param no_wait: Applied only to online deployment, defaults to False
        :type no_wait: bool, optional
        :return: None
        :rtype: None | OnlineDeployment
        """
        if local:
            return self._local_deployment_helper.create_or_update(
                deployment=deployment, local_endpoint_mode=self._get_local_endpoint_mode(vscode_debug)
            )

        # This get() is to ensure, the endpoint exists and fail before even start the deployment
        module_logger.info(f"Check: endpoint {deployment.endpoint_name} exists")
        self._online_endpoint_operations.get(deployment.endpoint_name, self._resource_group_name, self._workspace_name)

        self._upload_dependencies(deployment)
        location = self._get_workspace_location()

        # generate online endpoint arm template
        arm_generator = OnlineDeploymentArmGenerator(
            operation_container=self._all_operations, workspace_scope=self._workspace_scope
        )
        template, resources_being_deployed = arm_generator.generate_online_deployment_template(
            workspace_name=self._workspace_name, location=location, deployment=deployment
        )
        module_logger.info("OnlineDeploymentOperations create_or_update before ArmDeploymentExecutor")
        arm_submit = ArmDeploymentExecutor(
            credentials=self._credentials,
            subscription_id=self._subscription_id,
            resource_group_name=self._resource_group_name,
            deployment_name=self._get_ARM_deployment_name(deployment.endpoint_name),
        )

        module_logger.info("OnlineDeploymentOperations create_or_update after ArmDeploymentExecutor")
        arm_submit.deploy_resource(
            template=template, resources_being_deployed=resources_being_deployed, wait=not no_wait
        )

    def get(self, name: str, endpoint_name: str, local: bool = False) -> OnlineDeployment:
        """Get a deployment resource

        :param name: The name of the deployment
        :type name: str
        :param endpoint_name: The name of the endpoint
        :type endpoint_name: str
        :param local: Whether deployment should be retrieved from local docker environment, defaults to False
        :type local: bool, optional
        :return: a deployment entity
        :rtype: OnlineDeployment
        """
        if local:
            deployment = self._local_deployment_helper.get(endpoint_name=endpoint_name, deployment_name=name)
        else:
            deployment = OnlineDeployment._from_rest_object(
                self._online_deployment.get(
                    endpoint_name=endpoint_name,
                    deployment_name=name,
                    resource_group_name=self._resource_group_name,
                    workspace_name=self._workspace_name,
                    **self._init_kwargs,
                )
            )

        deployment.endpoint_name = endpoint_name
        return deployment

    def delete(self, name: str, endpoint_name: str, local: bool = False) -> None:
        """Delete a deployment

        :param name: The name of the deployment
        :type name: str
        :param endpoint_name: The name of the endpoint
        :type endpoint_name: str
        :param local: Whether deployment should be retrieved from local docker environment, defaults to False
        :type local: bool, optional
        """
        if local:
            return self._local_deployment_helper.delete(name=endpoint_name, deployment_name=name)
        return self._online_deployment.begin_delete(
            endpoint_name=endpoint_name,
            deployment_name=name,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            **self._init_kwargs,
        )

    def get_logs(
        self, name: str, endpoint_name: str, lines: int, container_type: Optional[str] = None, local: bool = False
    ) -> str:
        """Retrive the logs from online deployment.

        :param name: The name of the deployment
        :type name: str
        :param endpoint_name: The name of the endpoint
        :type endpoint_name: str
        :param lines: The maximum number of lines to tail
        :type lines: int
        :param container_type: The type of container to retrieve logs from. Possible values include:
            "StorageInitializer", "InferenceServer", defaults to None
        :type container_type: Optional[str], optional
        :param local: [description], defaults to False
        :type local: bool, optional
        :return: the logs
        :rtype: str
        """
        if local:
            return self._local_deployment_helper.get_deployment_logs(
                endpoint_name=endpoint_name, deployment_name=name, lines=lines
            )
        if container_type:
            container_type = self._validate_deployment_log_container_type(container_type)
        log_request = DeploymentLogsRequest(container_type=container_type, tail=lines)
        return self._online_deployment.get_logs(
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            endpoint_name=endpoint_name,
            deployment_name=name,
            body=log_request,
            **self._init_kwargs,
        ).content

    def list(self, endpoint_name: str, local: bool = False) -> ItemPaged[OnlineDeployment]:
        """List a deployment resource

        :param endpoint_name: The name of the endpoint
        :type endpoint_name: str
        :param local: Whether deployment should be retrieved from local docker environment, defaults to False
        :type local: bool, optional
        :return: an iterator of deployment entities
        :rtype: Iterable[OnlineDeployment]
        """
        if local:
            return self._local_deployment_helper.list()
        return self._online_deployment.list(
            endpoint_name=endpoint_name,
            resource_group_name=self._resource_group_name,
            workspace_name=self._workspace_name,
            cls=lambda objs: [OnlineDeployment._from_rest_object(obj) for obj in objs],
            **self._init_kwargs,
        )

    def _validate_deployment_log_container_type(self, container_type):
        if container_type == EndpointDeploymentLogContainerType.INFERENCE_SERVER:
            return EndpointDeploymentLogContainerType.INFERENCE_SERVER_REST

        if container_type == EndpointDeploymentLogContainerType.STORAGE_INITIALIZER:
            return EndpointDeploymentLogContainerType.STORAGE_INITIALIZER_REST

        raise Exception(
            f"Invalid container type '{container_type}'. Supported container types are {EndpointDeploymentLogContainerType.INFERENCE_SERVER} and {EndpointDeploymentLogContainerType.STORAGE_INITIALIZER}."
        )

    def _get_ARM_deployment_name(self, name: str):
        random.seed(version=2)
        return f"{self._workspace_name}-{name}-{random.randint(1, 10000000)}"

    def _get_workspace_location(self) -> str:
        """Get the workspace location
        TODO[TASK 1260265]: can we cache this information and only refresh when the workspace_scope is changed?
        """
        return self._all_operations.all_operations[AzureMLResourceType.WORKSPACE].get(self._workspace_name).location

    def _upload_dependencies(self, deployment: OnlineDeployment):
        """Upload code, dependency, model dependencies.
        For BatchDeployment only, register these dependencies, and also register compute.
        """

        module_logger.debug(f"Upload the dependencies for deployment {deployment.name}")
        register_asset = False  # isinstance(deployment, BatchDeployment)
        orchestrators = OperationOrchestrator(
            operation_container=self._all_operations, workspace_scope=self._workspace_scope
        )
        deployment.code_configuration = (
            CodeConfiguration(
                code=orchestrators.get_asset_arm_id(
                    deployment.code_configuration.code,
                    azureml_type=AzureMLResourceType.CODE,
                    register_asset=register_asset,
                ),
                scoring_script=deployment.code_configuration.scoring_script,
            )
            if deployment.code_configuration
            else None
        )
        deployment.environment = (
            orchestrators.get_asset_arm_id(
                deployment.environment, azureml_type=AzureMLResourceType.ENVIRONMENT, register_asset=register_asset
            )
            if deployment.environment
            else None
        )
        deployment.model = (
            orchestrators.get_asset_arm_id(
                deployment.model, azureml_type=AzureMLResourceType.MODEL, register_asset=register_asset
            )
            if deployment.model
            else None
        )
        if register_asset and deployment.compute:
            deployment.compute.target = orchestrators.get_asset_arm_id(
                deployment.compute.target, azureml_type=AzureMLResourceType.COMPUTE
            )

    def _get_local_endpoint_mode(self, vscode_debug):
        return LocalEndpointMode.VSCodeDevContainer if vscode_debug else LocalEndpointMode.DetachedContainer
