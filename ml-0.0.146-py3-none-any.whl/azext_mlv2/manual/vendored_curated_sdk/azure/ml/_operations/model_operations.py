# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Iterable

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._artifact_utilities import (
    _check_and_upload_path,
    _update_metadata,
    _get_default_datastore_info,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._artifacts._constants import ASSET_PATH_ERROR, CHANGED_ASSET_PATH_MSG
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._operations.datastore_operations import DatastoreOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01 import AzureMachineLearningWorkspaces as ServiceClient102021
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import (
    ModelVersionResource,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._arm_id_utils import get_datastore_arm_id, is_ARM_id_for_resource
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils._asset_utils import _create_or_update_autoincrement
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._workspace_dependent_operations import WorkspaceScope, _WorkspaceDependentOperations
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Model

module_logger = logging.getLogger(__name__)


class ModelOperations(_WorkspaceDependentOperations):
    def __init__(
        self,
        workspace_scope: WorkspaceScope,
        service_client: ServiceClient102021,
        datastore_operations: DatastoreOperations,
    ):
        super(ModelOperations, self).__init__(workspace_scope)
        self._model_versions_operation = service_client.model_versions
        self._model_container_operation = service_client.model_containers
        self._datastore_operation = datastore_operations

    def create_or_update(self, model: Model) -> Model:  # TODO: Are we going to implement job_name?
        name = model.name
        version = model.version

        model, indicator_file = _check_and_upload_path(artifact=model, asset_operations=self)

        model_version_resource = model._to_rest_object()
        auto_increment_version = model._auto_increment_version
        try:
            if auto_increment_version:
                result = _create_or_update_autoincrement(
                    name=model.name,
                    body=model_version_resource,
                    version_operation=self._model_versions_operation,
                    container_operation=self._model_container_operation,
                    workspace_name=self._workspace_name,
                    **self._scope_kwargs,
                )
            else:
                result = self._model_versions_operation.create_or_update(
                    name=name,
                    version=version,
                    body=model_version_resource,
                    workspace_name=self._workspace_name,
                    **self._scope_kwargs,
                )
        except Exception as e:
            # service side raises an exception if we attempt to update an existing asset's path
            if str(e) == ASSET_PATH_ERROR:
                raise Exception(CHANGED_ASSET_PATH_MSG)
            else:
                raise e

        model = Model._from_rest_object(result)
        if auto_increment_version and indicator_file:
            datastore_info = _get_default_datastore_info(self._datastore_operation)
            _update_metadata(model.name, model.version, indicator_file, datastore_info)  # update version in storage

        return model

    def _get(self, name: str, version: str) -> ModelVersionResource:  # name:latest
        model_version_resource = self._model_versions_operation.get(
            name=name, version=version, workspace_name=self._workspace_name, **self._scope_kwargs
        )
        return model_version_resource

    def get(self, name: str, version: str) -> Model:
        """Returns information about the specified model asset.

        :param name: Name of the model.
        :type name: str
        :param version: Version of the model.
        :type version: str
        """
        # TODO: We should consider adding an exception trigger for internal_model=None
        model_version_resource = self._get(name, version)

        return Model._from_rest_object(model_version_resource)

    def delete(self, name: str, version: str) -> None:
        """Delete model asset.

        :param name: Name of model asset.
        :type name: str
        :param version: Version of model asset.
        :type version: str
        """
        if version:
            return self._model_versions_operation.delete(
                name=name, version=version, workspace_name=self._workspace_name, **self._scope_kwargs
            )
        else:
            raise Exception("Deletion on the whole lineage is not supported yet.")

    def list(self, name: str = None) -> Iterable[Model]:
        """List all model assets in workspace.

        :param name: Name of the model.
        :type name: str
        :return: An iterator like instance of Model objects
        :rtype: ~azure.core.paging.ItemPaged[Model]
        """
        if name:
            return self._model_versions_operation.list(
                name=name,
                workspace_name=self._workspace_name,
                cls=lambda objs: [Model._from_rest_object(obj) for obj in objs],
                **self._scope_kwargs,
            )
        else:
            return self._model_container_operation.list(
                workspace_name=self._workspace_name,
                cls=lambda objs: [Model._from_container_rest_object(obj) for obj in objs],
                **self._scope_kwargs,
            )
