# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

MFE_BASE_URL = "https://management.azure.com"
API_VERSION_2021_03_01_PREVIEW = "2021-03-01-preview"
API_VERSION_2020_09_01_PREVIEW = "2020-09-01-preview"
API_VERSION_2020_09_01_DATAPLANE = "2020-09-01-dataplanepreview"
ONLINE_ENDPOINT_TYPE = "online"
BATCH_ENDPOINT_TYPE = "batch"
BASE_PATH_CONTEXT_KEY = "base_path"
PARAMS_OVERRIDE_KEY = "params_override"
TYPE = "type"
JOBLIMITSTYPE = "JobLimitsType"
DATA_ARM_TYPE = "data"
DATASET_ARM_TYPE = "datasets"
ARM_ID_PREFIX = "azureml:"
FILE_PREFIX = "file:"
FOLDER_PREFIX = "folder:"
ARM_ID_FULL_PREFIX = "/subscriptions/"
AZUREML_RESOURCE_PROVIDER = "Microsoft.MachineLearningServices"
RESOURCE_ID_FORMAT = "/subscriptions/{}/resourceGroups/{}/providers/{}/workspaces/{}"
NAMED_RESOURCE_ID_FORMAT = "/subscriptions/{}/resourceGroups/{}/providers/{}/workspaces/{}/{}/{}"
LEVEL_ONE_NAMED_RESOURCE_ID_FORMAT = "/subscriptions/{}/resourceGroups/{}/providers/{}/{}/{}"
VERSIONED_RESOURCE_ID_FORMAT = "/subscriptions/{}/resourceGroups/{}/providers/{}/workspaces/{}/{}/{}/versions/{}"
DATASTORE_RESOURCE_ID = (
    "/subscriptions/{}/resourceGroups/{}/providers/" "Microsoft.MachineLearningServices/workspaces/{}/datastores/{}"
)
PROVIDER_RESOURCE_ID_WITH_VERSION = (
    "/subscriptions/{}/resourceGroups/{}/providers/" "Microsoft.MachineLearningServices/workspaces/{}/{}/{}/versions/{}"
)
VERSIONED_RESOURCE_NAME = "{}:{}"
PYTHON = "python"
AML_TOKEN_YAML = "aml_token"
AAD_TOKEN_YAML = "aad_token"
KEY = "key"
DEFAULT_ARM_RETRY_INTERVAL = 60
COMPONENT_TYPE = "type"
TID_FMT = "&tid={}"
DEFAULT_SCOPES = ["https://management.azure.com/.default"]
AZUREML_PRIVATE_FEATURES_ENV_VAR = "AZURE_ML_CLI_PRIVATE_FEATURES_ENABLED"
ENDPOINT_DEPLOYMENT_START_MSG = "https://ms.portal.azure.com/#blade/HubsExtension/DeploymentDetailsBlade/overview/id/%2Fsubscriptions%2F{}%2FresourceGroups%2F{}%2Fproviders%2FMicrosoft.Resources%2Fdeployments%2F{}\n"
AZUREML_LOCAL_ENDPOINTS_NOT_IMPLEMENTED_ERROR = "This operation for local endpoints is not supported yet."
BATCH_JOB_NOT_SUPPORTED_ERROR_CODE = "BatchJobNotSupported"
ENVIRONMENT_VARIABLES = "environment_variables"
LIMITED_RESULTSET_WARNING_FORMAT = "Displaying top {} results from the list command."
MAX_LIST_CLI_RESULTS = 50
LOCAL_COMPUTE_TARGET = "local"
LOCAL_COMPUTE_PROPERTY = "IsLocal"
CONDA_FILE = "conda_file"
DOCKER_FILE_NAME = "Dockerfile"
ML_AUDIENCE_SCOPE = "https://ml.azure.com"
COMPUTE_UPDATE_ERROR = "Only AmlCompute cluster properties are supported, compute name {}, is {} type."
MAX_AUTOINCREMENT_ATTEMPTS = 3
SHORT_URI_FORMAT = "azureml://datastores/{}/paths/{}"
LONG_URI_FORMAT = "azureml://subscriptions/{}/resourceGroups/{}/workspaces/{}/datastores/{}/paths/{}"
SHORT_URI_REGEX_FORMAT = "azureml://datastores/([^/]+)/paths/(.+)"
OUTPUT_URI_REGEX_FORMAT = "azureml://datastores/([^/]+)/ExperimentRun/(.+)"
LONG_URI_REGEX_FORMAT = (
    "azureml://subscriptions/([^/]+)/resourceGroups/([^/]+)/workspaces/([^/]+)/datastores/([^/]+)/paths/(.+)"
)


class SearchSpace:
    # Hyperparameter search constants
    CHOICE = "choice"
    UNIFORM = "uniform"
    LOGUNIFORM = "loguniform"
    QUNIFORM = "quniform"
    QLOGUNIFORM = "qloguniform"
    NORMAL = "normal"
    LOGNORMAL = "lognormal"
    QNORMAL = "qnormal"
    QLOGNORMAL = "qlognormal"
    RANDINT = "randint"

    UNIFORM_LOGUNIFORM = [UNIFORM, LOGUNIFORM]
    QUNIFORM_QLOGUNIFORM = [QUNIFORM, QLOGUNIFORM]
    NORMAL_LOGNORMAL = [NORMAL, LOGNORMAL]
    QNORMAL_QLOGNORMAL = [QNORMAL, QLOGNORMAL]


class ComputeType(object):
    MANAGED = "managed"
    AMLCOMPUTE = "amlcompute"
    COMPUTEINSTANCE = "computeinstance"
    VIRTUALMACHINE = "virtualmachine"
    KUBERNETES = "kubernetes"


class ComputeTier(object):
    LOWPRIORITY = "low_priority"
    DEDICATED = "dedicated"


class IdentityType(object):
    SYSTEM_ASSIGNED = "system_assigned"
    USER_ASSIGNED = "user_assigned"
    BOTH = "system_assigned,user_assigned"


class DeploymentType(object):
    K8S = "Kubernetes"
    MANAGED = "Managed"


class DistributionType(object):
    MPI = "Mpi"
    TENSORFLOW = "TensorFlow"
    PYTORCH = "PyTorch"


class EndpointDeploymentLogContainerType(object):
    STORAGE_INITIALIZER_REST = "StorageInitializer"
    INFERENCE_SERVER_REST = "InferenceServer"
    INFERENCE_SERVER = "inference-server"
    STORAGE_INITIALIZER = "storage-initializer"


class EndpointKeyType(object):
    PRIMARY_KEY_TYPE = "primary"
    SECONDARY_KEY_TYPE = "secondary"


class JobType(object):
    COMMAND = "command"
    SWEEP = "sweep"
    PIPELINE = "pipeline"
    AUTOML = "automl"
    COMPONENT = "component"
    BASE = "base"


class JobLimitsType(object):
    SWEEP = "Sweep"


class JobLogPattern:
    COMMAND_JOB_LOG_PATTERN = "azureml-logs/[\\d]{2}.+\\.txt"
    PIPELINE_JOB_LOG_PATTERN = "logs/azureml/executionlogs\\.txt"
    SWEEP_JOB_LOG_PATTERN = "azureml-logs/hyperdrive\\.txt"
    COMMON_RUNTIME_STREAM_LOG_PATTERN = "user_logs/std_log[\\D]*[0]*(?:_ps)?\\.txt"
    COMMON_RUNTIME_ALL_USER_LOG_PATTERN = "user_logs/std_log.*\\.txt"


class AzureMLResourceType(object):
    CODE = "codes"
    COMPUTE = "computes"
    DATA = "data"
    DATASET = "datasets"
    DATASTORE = "datastores"
    ONLINE_ENDPOINT = "online_endpoints"
    BATCH_ENDPOINT = "batch_endpoints"
    ONLINE_DEPLOYMENT = "online_deployments"
    DEPLOYMENT = "deployments"
    BATCH_DEPLOYMENT = "batch_deployments"
    ENVIRONMENT = "environments"
    JOB = "jobs"
    MODEL = "models"
    VIRTUALCLUSTER = "virtualclusters"
    WORKSPACE = "workspaces"
    COMPONENT = "components"

    NAMED_TYPES = {JOB, COMPUTE, WORKSPACE, ONLINE_ENDPOINT, ONLINE_DEPLOYMENT, DATASTORE}
    VERSIONED_TYPES = {MODEL, DATA, DATASET, CODE, ENVIRONMENT, COMPONENT}


class ArmConstants(object):
    CODE_PARAMETER_NAME = "codes"
    CODE_VERSION_PARAMETER_NAME = "codeVersions"
    MODEL_PARAMETER_NAME = "models"
    MODEL_VERSION_PARAMETER_NAME = "modelVersions"
    ENVIRONMENT_PARAMETER_NAME = "environments"
    WORKSPACE_PARAMETER_NAME = "workspaceName"
    LOCATION_PARAMETER_NAME = "location"
    ENDPOINT_IDENTITY_PARAMETER_NAME = "onlineEndpointIdentity"
    ENDPOINT_PARAMETER_NAME = "onlineEndpoint"
    ENDPOINT_PROPERTIES_PARAMETER_NAME = "onlineEndpointProperties"
    ENDPOINT_PROPERTIES_TRAFFIC_UPDATE_PARAMETER_NAME = "onlineEndpointPropertiesTrafficUpdate"
    ENDPOINT_NAME_PARAMETER_NAME = "onlineEndpointName"
    ENDPOINT_TAGS_PARAMETER_NAME = "onlineEndpointTags"
    DEPLOYMENTS_PARAMETER_NAME = "onlineDeployments"
    PROPERTIES_PARAMETER_NAME = "properties"
    DEPENDSON_PARAMETER_NAME = "dependsOn"
    TRAFFIC_PARAMETER_NAME = "trafficRules"
    CODE_RESOURCE_NAME = "codeDeploymentCopy"
    CODE_VERSION_RESOURCE_NAME = "codeVersionDeploymentCopy"
    MODEL_RESOURCE_NAME = "modelDeploymentCopy"
    MODEL_VERSION_RESOURCE_NAME = "modelVersionDeploymentCopy"
    ENVIRONMENT_VERSION_RESOURCE_NAME = "environmentVersionDeploymentCopy"
    ONLINE_DEPLOYMENT_RESOURCE_NAME = "onlineDeploymentCopy"
    ONLINE_ENDPOINT_RESOURCE_NAME = "onlineEndpointCopy"
    UPDATE_RESOURCE_NAME = "updateEndpointWithTraffic"
    ENDPOINT_CREATE_OR_UPDATE_PARAMETER_NAME = "endpointCreateOrUpdate"
    TAGS = "tags"
    SKU = "sku"
    KEY_VAULT_PARAMETER_NAME = "vaults"
    STORAGE_ACCOUNT_PARAMETER_NAME = "storageAccounts"
    APP_INSIGHTS_PARAMTER_NAME = "components"
    CONTAINER_REGISTRY_PARAMETER_NAME = "registries"

    CODE_TYPE = "code"
    CODE_VERSION_TYPE = "code_version"
    MODEL_TYPE = "model"
    MODEL_VERSION_TYPE = "model_version"
    ENVIRONMENT_TYPE = "environment"
    ENVIRONMENT_VERSION_TYPE = "environment_version"
    ONLINE_ENDPOINT_TYPE = "online_endpoint"
    ONLINE_DEPLOYMENT_TYPE = "online_deployment"
    UPDATE_ONLINE_ENDPOINT_TYPE = "update_online_endpoint"
    BASE_TYPE = "base"
    WORKSPACE_BASE = "workspace_base"
    WORKSPACE_PARAM = "worpspace_param"

    OPERATION_CREATE = "create"
    OPERATION_UPDATE = "update"
    NAME = "name"
    VERSION = "version"
    ASSET_PATH = "assetPath"
    DATASTORE_ID = "datastoreId"
    OBJECT = "Object"
    ARRAY = "Array"
    STRING = "String"
    DEFAULT_VALUE = "defaultValue"

    STORAGE = "StorageAccount"
    KEY_VAULT = "KeyVault"
    APP_INSIGHTS = "AppInsights"
    WORKSPACE = "Workspace"

    AZURE_MGMT_RESOURCE_API_VERSION = "2020-06-01"
    AZURE_MGMT_STORAGE_API_VERSION = "2019-06-01"
    AZURE_MGMT_APPINSIGHT_API_VERSION = "2015-05-01"
    AZURE_MGMT_KEYVAULT_API_VERSION = "2019-09-01"
    AZURE_MGMT_CONTAINER_REG_API_VERSION = "2019-05-01"


class WorkspaceResourceConstants(object):
    ENCRYPTION_STATUS_ENABLED = "Enabled"


class HttpResponseStatusCode(object):
    NOT_FOUND = 404


class OperationStatus(object):
    SUCCEEDED = "Succeeded"
    FAILED = "Failed"
    CANCELED = "Canceled"
    RUNNING = "Running"


class EndpointInvokeFields(object):
    DEFAULT_HEADER = {"Content-Type": "application/json"}
    AUTHORIZATION = "Authorization"
    MODEL_DEPLOYMENT = "azureml-model-deployment"


class EndpointGetLogsFields(object):
    LINES = 5000


class CommonYamlFields(object):
    TYPE = "type"


class JobComputePropertyFields(object):
    # Legacy name
    AISUPERCOMPUTER = "AISuperComputer"
    SINGULARITY = "Singularity"


class EndpointYamlFields(object):
    TYPE = "type"
    TRAFFIC_NAME = "traffic"
    NAME = "name"
    SCALE_SETTINGS = "scale_settings"
    SCALE_TYPE = "scale_type"
    INSTANCE_COUNT = "instance_count"
    MINIMUM = "min_instances"
    MAXIMUM = "max_instances"
    POLLING_INTERVAL = "polling_interval"
    TARGET_UTILIZATION_PERCENTAGE = "target_utilization_percentage"
    SKU_DEFAULT = "Standard_F4s_v2"
    COMPUTE = "compute"
    CODE_CONFIGURATION = "code_configuration"
    CODE = "code"
    SCORING_SCRIPT = "scoring_script"
    SCORING_URI = "scoring_uri"
    SWAGGER_URI = "swagger_uri"
    PROVISIONING_STATE = "provisioning_state"
    MINI_BATCH_SIZE = "mini_batch_size"
    RETRY_SETTINGS = "retry_settings"
    BATCH_JOB_INSTANCE_COUNT = "compute.instance_count"
    BATCH_JOB_OUTPUT_PATH = "output_dataset.path"
    BATCH_JOB_OUTPUT_DATSTORE = "output_dataset.datastore_id"
    BATCH_JOB_DATASET = "dataset"
    BATCH_JOB_NAME = "job_name"


class GitProperties(object):
    ENV_REPOSITORY_URI = "AZUREML_GIT_REPOSITORY_URI"
    ENV_BRANCH = "AZUREML_GIT_BRANCH"
    ENV_COMMIT = "AZUREML_GIT_COMMIT"
    ENV_DIRTY = "AZUREML_GIT_DIRTY"
    ENV_BUILD_ID = "AZUREML_GIT_BUILD_ID"
    ENV_BUILD_URI = "AZUREML_GIT_BUILD_URI"

    PROP_DIRTY = "azureml.git.dirty"
    PROP_BUILD_ID = "azureml.git.build_id"
    PROP_BUILD_URI = "azureml.git.build_uri"

    PROP_MLFLOW_GIT_BRANCH = "mlflow.source.git.branch"
    PROP_MLFLOW_GIT_COMMIT = "mlflow.source.git.commit"
    PROP_MLFLOW_GIT_REPO_URL = "mlflow.source.git.repoURL"


class AutoMLConstants:
    # The following are fields found in the yaml for AutoML Job
    GENERAL_YAML = "general"
    DATA_YAML = "data"
    FEATURIZATION_YAML = "featurization"
    FORECASTING_YAML = "forecasting"
    TRAINING_YAML = "training"
    MAX_TRIALS_YAML = "max_total_trials"
    DATASET_YAML = "dataset"
    VALIDATION_DATASET_SIZE_YAML = "validation_dataset_size"
    TRAINING_DATA_SETTINGS_YAML = "training"
    TEST_DATA_SETTINGS_YAML = "test"
    VALIDATION_DATA_SETTINGS_YAML = "validation"
    COUNTRY_OR_REGION_YAML = "country_or_region_for_holidays"
    TASK_TYPE_YAML = "task"
    TRIAL_TIMEOUT_YAML = "trial_timeout_minutes"
    BLOCKED_ALGORITHMS_YAML = "blocked_training_algorithms"
    ALLOWED_ALGORITHMS_YAML = "allowed_training_algorithms"
    ENSEMBLE_MODEL_DOWNLOAD_TIMEOUT_YAML = "ensemble_model_download_timeout_minutes"

    # The following are general purpose AutoML fields
    TARGET_LAGS = "target_lags"
    AUTO = "auto"
    OFF = "off"
    CUSTOM = "custom"
    TIME_SERIES_ID_COLUMN_NAMES = "time_series_id_column_names"
    TRANSFORMER_PARAMS = "transformer_params"
    MODE = "mode"


class PipelineConstants:
    DEFAULT_DATASTORE_SDK = "default_datastore_name"
    DEFAULT_DATASTORE_REST = "defaultDatastoreName"
    DATASTORE = "datastore"
    DATASTORE_REST = "Datastore"
    ENVIRONMENT = "environment"
    CODE = "code"


class OnlineEndpointConfigurations:
    MIN_NAME_LENGTH = 3
    MAX_NAME_LENGTH = 32
    NAME_REGEX_PATTERN = r"^[a-zA-Z]([-a-zA-Z0-9]*[a-zA-Z0-9])?$"


class LROConfigurations:
    MAX_WAIT_COUNT = 150
    POLLING_TIMEOUT = 720
    POLL_INTERVAL = 5
    SLEEP_TIME = 5


class OrderString:
    CREATED_AT_DESC = "createdtime desc"


class ComputeDefaults:
    VMSIZE = "STANDARD_DS3_V2"
    ADMIN_USER = "azureuser"
    MIN_NODES = 0
    MAX_NODES = 4
    IDLE_TIME = 1800
    PRIORITY = "Dedicated"


class ComponentType(object):
    COMMAND = "command"


class ComponentJobConstants(object):
    INPUT_PATTERN = r"^\$\{\{(inputs|jobs)\.(.*?)\}\}$"
    OUTPUT_PATTERN = r"^\$\{\{outputs\.(.*?)\}\}$"
    INPUT_DESTINATION_FORMAT = "jobs.{}.inputs.{}"
    OUTPUT_DESTINATION_FORMAT = "jobs.{}.outputs.{}"


class DockerTypes:
    IMAGE = "Image"
    BUILD = "Build"


class DataType:
    SIMPLE = "Simple"
    DATAFLOW = "Dataflow"


class LocalEndpointConstants:
    CONDA_FILE_NAME = "conda.yml"
    DOCKER_PORT = "5001"
    LABEL_KEY_AZUREML_LOCAL_ENDPOINT = "azureml-local-endpoint"
    LABEL_KEY_ENDPOINT_NAME = "endpoint"
    LABEL_KEY_DEPLOYMENT_NAME = "deployment"
    LABEL_KEY_ENDPOINT_JSON = "endpoint-data"
    LABEL_KEY_DEPLOYMENT_JSON = "deployment-data"
    LABEL_KEY_AZUREML_PORT = "azureml-port"
    DEFAULT_STARTUP_WAIT_TIME_SECONDS = 15
    CONTAINER_EXITED = "exited"
    ENDPOINT_STATE_FAILED = "Failed"
    ENDPOINT_STATE_SUCCEEDED = "Succeeded"
    ENDPOINT_STATE_LOCATION = "local"
    AZUREML_APP_PATH = "/var/azureml-app/"
    ENVVAR_KEY_AZUREML_ENTRY_SCRIPT = "AZUREML_ENTRY_SCRIPT"
    ENVVAR_KEY_AZUREML_MODEL_DIR = "AZUREML_MODEL_DIR"
    ENVVAR_KEY_AML_APP_ROOT = "AML_APP_ROOT"
    ENNVAR_KEY_AZUREML_INFERENCE_PYTHON_PATH = "AZUREML_INFERENCE_PYTHON_PATH"
    CONDA_ENV_NAME = "inf-conda-env"
    CONDA_ENV_BIN_PATH = "/opt/miniconda/envs/inf-conda-env/bin"
    CONDA_ENV_PYTHON_PATH = "/opt/miniconda/envs/inf-conda-env/bin/python"


class InputOutputModes:
    MOUNT = "mount"
    DOWNLOAD = "download"
    UPLOAD = "upload"
    RO_MOUNT = "ro_mount"
    RW_MOUNT = "rw_mount"


class BatchDeploymentOutputAction:
    APPEND_ROW = "append_row"
    SUMMARY_ONLY = "summary_only"


class PublicNetworkAccess:
    ENABLED = "Enabled"
    DISABLED = "Disabled"
