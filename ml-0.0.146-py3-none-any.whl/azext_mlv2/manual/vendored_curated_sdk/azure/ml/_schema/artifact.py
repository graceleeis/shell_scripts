# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging


from marshmallow import fields, post_load
from .asset import AssetSchema
from .fields import ArmStr
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import BASE_PATH_CONTEXT_KEY, AzureMLResourceType

module_logger = logging.getLogger(__name__)


class ArtifactSchema(AssetSchema):
    local_path = fields.Str(metadata={"description": "the path from which the artifact gets uploaded to the cloud"})

    @post_load
    def make(self, data, **kwargs):
        data[BASE_PATH_CONTEXT_KEY] = self.context[BASE_PATH_CONTEXT_KEY]
        return data
