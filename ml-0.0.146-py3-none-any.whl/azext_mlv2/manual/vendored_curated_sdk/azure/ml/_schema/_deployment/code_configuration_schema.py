# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.code_asset import CodeAssetSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmVersionedStr
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import BASE_PATH_CONTEXT_KEY, AzureMLResourceType, EndpointYamlFields
from marshmallow import fields, post_load, validates_schema, ValidationError

module_logger = logging.getLogger(__name__)


class CodeConfigurationSchema(PathAwareSchema):
    code = UnionField([ArmVersionedStr(azureml_type=AzureMLResourceType.CODE), NestedField(CodeAssetSchema)])
    scoring_script = fields.Str()

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import CodeConfiguration

        return CodeConfiguration(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)
