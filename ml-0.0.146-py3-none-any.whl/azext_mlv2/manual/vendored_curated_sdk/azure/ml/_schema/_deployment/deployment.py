# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.environment import EnvironmentSchema, AnonymousEnvironmentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmVersionedStr, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.model import AnonymousModelSchema, PipelineModelSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType
from marshmallow import fields

from .code_configuration_schema import CodeConfigurationSchema

module_logger = logging.getLogger(__name__)


class DeploymentSchema(PathAwareSchema):
    name = fields.Str(required=True)
    endpoint_name = fields.Str(required=True)
    description = fields.Str(metadata={"description": "Description of the endpoint deployment."})
    id = fields.Str()
    tags = fields.Dict()
    properties = fields.Dict()
    model = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.MODEL, allow_default_version=True),
            NestedField(AnonymousModelSchema),
            NestedField(PipelineModelSchema),
        ],
        metadata={"description": "Reference to the model asset for the endpoint deployment."},
    )
    code_configuration = NestedField(
        CodeConfigurationSchema, metadata={"description": "Code configuration for the endpoint deployment."}
    )
    environment = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.ENVIRONMENT, allow_default_version=True),
            NestedField(EnvironmentSchema),
            NestedField(AnonymousEnvironmentSchema),
        ]
    )
    environment_variables = fields.Dict(
        metadata={"description": "Environment variables configuration for the deployment."}
    )
