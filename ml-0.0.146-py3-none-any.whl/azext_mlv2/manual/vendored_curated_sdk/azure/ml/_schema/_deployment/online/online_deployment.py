# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.environment import EnvironmentSchema, AnonymousEnvironmentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmVersionedStr, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.model import AnonymousModelSchema, PipelineModelSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import EndpointComputeType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import camel_to_snake
from marshmallow import fields, post_load

from .scale_settings_schema import DefaultScaleSettingsSchema, TargetUtilizationScaleSettingsSchema
from .request_settings_schema import RequestSettingsSchema
from .resource_requirements_schema import ResourceRequirementsSchema
from .liveness_probe import LivenessProbeSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._deployment.deployment import DeploymentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import BASE_PATH_CONTEXT_KEY

module_logger = logging.getLogger(__name__)


class OnlineDeploymentSchema(DeploymentSchema):
    app_insights_enabled = fields.Bool()
    scale_settings = UnionField(
        [NestedField(DefaultScaleSettingsSchema), NestedField(TargetUtilizationScaleSettingsSchema)]
    )
    request_settings = NestedField(RequestSettingsSchema)
    liveness_probe = NestedField(LivenessProbeSchema)
    readiness_probe = NestedField(LivenessProbeSchema)
    provisioning_state = fields.Str()
    instance_count = fields.Int()
    type = StringTransformedEnum(
        required=False,
        allowed_values=[EndpointComputeType.MANAGED.value, EndpointComputeType.KUBERNETES.value],
        casing_transform=camel_to_snake,
    )
    model_mount_path = fields.Str()
    instance_type = fields.Str()


class KubernetesOnlineDeploymentSchema(OnlineDeploymentSchema):
    resources = NestedField(ResourceRequirementsSchema)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import KubernetesOnlineDeployment

        module_logger.info("KubernetesOnlineDeploymentSchema: Loading KubernetesOnlineDeployment ...")
        return KubernetesOnlineDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class CompositeOnlineDeploymentSchema(OnlineDeploymentSchema):
    resources = NestedField(ResourceRequirementsSchema)
    composite_model = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.MODEL, allow_default_version=True),
            NestedField(AnonymousModelSchema),
            NestedField(PipelineModelSchema),
        ],
        metadata={"description": "Reference to the model asset for the endpoint deployment."},
    )

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._deployment.online_deployment import CompositeOnlineDeployment

        module_logger.info("KubernetesOnlineDeploymentSchema: Loading CompositeOnlineDeployment ...")
        return CompositeOnlineDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class ManagedOnlineDeploymentSchema(OnlineDeploymentSchema):
    instance_type = fields.Str(required=True)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ManagedOnlineDeployment

        return ManagedOnlineDeployment(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)
