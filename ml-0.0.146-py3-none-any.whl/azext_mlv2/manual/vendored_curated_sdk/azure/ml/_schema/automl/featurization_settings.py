# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from marshmallow import fields as flds, post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, NestedField, StringTransformedEnum, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.automl.featurization import (
    FeaturizationSettings,
    FeaturizationConfig,
    ColumnTransformer,
)


class ColumnTransformerSchema(metaclass=PatchedSchemaMeta):
    fields = flds.List(flds.Str())
    parameters = flds.Dict(
        keys=flds.Str(), values=UnionField([flds.Float(), flds.Str()], allow_none=True, missing=None)
    )

    @post_load
    def make(self, data, **kwargs):
        return ColumnTransformer(**data)


class FeaturizationConfigSchema(metaclass=PatchedSchemaMeta):
    blocked_transformers = flds.List(flds.Str())
    column_purposes = flds.Dict(keys=flds.Str(), values=flds.Str())
    transformer_params = flds.Dict(keys=flds.Str(), values=flds.List(NestedField(ColumnTransformerSchema())))
    dataset_language = flds.Str()
    drop_columns = flds.List(flds.Str())

    @post_load
    def make(self, data, **kwargs):
        return FeaturizationConfig(**data)


class FeaturizationSettingsSchema(metaclass=PatchedSchemaMeta):
    featurization_config = UnionField(
        [
            StringTransformedEnum(allowed_values=[AutoMLConstants.AUTO, AutoMLConstants.OFF]),
            NestedField(FeaturizationConfigSchema()),
        ]
    )
    enable_dnn_featurization = flds.Bool()

    @post_load
    def make(self, data, **kwargs):
        return FeaturizationSettings(**data)
