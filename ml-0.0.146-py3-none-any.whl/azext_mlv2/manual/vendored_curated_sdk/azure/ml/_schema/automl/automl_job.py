# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import JobType, AutoMLConstants
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job import BaseJobSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.automl import (
    AutoMLGeneralSettingsSchema,
    ForecastingSettingsSchema,
    FeaturizationSettingsSchema,
    TrainingSettingsSchema,
    DataSettingsSchema,
    AutoMLLimitsSchema,
)


class AutoMLJobSchema(BaseJobSchema):
    type = StringTransformedEnum(required=True, allowed_values=JobType.AUTOML)
    general_settings = NestedField(AutoMLGeneralSettingsSchema(), data_key=AutoMLConstants.GENERAL_YAML, required=True)
    limits = NestedField(AutoMLLimitsSchema())
    data_settings = NestedField(DataSettingsSchema(), data_key=AutoMLConstants.DATA_YAML, required=True)
    featurization_settings = NestedField(FeaturizationSettingsSchema(), data_key=AutoMLConstants.FEATURIZATION_YAML)
    forecasting_settings = NestedField(ForecastingSettingsSchema(), data_key=AutoMLConstants.FORECASTING_YAML)
    training_settings = NestedField(TrainingSettingsSchema(), data_key=AutoMLConstants.TRAINING_YAML)
