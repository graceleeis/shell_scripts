# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from marshmallow import INCLUDE, post_dump
from marshmallow import fields

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.component.distribution import (
    ComponentPyTorchSchema,
    ComponentTensorFlowSchema,
    ComponentMPISchema,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema_meta import PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.component.resource import ComponentResourceSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import UnionField, NestedField


class OverridesSchema(metaclass=PatchedSchemaMeta):
    resources = NestedField(ComponentResourceSchema, unknown=INCLUDE)
    environment_variables = fields.Dict(keys=fields.Str(), values=fields.Str())
    distribution = UnionField(
        [
            NestedField(ComponentPyTorchSchema, unknown=INCLUDE),
            NestedField(ComponentTensorFlowSchema, unknown=INCLUDE),
            NestedField(ComponentMPISchema, unknown=INCLUDE),
        ],
        metadata={"description": "Provides the configuration for a distributed run."},
    )

    @post_dump(pass_original=True)
    def dump_override(self, parsed_json, original, **kwargs):
        # Parsed JSON contains only the properties declared in the schema.
        # To include unknown properties, we return the original,
        # mapping in the known properties
        original["distribution"] = parsed_json.get("distribution", None)
        original["resources"] = parsed_json.get("resources", None)
        original["environment_variables"] = parsed_json.get("environment_variables", None)
        return original
