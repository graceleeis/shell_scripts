# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import ArmVersionedStr, NestedField, PatchedSchemaMeta, StringTransformedEnum, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.component import AnonymousCommandComponentSchema, ComponentFileRefField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.pipeline.overrides import OverridesSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_fields_provider import InputsField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_entry import OutputEntrySchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_uri import OutputUriSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.pipeline.pipeline_job_io import OutputBindingStr
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.pipeline.component_job import ComponentJob
from marshmallow import fields, post_load, INCLUDE

from ..fields import ComputeField

module_logger = logging.getLogger(__name__)


class ComponentJobSchema(metaclass=PatchedSchemaMeta):
    type = fields.Str()
    inputs = InputsField()
    outputs = fields.Dict(
        keys=fields.Str(),
        values=UnionField([OutputBindingStr, NestedField(OutputEntrySchema), NestedField(OutputUriSchema)]),
    )
    component = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.COMPONENT, allow_default_version=True),
            NestedField(AnonymousCommandComponentSchema, unknown=INCLUDE),
            ComponentFileRefField,
        ]
    )
    compute = ComputeField()
    overrides = NestedField(OverridesSchema, unknown=INCLUDE)

    @post_load
    def make(self, data, **kwargs) -> ComponentJob:
        return ComponentJob(**data)
