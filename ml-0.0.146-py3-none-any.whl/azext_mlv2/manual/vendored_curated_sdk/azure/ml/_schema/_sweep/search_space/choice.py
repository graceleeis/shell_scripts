# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import SearchSpace
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema import PatchedSchemaMeta
from marshmallow import fields, post_load


class ChoiceSchema(metaclass=PatchedSchemaMeta):
    values = fields.List(UnionField([fields.Float(), fields.Str(), fields.Dict()]))
    type = StringTransformedEnum(required=True, allowed_values=SearchSpace.CHOICE)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Choice

        return Choice(**data)
