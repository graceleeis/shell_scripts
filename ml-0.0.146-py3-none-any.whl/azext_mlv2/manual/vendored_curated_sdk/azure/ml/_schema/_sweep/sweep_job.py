# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_fields_provider import InputsField, OutputsField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.parameterized_command import ParameterizedCommandSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.job_limits import SweepJobLimitsSchema
from marshmallow import fields
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import (
    SamplingAlgorithm,
)

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import JobType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, UnionField

from .search_space import (
    UniformSchema,
    ChoiceSchema,
    NormalSchema,
    QUniformSchema,
    QNormalSchema,
    RandintSchema,
)
from .sweep_objective import SweepObjectiveSchema
from .sweep_termination import (
    BanditPolicySchema,
    MedianStoppingPolicySchema,
    TruncationSelectionPolicySchema,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job import BaseJobSchema


# This is meant to match the yaml definition NOT the models defined in _restclient
class SweepJobSchema(BaseJobSchema):
    type = StringTransformedEnum(required=True, allowed_values=JobType.SWEEP)
    sampling_algorithm = StringTransformedEnum(
        required=True,
        allowed_values=[SamplingAlgorithm.BAYESIAN, SamplingAlgorithm.GRID, SamplingAlgorithm.RANDOM],
        metadata={"description": "The sampling algorithm to use for the hyperparameter sweep."},
    )
    search_space = fields.Dict(
        keys=fields.Str(),
        values=UnionField(
            [
                NestedField(ChoiceSchema()),
                NestedField(UniformSchema()),
                NestedField(QUniformSchema()),
                NestedField(NormalSchema()),
                NestedField(QNormalSchema()),
                NestedField(RandintSchema()),
            ]
        ),
        metadata={"description": "The parameters to sweep over the trial."},
    )
    objective = NestedField(
        SweepObjectiveSchema,
        required=True,
        metadata={"description": "The name and optimization goal of the primary metric."},
    )
    trial = NestedField(ParameterizedCommandSchema, required=True)
    early_termination = UnionField(
        [
            NestedField(BanditPolicySchema()),
            NestedField(MedianStoppingPolicySchema()),
            NestedField(TruncationSelectionPolicySchema()),
        ],
        metadata={"description": "The early termination policy to be applied to the Sweep runs."},
    )
    limits = NestedField(SweepJobLimitsSchema)
    inputs = InputsField()
    outputs = OutputsField()
