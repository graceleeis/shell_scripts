# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from marshmallow import fields

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema import PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import (
    Goal,
)

module_logger = logging.getLogger(__name__)


class SweepObjectiveSchema(metaclass=PatchedSchemaMeta):
    goal = StringTransformedEnum(required=True, allowed_values=[Goal.MINIMIZE, Goal.MAXIMIZE])
    primary_metric = fields.Str(required=True)
