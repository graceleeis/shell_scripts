# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
from typing import Any
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmStr
from marshmallow import fields, post_load, validates_schema, ValidationError, pre_load, validates
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema._endpoint.endpoint import EndpointSchema

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import (
    AzureMLResourceType,
    BASE_PATH_CONTEXT_KEY,
    EndpointYamlFields,
)

module_logger = logging.getLogger(__name__)


class OnlineEndpointSchema(EndpointSchema):
    traffic = fields.Dict(
        keys=fields.Str(),
        values=fields.Int(),
        metadata={
            "description": "a dict with key as deployment name and value as traffic percentage. The values need to sum to 100"
        },
    )
    allow_public_access = fields.Bool()

    @validates("traffic")
    def validate_traffic(self, data, **kwargs):
        if sum(data.values()) > 100:
            raise ValidationError("Traffic rule percentages must sum to less than or equal to 100%")

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import OnlineEndpoint

        return OnlineEndpoint(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class KubernetesOnlineEndpointSchema(OnlineEndpointSchema):
    provisioning_state = fields.Str(metadata={"description": "status of the deployment provisioning operation"})
    compute = ArmStr(azureml_type=AzureMLResourceType.COMPUTE)

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import KubernetesOnlineEndpoint

        return KubernetesOnlineEndpoint(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class ManagedOnlineEndpointSchema(OnlineEndpointSchema):
    provisioning_state = fields.Str()

    @post_load
    def make(self, data: Any, **kwargs: Any) -> Any:
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ManagedOnlineEndpoint

        return ManagedOnlineEndpoint(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)
