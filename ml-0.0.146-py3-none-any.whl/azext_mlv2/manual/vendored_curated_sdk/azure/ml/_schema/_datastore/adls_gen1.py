# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Any, Dict

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import DatastoreType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum, UnionField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import camel_to_snake
from marshmallow import fields, post_load

from .credentials import CertificateSchema, ServicePrincipalSchema


class AzureDataLakeGen1Schema(PathAwareSchema):
    name = fields.Str(required=True)
    type = StringTransformedEnum(
        allowed_values=DatastoreType.AZURE_DATA_LAKE_GEN1,
        casing_transform=camel_to_snake,
        required=True,
    )
    store_name = fields.Str(required=True)
    credentials = UnionField([NestedField(ServicePrincipalSchema), NestedField(CertificateSchema)])
    description = fields.Str()
    tags = fields.Dict(keys=fields.Str(), values=fields.Dict())

    @post_load
    def make(self, data: Dict[str, Any], **kwargs) -> "AzureDataLakeGen1Datastore":
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import AzureDataLakeGen1Datastore

        return AzureDataLakeGen1Datastore(**data)
