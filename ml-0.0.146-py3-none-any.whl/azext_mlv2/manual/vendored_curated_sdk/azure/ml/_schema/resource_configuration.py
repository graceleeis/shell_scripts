# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema_meta import PatchedSchemaMeta
from marshmallow import fields, post_load


class ResourceConfigurationSchema(metaclass=PatchedSchemaMeta):
    instance_count = fields.Int()
    instance_type = fields.Str(metadata={"description": "The instance type to make available to this job."})
    properties = fields.Dict(keys=fields.Str())

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ResourceConfiguration

        return ResourceConfiguration(**data)
