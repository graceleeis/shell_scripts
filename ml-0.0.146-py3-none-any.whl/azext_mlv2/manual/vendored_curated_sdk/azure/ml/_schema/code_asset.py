# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging
import uuid

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmStr

from .asset import AnonymousAssetSchema
from .artifact import ArtifactSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import BASE_PATH_CONTEXT_KEY, AzureMLResourceType
from marshmallow import ValidationError, fields, post_load, pre_dump

module_logger = logging.getLogger(__name__)


class CodeAssetSchema(ArtifactSchema):
    id = ArmStr(azureml_type=AzureMLResourceType.CODE, dump_only=True)
    code_uri = fields.Str(
        metadata={"description": "Blob URI pointing to a file or directory where code asset is located."}
    )

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Code

        return Code(base_path=self.context[BASE_PATH_CONTEXT_KEY], **data)


class AnonymousCodeAssetSchema(CodeAssetSchema, AnonymousAssetSchema):
    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Code

        return Code(
            name=str(uuid.uuid4()),
            version="1",
            is_anonymous=True,
            base_path=self.context[BASE_PATH_CONTEXT_KEY],
            **data
        )

    @pre_dump
    def validate(self, data, **kwargs):
        # AnonymousCodeAssetSchema does not support None or arm string(fall back to ArmVersionedStr)
        if data is None or not hasattr(data, "get"):
            raise ValidationError("Code cannot be None")
        return data
