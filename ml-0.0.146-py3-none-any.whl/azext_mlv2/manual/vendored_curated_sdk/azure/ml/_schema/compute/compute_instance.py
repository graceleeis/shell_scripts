# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from marshmallow import fields
from marshmallow.decorators import post_load
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema_meta import PatchedSchemaMeta
from .compute import ComputeSchema
from ..fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import ComputeType
from ..fields import UnionField, FileRefField, NestedField


class ComputeInstanceSshSettingsSchema(metaclass=PatchedSchemaMeta):
    admin_username = fields.Str(dump_only=True)
    ssh_port = fields.Str(dump_only=True)
    ssh_key_value = fields.Str()

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import SshSettingsForComputeInstance

        return SshSettingsForComputeInstance(**data)


class ComputeInstanceNetworkSettingsSchema(metaclass=PatchedSchemaMeta):
    vnet_name = fields.Str()
    subnet = fields.Str()
    public_ip_address = fields.Str(dump_only=True)
    private_ip_address = fields.Str(dump_only=True)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import ComputeInstanceNetworkSettings

        return ComputeInstanceNetworkSettings(**data)


class CreateOnBehalfOfSchema(metaclass=PatchedSchemaMeta):
    user_tenant_id = fields.Str()
    user_object_id = fields.Str()

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import CreateOnBehalfOf

        return CreateOnBehalfOf(**data)


class ComputeInstanceSchema(ComputeSchema):
    type = StringTransformedEnum(allowed_values=[ComputeType.COMPUTEINSTANCE], required=True)
    size = fields.Str()
    network_settings = NestedField(ComputeInstanceNetworkSettingsSchema)
    create_on_behalf_of = NestedField(CreateOnBehalfOfSchema)
    ssh_settings = NestedField(ComputeInstanceSshSettingsSchema)
    ssh_public_access_enabled = fields.Bool(default=None)
    state = fields.Str()
    last_operation = fields.Dict(keys=fields.Str(), values=fields.Str(), dump_only=True)
    applications = fields.List(fields.Dict(keys=fields.Str(), values=fields.Str()), dump_only=True)
