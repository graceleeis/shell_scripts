# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, UnionField
from marshmallow import fields
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_entry import (
    InputDatasetSchema,
    InputDataSchema,
    InputLiteralValueSchema,
    OutputEntrySchema,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.input_output_uri import InputUriSchema, OutputUriSchema


def InputsField(**kwargs):
    return fields.Dict(
        keys=fields.Str(),
        values=UnionField(
            [
                # By default when strict is false, marshmallow downcasts float to int.
                # Setting it to true will throw a validation error and try the next types in list.
                # https://github.com/marshmallow-code/marshmallow/pull/755
                NestedField(InputDatasetSchema),
                NestedField(InputUriSchema),
                NestedField(InputDataSchema),
                NestedField(InputLiteralValueSchema),
                fields.Int(strict=True),
                fields.Str(),
                fields.Bool(),
                fields.Float(),
            ],
            metadata={"description": "Inputs to a job."},
            **kwargs
        ),
    )


def OutputsField(**kwargs):
    return fields.Dict(
        keys=fields.Str(),
        values=UnionField([NestedField(OutputUriSchema), NestedField(OutputEntrySchema)], allow_none=True),
        metadata={"description": "Outputs of a job."},
        **kwargs
    )
