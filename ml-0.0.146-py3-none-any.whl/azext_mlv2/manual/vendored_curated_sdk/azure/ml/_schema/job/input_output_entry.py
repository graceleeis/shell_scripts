# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import NestedField, PatchedSchemaMeta, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import AzureMLResourceType, InputOutputModes
from marshmallow import pre_dump, ValidationError, fields, post_load, pre_load

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.dataset import AnonymousDataSchema, AnonymousDatasetSchema, DatasetSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import ArmVersionedStr, UnionField
from marshmallow.decorators import validates_schema

module_logger = logging.getLogger(__name__)


class InputDatasetSchema(metaclass=PatchedSchemaMeta):
    mode = StringTransformedEnum(
        allowed_values=[
            InputOutputModes.DOWNLOAD,
            InputOutputModes.RO_MOUNT,
            InputOutputModes.RW_MOUNT,
        ],
        required=False,
    )
    dataset = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.DATASET, allow_default_version=True),
            NestedField(AnonymousDatasetSchema),
        ],
        required=True,
    )

    @pre_dump
    def check_dict(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.input_output_entry import InputDatasetEntry

        if isinstance(data, InputDatasetEntry):
            return data
        else:
            raise ValidationError("InputDatasetSchema needs type InputDatasetEntry to dump")


class InputDataSchema(metaclass=PatchedSchemaMeta):
    mode = StringTransformedEnum(
        allowed_values=[InputOutputModes.MOUNT, InputOutputModes.DOWNLOAD],
        required=False,
    )
    data = UnionField(
        [
            ArmVersionedStr(azureml_type=AzureMLResourceType.DATA, allow_default_version=True),
            NestedField(AnonymousDataSchema),
        ]
    )

    @pre_load
    def warn_for_data_deprecation(self, data, **kwargs):
        if data is not None and isinstance(data, dict) and "data" in data:
            module_logger.warning(
                f"Warning: the provided input type data for '{data}' is deprecated and will be removed in a future release. Use dataset instead."
            )
        return data

    @pre_dump
    def check_dict(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.input_output_entry import InputOutputEntry

        if isinstance(data, InputOutputEntry):
            return data
        else:
            raise ValidationError("InputDatasetSchema needs type InputOutputEntry to dump")


class InputLiteralValueSchema(metaclass=PatchedSchemaMeta):
    value = UnionField([fields.Str(), fields.Bool(), fields.Int(), fields.Float()])

    @post_load
    def make(self, data, **kwargs):
        return data["value"]

    @pre_dump
    def check_dict(self, data, **kwargs):
        if hasattr(data, "value"):
            return data
        else:
            raise ValidationError("InputLiteralValue must have a field value")


class OutputEntrySchema(PathAwareSchema):
    mode = StringTransformedEnum(
        allowed_values=[InputOutputModes.MOUNT, InputOutputModes.UPLOAD, InputOutputModes.RW_MOUNT],
        required=False,
    )
    data = NestedField(DatasetSchema, dump_only=True)

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.input_output_entry import OutputDatasetEntry

        return OutputDatasetEntry(**data)
