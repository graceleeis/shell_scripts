# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import copy
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import JobLimitsType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.schema_meta import PatchedSchemaMeta
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._utils.utils import from_iso_duration_format, to_iso_duration_format
from marshmallow import fields, post_load, pre_dump


class CommandJobLimitsSchema(metaclass=PatchedSchemaMeta):
    timeout = fields.Int()

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import CommandJobLimits

        if data.get("timeout", None):
            data["timeout"] = to_iso_duration_format(data["timeout"])

        return CommandJobLimits(**data)

    @pre_dump
    def pre_dump(self, obj: "CommandJobLimits", **kwargs):
        if obj.timeout:
            obj_copy = copy.deepcopy(obj)
            obj_copy.timeout = str(from_iso_duration_format(obj_copy.timeout))
            return obj_copy

        return obj


class SweepJobLimitsSchema(metaclass=PatchedSchemaMeta):
    max_concurrent_trials = fields.Int(metadata={"description": "Sweep Job max concurrent trials."})
    max_total_trials = fields.Int(metadata={"description": "Sweep Job max total trials."})
    timeout = fields.Int(
        metadata={
            "description": "The max run duration in ISO 8601 format, after which the job will be cancelled. Only supports duration with precision as low as Seconds."
        }
    )
    trial_timeout = fields.Int(metadata={"description": "Sweep Job Trial timeout value."})

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import SweepJobLimits

        if data.get("timeout", None):
            # Bug 1335978:  Service rounds durations less than 60 seconds to 60 days.
            # If duration is non-0 and less than 60, set to 60.
            floored_timeout = data["timeout"] if data["timeout"] > 60 or data["timeout"] == 0 else 60
            data["timeout"] = to_iso_duration_format(floored_timeout)
        if data.get("trial_timeout", None):
            floored_timeout = data["trial_timeout"] if data["trial_timeout"] > 60 or data["trial_timeout"] == 0 else 60
            data["trial_timeout"] = to_iso_duration_format(floored_timeout)

        return SweepJobLimits(**data)

    @pre_dump
    def pre_dump(self, obj: "SweepJobLimits", **kwargs):

        obj_copy = copy.deepcopy(obj)
        if obj.timeout:
            obj_copy.timeout = str(from_iso_duration_format(obj_copy.timeout))
        if obj.trial_timeout:
            obj_copy.trial_timeout = str(from_iso_duration_format(obj_copy.trial_timeout))

        return obj_copy
