# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------


import logging

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._restclient.v2021_10_01.models import AmlToken, ManagedIdentity, IdentityConfigurationType
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from marshmallow import fields, post_load

from ..schema import PatchedSchemaMeta

module_logger = logging.getLogger(__name__)


class ManagedIdentitySchema(metaclass=PatchedSchemaMeta):
    identity_type = StringTransformedEnum(
        data_key="type", name="type", required=True, allowed_values=IdentityConfigurationType.MANAGED
    )
    client_id = fields.Str()
    object_id = fields.Str()
    msi_resource_id = fields.Str()

    @post_load
    def make(self, data, **kwargs):
        return ManagedIdentity(**data)


class AMLTokenIdentitySchema(metaclass=PatchedSchemaMeta):
    identity_type = StringTransformedEnum(
        data_key="type", name="type", required=True, allowed_values=IdentityConfigurationType.AML_TOKEN
    )

    @post_load
    def make(self, data, **kwargs):
        return AmlToken(**data)
