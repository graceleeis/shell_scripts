# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import PatchedSchemaMeta, PathAwareSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import StringTransformedEnum
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import InputOutputModes
from marshmallow import pre_dump, ValidationError, fields, post_load, pre_load
from marshmallow.decorators import validates_schema


class UriBaseSchema(PathAwareSchema):
    file = fields.String()
    folder = fields.String()

    @pre_load
    def pre_load(self, data, **kwargs):
        if data is None or not isinstance(data, dict):
            raise ValidationError("Uri must specify a file or a folder.")
        if data.get("file", None) is not None and data.get("folder", None) is not None:
            raise ValidationError("Uri can only specify a file or a folder.")
        if data.get("file", None) is None and data.get("folder", None) is None:
            raise ValidationError("Uri must specify a file or a folder.")
        return data

    @validates_schema
    def validate(self, data, **kwargs):
        if data.get("file", None) is not None and data.get("folder", None) is not None:
            raise ValidationError("Uri can only specify a file or a folder.")
        if data.get("file", None) is None and data.get("folder", None) is None:
            raise ValidationError("Uri must specify a file or a folder.")

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.input_output_entry import UriInputOutputEntry

        return UriInputOutputEntry(**data)

    @pre_dump
    def check_dict(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._job.input_output_entry import UriInputOutputEntry

        if isinstance(data, UriInputOutputEntry):
            return data
        else:
            # Assists with union schema
            raise ValidationError("Input/Output UriSchema needs type UriInputOutputEntry to dump")


class OutputUriSchema(UriBaseSchema):
    file = fields.String(dump_only=True)
    folder = fields.String(dump_only=True)
    mode = StringTransformedEnum(
        allowed_values=[InputOutputModes.UPLOAD, InputOutputModes.RW_MOUNT],
        required=False,
        dump_only=True,
    )


class InputUriSchema(UriBaseSchema):
    mode = StringTransformedEnum(
        allowed_values=[
            InputOutputModes.DOWNLOAD,
            InputOutputModes.RW_MOUNT,
            InputOutputModes.RO_MOUNT,
        ],
        required=False,
    )
