# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from marshmallow import post_dump, post_load, INCLUDE

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.job.distribution import (
    PyTorchDistributionSchema,
    MPIDistributionSchema,
    TensorFlowDistributionSchema,
)


class BaseComponentDistributionSchema:
    class Meta:
        unknown = INCLUDE

    @post_load
    def make(self, data, **kwargs):
        return data

    @post_dump(pass_original=True)
    def dump_override(self, parsed_json, original, **kwargs):
        # Parsed JSON contains only the properties declared in the schema.
        # To include unknown properties, we return the original,
        # mapping the parsed rename.
        if original.get("type", None) is None:
            original["type"] = parsed_json.get("type", None)
        original.pop("distribution_type", None)
        return original


class ComponentPyTorchSchema(BaseComponentDistributionSchema, PyTorchDistributionSchema):
    pass


class ComponentMPISchema(BaseComponentDistributionSchema, MPIDistributionSchema):
    pass


class ComponentTensorFlowSchema(BaseComponentDistributionSchema, TensorFlowDistributionSchema):
    pass
