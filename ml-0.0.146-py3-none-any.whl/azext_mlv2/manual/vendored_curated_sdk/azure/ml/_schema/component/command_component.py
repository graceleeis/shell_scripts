# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import uuid
import yaml
from copy import deepcopy
from marshmallow import fields, post_load, INCLUDE

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema import StringTransformedEnum, UnionField, NestedField, ArmVersionedStr
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.fields import FileRefField
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.asset import AnonymousAssetSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.code_asset import AnonymousCodeAssetSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.component.component import BaseComponentSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.component.resource import ComponentResourceSchema
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.component.distribution import (
    ComponentMPISchema,
    ComponentTensorFlowSchema,
    ComponentPyTorchSchema,
)
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._schema.environment import AnonymousEnvironmentSchema

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import ComponentType, AzureMLResourceType, BASE_PATH_CONTEXT_KEY, FILE_PREFIX


class CommandComponentSchema(BaseComponentSchema):
    type = StringTransformedEnum(allowed_values=[ComponentType.COMMAND])
    command = fields.Str(metadata={"description": "String to be executed. Can set variables using ${{ }}"})
    code = UnionField(
        [
            NestedField(AnonymousCodeAssetSchema),
            ArmVersionedStr(azureml_type=AzureMLResourceType.CODE),
        ],
        metadata={"description": "A file:, http:, https:, or azureml: url pointing to an AzureML instance."},
    )
    environment = UnionField(
        [
            NestedField(AnonymousEnvironmentSchema),
            ArmVersionedStr(azureml_type=AzureMLResourceType.ENVIRONMENT, allow_default_version=True),
        ]
    )
    resources = NestedField(ComponentResourceSchema, unknown=INCLUDE)
    distribution = UnionField(
        [
            NestedField(ComponentPyTorchSchema, unknown=INCLUDE),
            NestedField(ComponentTensorFlowSchema, unknown=INCLUDE),
            NestedField(ComponentMPISchema, unknown=INCLUDE),
        ],
        metadata={"description": "Provides the configuration for a distributed run."},
    )


class AnonymousCommandComponentSchema(AnonymousAssetSchema, CommandComponentSchema):
    """Anonymous command component schema.

    Note inheritance follows order: AnonymousAssetSchema, CommandComponentSchema because we need name and version to
    be dump only(marshmallow collects fields follows method resolution order).
    """

    @post_load
    def make(self, data, **kwargs):
        from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import CommandComponent

        # TODO(1057731): verify if this component can be reused
        return CommandComponent(
            name=str(uuid.uuid4()),
            version="1",
            is_anonymous=True,
            base_path=self.context[BASE_PATH_CONTEXT_KEY],
            **data,
        )


class ComponentFileRefField(FileRefField):
    def _deserialize(self, value, attr, data, **kwargs):
        # Get component info from component yaml file.
        data = super()._deserialize(value, attr, data, **kwargs)
        component_dict = yaml.safe_load(data)

        # Update base_path to parent path of component file.
        component_schema_context = deepcopy(self.context)
        component_schema_context[BASE_PATH_CONTEXT_KEY] = (self.context[BASE_PATH_CONTEXT_KEY] / value).parent
        return AnonymousCommandComponentSchema(context=component_schema_context).load(component_dict, unknown=INCLUDE)
