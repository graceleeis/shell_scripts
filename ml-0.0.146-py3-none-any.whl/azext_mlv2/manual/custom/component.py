# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict
from itertools import islice

from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Component
from .raise_error import log_and_raise_error
from .utils import _is_debug_set, _dump_entity_with_warnings, get_ml_client


def ml_component_list(cmd, resource_group_name, workspace_name, name=None, max_results=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        if max_results:
            results = islice(ml_client.components.list(name=name), int(max_results))
        else:
            results = ml_client.components.list(name=name)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err)


def ml_component_show(cmd, resource_group_name, workspace_name, name, version):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        component = ml_client.components.get(name=name, version=version)
        return _dump_entity_with_warnings(component)
    except Exception as err:
        log_and_raise_error(err)


def ml_component_create(cmd, file, resource_group_name, workspace_name, version=None, params_override=[]):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        # 1. update override params
        if version:
            params_override.append({"version": version})
        # 2. load to component schema
        component = Component.load(path=file, params_override=params_override)
        # 3. create component
        result = ml_client.create_or_update(component)
        return _dump_entity_with_warnings(result)
    except Exception as err:
        log_and_raise_error(err)


def ml_component_update(cmd, resource_group_name, workspace_name, parameters: Dict = None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        # 1. load parameters into component entity
        component_entity = Component._load(data=parameters, yaml_path=".")
        # 2. update the component
        result = ml_client.create_or_update(component_entity)
        return _dump_entity_with_warnings(result)
    except Exception as err:
        log_and_raise_error(err)


def ml_component_delete(cmd, name, resource_group_name, workspace_name, version=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.components.delete(name=name, version=version)
    except Exception as err:
        log_and_raise_error(err)
