import json
import traceback
from colorama import init
from azure.core.exceptions import HttpResponseError, ODataV4Format
from azure.cli.core.style import print_styled_text, Style
from knack.log import get_logger
from knack.cli import CLIError

from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import LIMITED_RESULTSET_WARNING_FORMAT

module_logger = get_logger()

init()


def print_styled_text_with_level(level, text):
    if not isinstance(text, str):
        text = str(text)
    print_styled_text(
        [
            (
                level,
                text,
            )
        ]
    )


def _get_exception_with_error(error_details):
    """
    Converts error message to ARMErrorFormat (if possible)
    and builds error message from it. Otherwise raise exception
    by using message for error passed.
    """
    if isinstance(error_details, str):
        return Exception(error_details)
    try:
        if hasattr(error_details, "message"):
            json_error = json.loads(error_details.message)
        else:
            json_error = json.loads(error_details)
        formatted_error = ODataV4Format(json_object=json_error)
        return Exception(formatted_error.message_details())
    except Exception:
        module_logger.debug(f"Error parsing details of deployment failed error : {error_details.message}")
        return Exception(error_details.message_details())


def _handle_deployment_failed_error(error_response):
    """
    Extracts error message from error details and returns an exception
    """
    if error_response.error.details:
        details = error_response.error.details
        for error_details in details:
            # For time being only handling first element. Assuming there will be only one error message
            # coming from service side rather then clubbing multiple together
            return _get_exception_with_error(error_details=error_details)
    return error_response


def _raise_cli_error(message):
    # Azure CLI guidelines: https://github.com/Azure/azure-cli/blob/dev/doc/error_handling_guidelines.md
    # This does not comply with Azure CLI guidelines on error handling.
    # We should do better to identify the error Exception type. Once SDK raise specific Exception we can
    # handle it in CLI and raise appropriate exceptions as defined in guidelines
    # TODO: Raise exceptions defined in Azure CLI guidelines
    raise CLIError(message)


def log_and_raise_error(error, debug=False):
    # use an f-string to automatically call str() on error
    if debug:
        module_logger.error(traceback.print_exc())
    if isinstance(error, HttpResponseError):
        module_logger.debug(f"Received HttpResponseError: {traceback.format_exc()}")
        if error.error and isinstance(error.error, ODataV4Format):
            if error.error and error.error.code and error.error.code == "DeploymentFailed":
                processed_error = _handle_deployment_failed_error(error_response=error)
                _raise_cli_error(processed_error)
            else:
                _raise_cli_error(error.error.message_details())
        elif hasattr(error, "response") and hasattr(error.response, "internal_response"):
            _raise_cli_error(_get_exception_with_error(error.response.internal_response.text))
        else:
            _raise_cli_error(error.message)
    else:
        module_logger.debug(traceback.format_exc())
        _raise_cli_error(error)


def print_limited_result_set_warning(max_results):
    print_styled_text_with_level(Style.WARNING, str(LIMITED_RESULTSET_WARNING_FORMAT.format(max_results)))
