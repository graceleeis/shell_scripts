# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict, List
from itertools import islice

from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities import Compute, AmlCompute, Identity, VmSize, Usage, UserAssignedIdentity
from .raise_error import log_and_raise_error
from .utils import _dump_entity_with_warnings, _is_debug_set, get_ml_client
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import ComputeType, COMPUTE_UPDATE_ERROR


IDENTITY_ERROR = "Identity_type can only be either of 'SystemAssigned', 'UserAssigned'"
USER_ASSIGNED_IDENTITY_EMPTY_ERROR = "user_assigned_identities cannot be empty for UserAssigned identity"
USER_ASSIGNED_IDENTITY_MORE_THAN_ONE_ERROR = "cannot handle more than one user_assigned_identities"


def ml_compute_list(cmd, resource_group_name, workspace_name, type=None, max_results=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        if max_results:
            results = islice(ml_client.compute.list(compute_type=type), int(max_results))
        else:
            results = ml_client.compute.list(compute_type=type)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_show(cmd, resource_group_name, workspace_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        return _dump_entity_with_warnings(ml_client.compute.get(name=name))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_create(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    type=None,
    vnet_name=None,
    subnet=None,
    admin_username=None,
    admin_password=None,
    ssh_key_value=None,
    ssh_public_access_enabled=None,
    file=None,
    size=None,
    no_wait=False,
    user_tenant_id=None,
    user_object_id=None,
    min_instances=None,
    max_instances=None,
    idle_time_before_scale_down=None,
    description=None,
    identity_type=None,
    user_assigned_identities=None,
    tier=None,
    tags=None,
    params_override=[],
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    if name:
        params_override.append({"name": name})
    if type:
        params_override.append({"type": type.lower()})
    if vnet_name:
        params_override.append({"network_settings.vnet_name": vnet_name})
    if subnet:
        params_override.append({"network_settings.subnet": subnet})
    if admin_username:
        params_override.append({"ssh_settings.admin_username": admin_username})
    if admin_password:
        params_override.append({"ssh_settings.admin_password": admin_password})
    if ssh_key_value:
        params_override.append({"ssh_settings.ssh_key_value": ssh_key_value})
    if size:
        params_override.append({"size": size})
    if user_tenant_id:
        params_override.append({"create_on_behalf_of.user_tenant_id": user_tenant_id})
    if user_object_id:
        params_override.append({"create_on_behalf_of.user_object_id": user_object_id})
    if min_instances:
        params_override.append({"min_instances": min_instances})
    if max_instances:
        params_override.append({"max_instances": max_instances})
    if idle_time_before_scale_down:
        params_override.append({"idle_time_before_scale_down": idle_time_before_scale_down})
    if description:
        params_override.append({"description": description})
    if identity_type:
        params_override.append({"identity.type": identity_type})
    if user_assigned_identities:
        identities = _process_user_assigned_identities(user_assigned_identities)
        params_override.append({"identity.user_assigned_identities": identities})
    if tier:
        params_override.append({"tier": tier})
    if ssh_public_access_enabled:
        params_override.append({"ssh_public_access_enabled": ssh_public_access_enabled})
    if tags:
        params_override.append({"tags": tags})

    try:
        compute = Compute.load(path=file, params_override=params_override)

        compute = ml_client.create_or_update(compute, no_wait=no_wait)
        return _dump_entity_with_warnings(compute)
    except Exception as e:
        log_and_raise_error(e, debug)


def ml_compute_delete(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.compute.begin_delete(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_start(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.compute.begin_start(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_stop(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.compute.begin_stop(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_restart(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.compute.begin_restart(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_list_sizes(cmd, resource_group_name, workspace_name, location=None, type=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        list_sizes = ml_client.compute.list_sizes(location=location, compute_type=type)
        return list(map(lambda x: _dump_entity_with_warnings(VmSize._from_rest_object(x)), list_sizes))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_list_usage(cmd, resource_group_name, workspace_name, location=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        usagelist = ml_client.compute.list_usage(location=location)
        result = []
        for y, x in enumerate(usagelist):
            result.append(_dump_entity_with_warnings(Usage._from_rest_object(x)))
        return result
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_compute_update(
    cmd,
    resource_group_name,
    workspace_name,
    name,
    max_instances=None,
    min_instances=None,
    idle_time_before_scale_down=None,
    identity_type=None,
    user_assigned_identities=None,
    parameters: Dict = None,
    no_wait: bool = False,
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    compute_type = parameters["type"]
    if not compute_type == ComputeType.AMLCOMPUTE:
        log_and_raise_error(COMPUTE_UPDATE_ERROR.format(name, compute_type))

    try:
        identity = None
        if identity_type or user_assigned_identities:
            if user_assigned_identities:
                user_assigned_identities = [
                    UserAssignedIdentity(resource_id=resource_id) for resource_id in user_assigned_identities.split(",")
                ]
            identity = Identity(type=identity_type, user_assigned_identities=user_assigned_identities)

        compute = AmlCompute(
            name=name,
            location=parameters["location"],
            max_instances=max_instances if max_instances else parameters["max_instances"],
            min_instances=min_instances if min_instances else parameters["min_instances"],
            idle_time_before_scale_down=idle_time_before_scale_down
            if idle_time_before_scale_down
            else parameters["idle_time_before_scale_down"],
            identity=identity,
            tags=parameters["tags"],
        )
        compute = ml_client.compute.begin_update(compute, no_wait=no_wait)
        return _dump_entity_with_warnings(compute)
    except Exception as err:
        log_and_raise_error(err, debug)


def _validate_identity(identity_type, user_assigned_identities):
    if identity_type:
        if identity_type not in ["SystemAssigned", "UserAssigned", "None"]:
            raise ValueError(IDENTITY_ERROR)
        if identity_type == "UserAssigned" and not user_assigned_identities:
            raise ValueError(USER_ASSIGNED_IDENTITY_EMPTY_ERROR)
        if identity_type == "UserAssigned" and len(user_assigned_identities) != 1:
            raise ValueError(USER_ASSIGNED_IDENTITY_MORE_THAN_ONE_ERROR)


# Convert comma separated strings to a list of dictionaries
def _process_user_assigned_identities(resource_ids: str) -> List[dict]:
    return [{"resource_id": resource_id} for resource_id in resource_ids.split(",")]


def ml_compute_attach(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    type=None,
    resource_id=None,
    admin_username=None,
    admin_password=None,
    ssh_port=None,
    no_wait=False,
    ssh_private_key_file=None,
    file=None,
    namespace=None,
    identity_type=None,
    user_assigned_identities=None,
):
    _validate_identity(identity_type, user_assigned_identities)
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    params_override = []
    if name:
        params_override.append({"name": name})
    if ssh_private_key_file:
        params_override.append({"ssh_settings.ssh_private_key_file": ssh_private_key_file})
    if admin_username:
        params_override.append({"ssh_settings.admin_username": admin_username})
    if admin_password:
        params_override.append({"ssh_settings.admin_password": admin_password})
    if ssh_port:
        params_override.append({"ssh_settings.ssh_port": ssh_port})
    if type:
        params_override.append({"type": type})
    if resource_id:
        params_override.append({"resource_id": resource_id})
    if namespace:
        params_override.append({"namespace": namespace})
    if identity_type:
        params_override.append({"identity.type": identity_type})
    if user_assigned_identities:
        identities = _process_user_assigned_identities(user_assigned_identities)
        params_override.append({"identity.user_assigned_identities": identities})
    try:
        compute = Compute.load(path=file, params_override=params_override)
        return _dump_entity_with_warnings(ml_client.create_or_update(compute, no_wait=no_wait))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_compute_detach(cmd, resource_group_name, workspace_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.compute.begin_delete(
            name=name,
            action="Detach",
            no_wait=no_wait,
        )
    except Exception as err:
        log_and_raise_error(err, debug)
