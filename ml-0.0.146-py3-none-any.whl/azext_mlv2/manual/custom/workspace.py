# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict
from itertools import islice
from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._workspace.workspace import Workspace
from .utils import _dump_entity_with_warnings, _is_debug_set, get_ml_client
from .raise_error import log_and_raise_error


def ml_workspace_list(cmd, resource_group_name=None, max_results=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    scope = "resource_group" if resource_group_name else "subscription"
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        if max_results:
            results = islice(ml_client.workspaces.list(scope=scope), int(max_results))
        else:
            results = ml_client.workspaces.list(scope=scope)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_show(cmd, resource_group_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        ws = ml_client.workspaces.get(name)
        return _dump_entity_with_warnings(ws)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_listkeys(cmd, resource_group_name, name):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.workspaces.list_keys(name)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_synckeys(cmd, resource_group_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.workspaces.begin_sync_keys(name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_create(
    cmd,
    resource_group_name,
    name=None,
    file=None,
    no_wait=False,
    location=None,
    description=None,
    tags=None,
    display_name=None,
    params_override=[],
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    if name:
        params_override.append({"name": name})
    if location:
        params_override.append({"location": location})
    if description:
        params_override.append({"description": description})
    if tags:
        params_override.append({"tags": tags})
    if display_name:
        params_override.append({"display_name": display_name})

    workspace = Workspace.load(path=file, params_override=params_override)
    try:
        ws = ml_client.workspaces.begin_create(workspace=workspace, no_wait=no_wait)
        return _dump_entity_with_warnings(ws) if ws else None
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_update(
    cmd,
    resource_group_name,
    name,
    display_name=None,
    image_build_compute=None,
    public_network_access=None,
    description=None,
    parameters: Dict = None,
    file=None,
    no_wait=False,
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    tags = parameters.pop("tags", None)
    params_override = [{k: v} for k, v in parameters.items()]
    params_override.append({"name": name})
    if display_name:
        params_override.append({"display_name": display_name})
    if image_build_compute:
        params_override.append({"image_build_compute": image_build_compute})
    if public_network_access is not None:
        params_override.append({"public_network_access": public_network_access})
    if description:
        params_override.append({"description": description})
    workspace = Workspace.load(path=file, params_override=params_override)
    if tags is not None:
        if workspace.tags:
            workspace.tags.update(tags)
        else:
            workspace.tags = tags
    try:
        ws = ml_client.workspaces.begin_update(workspace, no_wait=no_wait)
        return _dump_entity_with_warnings(ws)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_delete(cmd, resource_group_name, name, all_resources=False, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.workspaces.begin_delete(name=name, delete_dependent_resources=all_resources, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_workspace_diagnose(cmd, resource_group_name, name, no_wait=False):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.workspaces.begin_diagnose(name=name, no_wait=no_wait)
    except Exception as err:
        log_and_raise_error(err, debug)
