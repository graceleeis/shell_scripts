# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict
from itertools import islice
from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Environment
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets.environment import BuildContext
from .raise_error import log_and_raise_error
from .utils import _is_debug_set, _dump_entity_with_warnings, get_ml_client


def ml_environment_create(
    cmd,
    resource_group_name,
    workspace_name,
    file=None,
    name=None,
    version=None,
    tags=None,
    description=None,
    image=None,
    conda_file=None,
    build_context=None,
    dockerfile_path="/Dockerfile",
    os_type=None,
    params_override=[],
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    if name:
        params_override.append({"name": name})
    if version:
        params_override.append({"version": version})
    if tags:
        params_override.append({"tags": tags})
    if description:
        params_override.append({"description": description})
    if image:
        params_override.append({"image": image})
    if conda_file:
        params_override.append({"conda_file": conda_file})
    if build_context:
        build = {"local_path": build_context, "dockerfile_path": dockerfile_path}
        params_override.append({"build": build})
    if os_type:
        params_override.append({"os_type": os_type})

    try:
        environment = Environment.load(path=file, params_override=params_override)
        environment = ml_client.create_or_update(environment)
        return _dump_entity_with_warnings(environment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_environment_show(cmd, resource_group_name, workspace_name, name, version):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        environment = ml_client.environments.get(name=name, version=version)
        return _dump_entity_with_warnings(environment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_environment_list(cmd, resource_group_name, workspace_name, name=None, max_results=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        if max_results:
            results = islice(ml_client.environments.list(name=name), int(max_results))
        else:
            results = ml_client.environments.list(name=name)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def _ml_environment_update(cmd, resource_group_name, workspace_name, parameters: Dict = None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        # Set unknown to EXCLUDE so that marshallow doesn't raise on dump only fields.
        environment = Environment._load(data=parameters)
        updated_environment = ml_client.create_or_update(environment)
        return _dump_entity_with_warnings(updated_environment)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_environment_delete(cmd, name, version, resource_group_name, workspace_name, **kwargs):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.environments.delete(name=name, version=version, **kwargs)
    except Exception as err:
        log_and_raise_error(err, debug)
