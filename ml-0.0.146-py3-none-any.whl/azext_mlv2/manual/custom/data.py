# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from .raise_error import log_and_raise_error
from marshmallow.utils import EXCLUDE, RAISE
from .utils import _dump_entity_with_warnings, get_ml_client, _is_debug_set
from itertools import islice

from azure.cli.core.commands.client_factory import get_subscription_id
from azext_mlv2.manual.vendored_curated_sdk.azure.ml.entities._assets import Data
from azext_mlv2.manual.vendored_curated_sdk.azure.ml._constants import ARM_ID_PREFIX


def ml_data_list(cmd, resource_group_name, workspace_name, name=None, max_results=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        if max_results:
            results = islice(ml_client.datasets.list(name=name), int(max_results))
        else:
            results = ml_client.datasets.list(name=name)
        return list(map(lambda x: _dump_entity_with_warnings(x), results))
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_data_show(cmd, resource_group_name, workspace_name, name, version):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )

    try:
        data = ml_client.data.get(name=name, version=version)
        return _dump_entity_with_warnings(data)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_data_create(
    cmd,
    resource_group_name,
    workspace_name,
    name=None,
    version=None,
    file=None,
    datastore_name=None,
    params_override=[],
):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    if name:
        params_override.append({"name": name})
    if version:
        params_override.append({"version": version})
    if datastore_name:
        datastore = ARM_ID_PREFIX + datastore_name
        params_override.append({"datastore": datastore})

    try:
        data = Data.load(path=file, params_override=params_override)
        data = ml_client.data.create_or_update(data)
        return _dump_entity_with_warnings(data)
    except Exception as err:
        log_and_raise_error(err, debug)


# This will only be used for generic update
def _ml_data_update(cmd, resource_group_name, workspace_name, name=None, version=None, **kwargs):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    data_params = kwargs["parameters"]

    if name:
        data_params["name"] = name
    if version:
        data_params["version"] = version

    try:
        data_obj = Data._load(yaml_data=data_params)
        data = ml_client.data.create_or_update(data_obj)
        return _dump_entity_with_warnings(data)
    except Exception as err:
        log_and_raise_error(err, debug)


def ml_data_delete(cmd, resource_group_name, workspace_name, name, version):
    subscription_id = get_subscription_id(cmd.cli_ctx)
    debug = _is_debug_set(cmd.cli_ctx)
    ml_client = get_ml_client(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        workspace_name=workspace_name,
        debug=debug,
        cli_ctx=cmd.cli_ctx,
    )
    try:
        return ml_client.data.delete(name=name, version=version)
    except Exception as err:
        log_and_raise_error(err, debug)
