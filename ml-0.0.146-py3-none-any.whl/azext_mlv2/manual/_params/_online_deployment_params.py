# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azure.cli.core.commands.parameters import get_three_state_flag
from ._common_params import add_common_params, add_override_param


def add_online_deployment_common_param(
    c,
    # type_help_message="The type of deployment. Allowed values: k8s, managed, batch.",
    name_help_message="Name of the deployment.",
    local_deployment_help_message=None,
):
    c.argument("name", options_list=["--name", "-n"], help=name_help_message)
    c.argument(
        "endpoint_name",
        options_list=["--endpoint-name", "-e"],
        help="Name of the online endpoint",
    )
    if local_deployment_help_message:
        c.argument(
            "local", arg_type=get_three_state_flag(), options_list=["--local"], help=local_deployment_help_message
        )


def load_online_deployment_params(self):
    with self.argument_context("ml online-deployment create") as c:
        add_common_params(c)
        add_online_deployment_common_param(
            c,
            local_deployment_help_message="Create deployment locally using Docker."
            " Only one deployment per endpoint is allowed."
            " Note: If specified endpoint doesn't exist, it will be created.",
        )
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML deployment specification.",
        )
        c.argument(
            "all_traffic",
            help="Sets endpoint traffic 100% to this deployment after successful creation, does not work with --no-wait",
        )
        c.argument(
            "vscode_debug",
            arg_type=get_three_state_flag(),
            help="Create local endpoint and attach VSCode debugger. Only works with --local flag.",
            default=False,
        )
        add_override_param(c)

    with self.argument_context("ml online-deployment update") as c:
        add_common_params(c)
        add_online_deployment_common_param(
            c,
            local_deployment_help_message="Update local deployment in Docker environment.",
        )
        c.argument(
            "vscode_debug",
            arg_type=get_three_state_flag(),
            help="Update local endpoint and re-attach VSCode debugger. Only works with --local flag.",
            default=False,
        )
        c.argument(
            "file",
            options_list=["--file", "-f"],
            help="Local path to the YAML file containing the Azure ML deployment specification.",
        )
        add_override_param(c)

    with self.argument_context("ml online-deployment delete") as c:
        add_common_params(c)
        add_online_deployment_common_param(
            c,
            local_deployment_help_message="Delete local deployment from Docker environment.",
        )

    with self.argument_context("ml online-deployment show") as c:
        add_common_params(c)
        add_online_deployment_common_param(
            c,
            local_deployment_help_message="Show local deployment from Docker environment.",
        )

    with self.argument_context("ml online-deployment list") as c:
        add_common_params(c)
        c.argument(
            "endpoint_name",
            options_list=["--endpoint-name", "-e"],
            help="Name of the endpoint",
        )
        c.argument(
            "local",
            arg_type=get_three_state_flag(),
            options_list=["--local"],
            help="List local deployment under this local endpoint.",
        )

    with self.argument_context("ml online-deployment get-logs") as c:
        add_common_params(c)
        add_online_deployment_common_param(
            c,
            local_deployment_help_message="Get logs from local deployment in Docker environment.",
        )
        c.argument("lines", options_list=["--lines", "-l"], help="The maximum number of lines to tail.")
        c.argument(
            "container",
            options_list=["--container", "-c"],
            help="The type of container from which to retrieve logs. Allowed values: inference-server, storage-initializer.",
        )
