# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_dataset_help():
    helps[
        "ml dataset"
    ] = """
        type: group
        short-summary: Manage Azure ML dataset assets.
        long-summary: >
            Azure ML dataset assets are references to file(s) in your storage services or public
            URLs along with any corresponding metadata. They are not copies of your data.
            You can use these dataset assets to access relevant data during model training and
            mount or download the referenced data to your compute target.
    """
    helps[
        "ml dataset list"
    ] = """
        type: command
        short-summary: List dataset assets in a workspace.
        examples:
        - name: List all the dataset assets in a workspace
          text: az ml dataset list --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the dataset asset versions for the specified name in a workspace
          text: az ml dataset list --name my-data --resource-group my-resource-group --workspace-name my-workspace
        - name: List all the dataset assets in a workspace using --query argument to execute a JMESPath query on the results of commands.
          text: az ml dataset list --query \"[].{Name:name}\" --output table --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml dataset show"
    ] = """
        type: command
        short-summary: Shows details for a dataset asset.
        examples:
        - name: Show details for a dataset asset with the specified name and version
          text: az ml dataset show --name my-data --version 1 --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml dataset create"
    ] = """
        type: command
        short-summary: Create a dataset asset.
        long-summary: >
            Dataset assets can be defined from files on your local machine or as references to
            files in cloud storage. The created dataset asset will be tracked in the workspace
            under the specified name and version.


            To create a dataset asset from file(s) on your local machine, specify the 'local_path'
            field in your YAML config. Azure ML will upload these file(s) to the blob container
            that backs the workspace's default datastore (named 'workspaceblobstore'). The created
            dataset asset will then point to that uploaded data.


            To create a dataset asset that references file(s) in cloud storage, specify the
            'datastore' that corresponds to the storage service and the 'path' to the file(s)
            in storage in your YAML config.


            You can also create a dataset asset directly from a storage URL or public URL. To do
            so, specify the URL to the 'path' field in your YAML config.
        examples:
        - name: Create a dataset asset from a YAML specification file
          text: az ml dataset create --file data.yml --resource-group my-resource-group --workspace-name my-workspace
    """
    helps[
        "ml dataset delete"
    ] = """
        type: command
        short-summary: Delete a dataset asset.
    """
    helps[
        "ml dataset update"
    ] = """
        type: command
        short-summary: Update a dataset asset.
        long-summary: >
            Only the 'description' and 'tags' properties can be updated.
    """
