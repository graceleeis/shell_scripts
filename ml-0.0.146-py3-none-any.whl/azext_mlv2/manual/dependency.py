# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import pkg_resources

REQUIREMENTS = []
with open("azext_mlv2/manual/requirements.txt", "rt") as fd:
    REQUIREMENTS = [str(requirement) for requirement in pkg_resources.parse_requirements(fd)]
DEPENDENCIES = ['azure-identity', 'marshmallow<4.0.0,>=3.5', 'tqdm', 'pyjwt<2.0.0', 'azure-storage-blob<=12.5.0,>12.0.0b4', 'pydash<=4.9.0', 'azure-storage-file-share==12.3.0', 'pathspec==0.8.*', 'isodate', 'docker>=4.0.0,~=5.0.0'] + REQUIREMENTS

